const DAY = 86400000;
const digits = value => String(value || '').replace(/[۰-۹٠-٩]/g, c => String('۰۱۲۳۴۵۶۷۸۹'.includes(c) ? '۰۱۲۳۴۵۶۷۸۹'.indexOf(c) : '٠١٢٣٤٥٦٧٨٩'.indexOf(c)));
const normalize = value => digits(value).replace(/[\u200c\u200f\u202a-\u202e]/g, ' ').replace(/\s+/g, ' ').trim();
const jalaliYears = new Map();

export function sourceTimestamp(value) {
  const text = normalize(value);
  const date = text.match(/^(\d{4})[-/](\d{1,2})[-/](\d{1,2})(.*)$/);
  if (!date) return null; // Do not let Date.parse interpret a Persian year as Gregorian.
  const [, y, m, d, tail] = date;
  const year = Number(y), month = Number(m), day = Number(d);
  if (year >= 1300 && year < 1600 && !tail) {
    if (!jalaliYears.has(year)) {
      const format = new Intl.DateTimeFormat('en-US-u-ca-persian', { timeZone: 'UTC', year: 'numeric', month: 'numeric', day: 'numeric' });
      const dates = new Map();
      const start = Date.UTC(year + 621, 0, 1);
      for (let i = 0; i < 731; i++) {
        const utc = start + i * DAY;
        const parts = Object.fromEntries(format.formatToParts(utc).map(p => [p.type, p.value]));
        if (Number(parts.year) === year) dates.set(`${Number(parts.month)}-${Number(parts.day)}`, utc - 3.5 * 3600000);
      }
      jalaliYears.set(year, dates);
    }
    return jalaliYears.get(year).get(`${month}-${day}`) ?? null;
  }
  if (year < 2000 || year > 2200 || month < 1 || month > 12 || day < 1 || day > 31) return null;
  const midnight = new Date(Date.UTC(year, month - 1, day));
  if (midnight.getUTCMonth() !== month - 1 || midnight.getUTCDate() !== day) return null;
  const iso = `${y}-${String(month).padStart(2,'0')}-${String(day).padStart(2,'0')}${tail || 'T00:00:00+03:30'}`;
  const timestamp = Date.parse(iso);
  return Number.isFinite(timestamp) ? timestamp : null;
}

export function relativeAgeDays(value) {
  const text = normalize(value);
  // Keep hour/minute precision when sorting. Match the age phrase, not any mention of work hours.
  const numeric = text.match(/(\d+)\s*(دقیقه|ساعت|روز|هفته|ماه|سال)\s*(?:پیش|قبل)/u);
  if (numeric) return Number(numeric[1]) * ({ دقیقه: 1/1440, ساعت: 1/24, روز: 1, هفته: 7, ماه: 30, سال: 365 })[numeric[2]];
  if (/پریروز/u.test(text)) return 2;
  if (/دیروز/u.test(text)) return 1;
  if (/امروز|لحظات(?:ی)?\s*پیش|دقایق(?:ی)?\s*پیش|همین\s*الان/u.test(text)) return 0;
  if (/یک\s*(?:روز|هفته|ماه|سال)\s*پیش/u.test(text)) return /هفته/u.test(text) ? 7 : /ماه/u.test(text) ? 30 : /سال/u.test(text) ? 365 : 1;
  return null;
}

export function sourceAgeDays(publishedAt, relative = '', now = Date.now()) {
  const timestamp = sourceTimestamp(publishedAt);
  if (timestamp !== null && timestamp <= now + DAY) return Math.max(0, (now - timestamp) / DAY);
  return relativeAgeDays(relative);
}

export function discoveryMeta(context, maxAgeDays = 0, pageNo = 1, rowIndex = 0) {
  const text = normalize(context);
  const ageDays = relativeAgeDays(text);
  // A «جدید» badge is only a hint, never proof for the age filter.
  const newHint = /(?:^|\s|[،؛|])جدید(?:\s|$|[،؛|])/u.test(text);
  const order = Math.max(0, Number(pageNo) - 1) * 1000 + Number(rowIndex || 0);
  const sortAge = ageDays ?? (newHint ? 0.5 : 1.5);
  return { priority: 1000 - sortAge, ageDays, order, context: text.slice(0, 1600) };
}

// Runs in the browser. Each freshness clue must belong to this card only.
export function collectDiscoveryRows({ source }) {
  const scope = document.querySelector('main') || document.body;
  const isJob = href => {
    try {
      const u = new URL(href, location.href);
      return source === 'divar' ? /(^|\.)divar\.ir$/i.test(u.hostname) && /^\/v\//.test(u.pathname)
        : /(^|\.)e-estekhdam\.com$/i.test(u.hostname) && /^\/k[a-z0-9]+(?:-|\/|$)/i.test(u.pathname);
    } catch { return false; }
  };
  const identity = href => { const u = new URL(href, location.href); return source === 'divar' ? u.pathname.split('/').filter(Boolean).at(-1) : (u.pathname.match(/^\/(k[a-z0-9]+)(?:-|\/|$)/i) || [])[1]; };
  const clean = v => String(v || '').replace(/[\u200c\u200f\u202a-\u202e]/g, ' ').replace(/\s+/g, ' ').trim();
  return Array.from(scope.querySelectorAll('a[href]')).filter(a => isJob(a.href) && !a.closest('nav,aside,footer,[class*="recommend" i],[class*="similar" i]')).map((a, rowIndex) => {
    const ownId = identity(a.href);
    let best = a;
    for (let node = a.parentElement, depth = 0; node && node !== scope && depth < 6; node = node.parentElement, depth++) {
      const ids = new Set(Array.from(node.querySelectorAll('a[href]')).filter(x => isJob(x.href)).map(x => identity(x.href)));
      if (ids.size !== 1 || !ids.has(ownId) || node.matches('nav,aside,footer')) break;
      const text = clean(node.innerText || node.textContent);
      if (text.length > 2600) break;
      best = node;
    }
    return { href: a.href, rowIndex, context: clean(best.innerText || best.textContent || '').slice(0, 2200) };
  });
}

export function freshnessDecision(data, card, maxAgeDays, requireKnownAge, now = Date.now()) {
  const detailAge = sourceAgeDays(data?.publishedAt, data?.publishedRelative, now);
  const ageDays = detailAge ?? (Number.isFinite(card?.ageDays) ? card.ageDays : null);
  return { ageDays, reason: maxAgeDays <= 0 ? 'disabled' : ageDays === null ? 'unknown' : ageDays > maxAgeDays ? 'old' : 'recent',
    allow: maxAgeDays <= 0 || (ageDays === null ? !requireKnownAge : ageDays <= maxAgeDays) };
}
