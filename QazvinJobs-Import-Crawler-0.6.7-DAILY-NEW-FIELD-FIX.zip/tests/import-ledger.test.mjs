import { test } from 'node:test';
import assert from 'node:assert/strict';
import { mkdtemp, readFile, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { ImportLedger } from '../import-ledger.mjs';
import { freshnessDecision } from '../freshness.mjs';

const endpoint = 'https://example.com/wp-json/import/batch';
async function withHistory(fn) {
  const dir = await mkdtemp(join(tmpdir(), 'qz-history-test-'));
  try { await fn(join(dir, 'history.json')); } finally { await rm(dir, { recursive: true, force: true }); }
}

test('a new process restores acknowledged IDs and skips a repeated source ad', async () => withHistory(async path => {
  const morning = new ImportLedger(path, endpoint);
  await morning.load();
  assert.equal(morning.has('divar', 'divar-ABC123'), false);
  await morning.acknowledge('divar', 'divar-ABC123', 'accepted');
  const tomorrow = new ImportLedger(path, endpoint);
  await tomorrow.load();
  assert.equal(tomorrow.has('divar', 'divar-ABC123'), true);
  assert.equal(tomorrow.has('divar', 'divar-NEW123'), false);
  assert.equal(tomorrow.has('e-estekhdam', 'divar-ABC123'), false);
  const raw = await readFile(path, 'utf8');
  assert.ok(!raw.includes(endpoint));
}));

test('rejected and failed ads remain eligible, receiver duplicates become acknowledged', async () => withHistory(async path => {
  const history = new ImportLedger(path, endpoint);
  await history.load();
  for (const status of ['no_contact', 'no_location', 'error', '', undefined]) {
    await history.acknowledge('divar', 'retry-ad', status);
    assert.equal(history.has('divar', 'retry-ad'), false);
  }
  await history.acknowledge('divar', 'old-receiver-ad', 'duplicates');
  const restored = new ImportLedger(path, endpoint); await restored.load();
  assert.equal(restored.has('divar', 'old-receiver-ad'), true);
  assert.equal(restored.has('divar', 'retry-ad'), false);
}));

test('one imported position does not suppress the other positions of an ad', async () => withHistory(async path => {
  const history = new ImportLedger(path, endpoint);
  await history.load();
  await history.acknowledge('e-estekhdam', 'kabc123-pos-accountant', 'accepted');
  assert.equal(history.has('e-estekhdam', 'kabc123'), false);
  assert.equal(history.has('e-estekhdam', 'kabc123-pos-driver'), false);
}));

test('corrupt or wrong-site history fails before it can silently import repeated ads', async () => withHistory(async path => {
  await writeFile(path, '{bad json');
  await assert.rejects(new ImportLedger(path, endpoint).load());
  const history = new ImportLedger(path, endpoint);
  await rm(path);
  await history.load();
  await history.acknowledge('divar', 'id', 'accepted');
  await assert.rejects(new ImportLedger(path, 'https://another-site.example/batch').load(), /another receiver/);
}));

test('daily policy accepts a fresh unseen ad but rejects ads older than 24 hours', () => {
  const now = Date.parse('2026-10-05T09:00:00Z');
  assert.equal(freshnessDecision({publishedAt:'2026-10-05T07:00:00Z'}, {}, 1, true, now).allow,true);
  assert.equal(freshnessDecision({publishedAt:'2026-10-04T08:59:00Z'}, {}, 1, true, now).allow,false);
  assert.equal(freshnessDecision({publishedRelative:'پریروز'}, {}, 1, true, now).allow,false);
});
