# QazvinJobs Import Crawler 0.6.4

## اصلاح پایداری ارتباط با Import Hub

- ارسال هر آگهی به وردپرس در خطاهای موقت شبکه، HTTP 5xx و 429 تا ۴ بار Retry می‌شود.
- Timeout ارسال به Import Hub از ۲۵ به ۳۰ ثانیه افزایش یافت.
- ارسال گزارش نهایی Diagnostics نیز تا ۴ بار Retry می‌شود.
- اگر فقط ارسال Diagnostics در پایان اجرا به دلیل Connect Timeout شکست بخورد، اجرای اصلی دیگر با Exit Code 1 خراب نمی‌شود؛ خطا در Log ثبت می‌شود و Workflow می‌تواند سبز بماند.
- شماره نسخه در User-Agent، payload، diagnostics و فایل‌های تشخیصی با 0.6.4 هماهنگ شد.
- اصلاحات 0.6.3 مربوط به تازگی آگهی‌های ای‌استخدام و نمایش شماره تماس بدون تغییر حفظ شده‌اند.

این نسخه برای خطای `UND_ERR_CONNECT_TIMEOUT` هنگام ارسال نهایی Diagnostics به `qazvinjobs.ir:443` ساخته شده است.
