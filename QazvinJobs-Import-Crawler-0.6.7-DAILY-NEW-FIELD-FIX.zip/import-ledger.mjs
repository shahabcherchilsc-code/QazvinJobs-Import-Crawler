import { readFile, mkdir, writeFile, rename } from 'node:fs/promises';
import { dirname } from 'node:path';
import { createHash } from 'node:crypto';

// Store only source IDs and acknowledgment time, never phone numbers or tokens.
export class ImportLedger {
  constructor(path, endpoint) {
    this.path = path;
    this.siteKey = createHash('sha256').update(String(endpoint)).digest('hex');
    this.entries = {};
    this.queue = Promise.resolve();
  }
  async load() {
    if (!this.path) return;
    let raw;
    try { raw = await readFile(this.path, 'utf8'); }
    catch (error) { if (error.code === 'ENOENT') return; throw error; }
    const state = JSON.parse(raw);
    if (state?.version !== 1 || state.site_key !== this.siteKey || !state.entries || Array.isArray(state.entries) || typeof state.entries !== 'object') {
      throw new Error('Import history is invalid or belongs to another receiver. Restore the correct history before crawling.');
    }
    if (Object.values(state.entries).some(value => !Number.isFinite(value) || value < 0)) throw new Error('Import history contains invalid acknowledgment times.');
    this.entries = state.entries;
  }
  has(source, sourceId) { return Object.hasOwn(this.entries, `${source}:${sourceId}`); }
  async acknowledge(source, sourceId, status, now = Date.now()) {
    // Failed, rejected and uncertain requests must remain eligible for a future run.
    if (!source || !sourceId || !['accepted', 'duplicates'].includes(status)) return false;
    this.entries[`${source}:${sourceId}`] = now;
    if (this.path) {
      this.queue = this.queue.then(async () => {
        await mkdir(dirname(this.path), { recursive: true });
        await writeFile(`${this.path}.tmp`, JSON.stringify({ version: 1, site_key: this.siteKey, entries: this.entries }) + '\n', { mode: 0o600 });
        await rename(`${this.path}.tmp`, this.path);
      });
      await this.queue;
    }
    return true;
  }
}
