import { freshnessDecision, sourceTimestamp } from './freshness.mjs';

// Export only stable public source identifiers, never query strings or slug text.
export function identity(value) {
  const u = new URL(value);
  if (u.protocol !== 'https:' || u.username || u.password || u.port) throw new Error('invalid_source_url');
  const host = u.hostname.toLowerCase().replace(/^www\./, '');
  if (host === 'e-estekhdam.com') {
    const m = u.pathname.match(/^\/(k[a-z0-9]+)(?:-|\/|$)/i);
    if (m) return { source: 'e-estekhdam', id: m[1].toLowerCase(), url: `https://www.e-estekhdam.com/${m[1].toLowerCase()}` };
  }
  if (host === 'divar.ir' && /^\/v\//.test(u.pathname)) {
    const parts = decodeURIComponent(u.pathname).split('/').filter(Boolean);
    if (parts.length >= 2 && parts.length <= 3 && /^[a-z0-9_-]{5,}$/i.test(parts.at(-1))) {
      const token = parts.at(-1);
      return { source: 'divar', id: `divar-${token.toLowerCase()}`, url: `https://divar.ir/v/${token}` };
    }
  }
  throw new Error('invalid_source_url');
}

export function redact(value) {
  return String(value || '').replace(/[۰-۹٠-٩]/g, c => String('۰۱۲۳۴۵۶۷۸۹'.includes(c) ? '۰۱۲۳۴۵۶۷۸۹'.indexOf(c) : '٠١٢٣٤٥٦٧٨٩'.indexOf(c)))
    .replace(/https?:\/\/\S+|[\w.+-]+@[\w.-]+\.[a-z]{2,}|@[\w.-]+/gi, '[redacted]')
    .replace(/(?:\+?\d[\s().-]*){8,}/g, '[redacted]')
    .replace(/[\u0000-\u001f\u007f\u202a-\u202e]/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 180);
}

export function auditRecord(own, data, card, entries, now = Date.now()) {
  const verdict = freshnessDecision(data, card, 1, true, now, 'today_yesterday');
  const relative = redact(data.publishedRelative);
  // This is an ambiguity warning, not a replacement production date filter.
  const exactRelative = /^(?:(?:امروز|دیروز|پریروز)|(?:\d+|یک)\s*(?:دقیقه|ساعت|روز|هفته|ماه|سال)\s*(?:پیش|قبل)|لحظات(?:ی)?\s*پیش|دقایق(?:ی)?\s*پیش)(?:\s+در\s+.{1,65})?$/u.test(relative);
  const timestamp = sourceTimestamp(data.publishedAt);
  const priorPositions = Object.keys(entries).filter(k => k.startsWith(`${own.source}:${own.id}-pos-`)).length;
  return {
    source: own.source, source_id: own.id, source_url: own.url,
    published_at: timestamp === null ? '' : new Date(timestamp).toISOString(),
    relative_evidence: relative, relative_evidence_kind: !relative ? 'absent' : exactRelative ? 'date_phrase' : 'ambiguous_text',
    detail_date_present: timestamp !== null,
    card_age_days: Number.isFinite(card?.ageDays) ? card.ageDays : null,
    decision: { allow: verdict.allow, reason: verdict.reason, age_days: verdict.ageDays, day_difference: verdict.dayDifference ?? null },
    warning: timestamp === null && relative && !exactRelative ? 'ambiguous_relative_date' : '',
    page_id_acknowledged: Object.hasOwn(entries, `${own.source}:${own.id}`),
    acknowledged_position_ids: priorPositions,
    status: data.title ? 'parsed' : 'missing_title'
  };
}

// Unauthenticated source browsing only. No receiver requests, contacts, sessions,
// analytics, service workers or POST requests are allowed by this audit context.
export function allowRequest(url, method, resourceType) {
  if (!['GET', 'HEAD'].includes(method) || ['image', 'font', 'media'].includes(resourceType)) return false;
  try {
    const u = new URL(url);
    return u.protocol === 'https:' && !u.username && !u.password && !u.port
      && /(^|\.)(?:e-estekhdam\.com|divar\.ir|divarcdn\.com)$/.test(u.hostname)
      && !/\/(?:contact|chat|login|auth|otp)(?:[/?_-]|$)/i.test(u.pathname);
  } catch { return false; }
}
