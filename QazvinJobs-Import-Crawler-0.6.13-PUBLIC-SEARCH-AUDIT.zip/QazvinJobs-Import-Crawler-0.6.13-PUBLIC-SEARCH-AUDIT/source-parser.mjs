// Shared production parser; the audit never imports crawler.mjs.
import { resolveEmployerEvidence } from './employer-evidence.mjs';

export async function extractJob(page, source) {
 const data = await page.evaluate(({ source }) => {
 const clean = value => String(value || '')
 .replace(/[\u200c\u200f\u202a-\u202e]/g, ' ')
 .replace(/\s+/g, ' ')
 .trim();
 const cleanMultiline = value => String(value || '')
 .replace(/&nbsp;|\u00a0/gi, ' ')
 .replace(/[\u200f\u202a-\u202e]/g, '')
 .replace(/[ \t]+/g, ' ')
 .replace(/ *\n */g, '\n')
 .replace(/\n{3,}/g, '\n\n')
 .trim();
 const htmlToMultilineText = html => {
   if (!html) return '';
   const holder = document.createElement('div');
   holder.innerHTML = String(html);
   for (const br of holder.querySelectorAll('br')) br.replaceWith('\n');
   for (const el of holder.querySelectorAll('p,li,h1,h2,h3,h4,div,section')) el.append('\n');
   return cleanMultiline(holder.textContent || '');
 };

 // IMPORTANT: page.evaluate() runs in the browser context. Any helper used
 // below must be declared inside this callback and cannot reference Node-side
 // functions. Keep Persian/Arabic digit normalization local to this scope.
 const toEnglishDigitsLocal = value => String(value || '').replace(/[۰-۹٠-٩]/g, ch => {
   const p = '۰۱۲۳۴۵۶۷۸۹'.indexOf(ch);
   if (p >= 0) return String(p);
   const a = '٠١٢٣٤٥٦٧٨٩'.indexOf(ch);
   return a >= 0 ? String(a) : ch;
 });

 const normalizeLabel = value => clean(value)
 .normalize('NFKC')
 .replace(/[\u064B-\u065F\u0670\u06D6-\u06ED]/g, '')
 .replace(/[يى]/g, 'ی')
 .replace(/ك/g, 'ک')
 .replace(/[：:]+$/g, '')
 .replace(/\s+/g, ' ')
 .trim();

 const firstText = selectors => {
   for (const selector of selectors) {
     const node = document.querySelector(selector);
     const value = clean(node?.innerText || node?.textContent || '');
     if (value) return value;
   }
   return '';
 };

 // Parse JobPosting JSON-LD before touching generic page text.
 let jobPosting = {};
 for (const node of document.querySelectorAll('script[type="application/ld+json"]')) {
   try {
     const parsed = JSON.parse(node.textContent || '{}');
     const rows = Array.isArray(parsed) ? parsed : (Array.isArray(parsed?.['@graph']) ? parsed['@graph'] : [parsed]);
     const found = rows.find(row => {
       const type = row?.['@type'];
       return type === 'JobPosting' || (Array.isArray(type) && type.includes('JobPosting'));
     });
     if (found) { jobPosting = found; break; }
   } catch {}
 }

 let title = clean(
   document.querySelector('h1')?.innerText ||
   jobPosting?.title ||
   document.querySelector('meta[property="og:title"]')?.content ||
   document.title
 );
 // Some E-Estekhdam templates include the relative publish time inside the same
 // visual H1 container (e.g. «کارگر انبار ۲ روز پیش»). It is metadata, never
 // part of the vacancy title. Strip it at extraction time so every downstream
 // field/source-id sees the real title only.
 title = title
 .replace(/\s*[-–|].*ای\s*استخدام.*$/i, '')
 .replace(/\s*[-–|].*دیوار.*$/i, '')
 .replace(/\s+(?:امروز|دیروز|پریروز|[۰-۹0-9]+\s*(?:دقیقه|ساعت|روز|هفته|ماه)\s*پیش)\s*$/u, '')
 .trim();

 const selectors = source === 'divar'
      ? ['main article','main','article','[class*="post-page"]','[class*="kt-page"]','body']
      : ['main article','article','main','[class*="job-detail"]','[class*="jobDetail"]','[class*="advertisement"]','body'];

 let root = document.body;
 for (const selector of selectors) {
   const node = document.querySelector(selector);
   const text = clean(node?.innerText || node?.textContent || '');
   if (node && text.length > 180 && (selector === 'body' || node.querySelector('h1'))) { root = node; break; }
 }

 // Parse a temporary rendered copy of the current ad only. The source page stays intact.
 const originalRoot = root;
 root = originalRoot.cloneNode(true);
 for (const node of root.querySelectorAll('nav,aside,footer,[class*="similar" i],[class*="recommend" i],[class*="related" i]')) node.remove();
 const relatedHeading = Array.from(root.querySelectorAll('h2,h3,h4,h5,p,span,div')).find(node =>
   /^(?:آگهی های (?:استخدام )?(?:مشابه|مرتبط|پیشنهادی)|فرصت های شغلی مشابه|استخدام های مشابه)$/u.test(normalizeLabel(node.innerText || node.textContent || ''))
 );
 if (relatedHeading) {
   const range = document.createRange();
   range.selectNodeContents(root);
   range.setStartBefore(relatedHeading);
   range.deleteContents();
 }
 root.style.cssText += ';position:absolute;left:-20000px;top:0;width:1200px;';
 document.body.appendChild(root);
 const rawBodyText = String(document.body?.innerText || document.body?.textContent || '');
 const bodyText = clean(rawBodyText);
 const bodyLines = String(root.innerText || root.textContent || '').split(/\n+/).map(clean).filter(Boolean);
 const rootRawText = String(root?.innerText || root?.textContent || '');
 const rootLines = rootRawText.split(/\n+/).map(clean).filter(Boolean);
 const contentText = clean(rootRawText || bodyText);
 const contentHtml = root?.innerHTML || '';

 // Exact adjacent-line parsing accepts an explicit line scope. E-Estekhdam
 // keeps the historical page scope; Divar is restricted to the current-ad
 // portion so related/recommended cards cannot become vacancy facts.
 const lineValueAfter = (labels, lines = bodyLines) => {
   const wanted = (Array.isArray(labels) ? labels : [labels]).map(normalizeLabel);
   for (let i = 0; i < lines.length - 1; i++) {
     if (wanted.includes(normalizeLabel(lines[i]))) {
       const value = clean(lines[i + 1]);
       if (value && value.length <= 300 && !knownLabels.some(k => normalizeLabel(k) === normalizeLabel(value))) return value;
     }
   }
   return '';
 };
 const nearbyDomValue = (labels) => {
   const wanted = (Array.isArray(labels) ? labels : [labels]).map(normalizeLabel);
   const nodes = Array.from((root || document).querySelectorAll('div,li,section,p,span,dt,dd,td,th'));
   for (const node of nodes) {
     const own = clean(node.innerText || node.textContent || '');
     if (!own || own.length > 180) continue;
     const kids = Array.from(node.children || []).map(x => clean(x.innerText || x.textContent || '')).filter(Boolean);
     if (kids.length >= 2) {
       for (let i=0;i<kids.length;i++) {
         if (wanted.includes(normalizeLabel(kids[i]))) {
           const candidates = kids.slice(i+1).filter(v => v && !wanted.includes(normalizeLabel(v)) && v.length <= 120);
           if (candidates[0]) return candidates[0];
         }
       }
     }
     for (const label of wanted) {
       const re = new RegExp(`^${label.replace(/[.*+?^${}()|[\]\\]/g,'\\$&')}\\s*[:：-]?\\s*(.+)$`,'u');
       const m = normalizeLabel(own).match(re);
       if (m && m[1] && m[1].length <= 120) return clean(m[1]);
     }
   }
   return '';
 };
 const sectionLines = (startLabels, stopLabels, lines = bodyLines) => {
   const starts = (Array.isArray(startLabels) ? startLabels : [startLabels]).map(normalizeLabel);
   const stops = (Array.isArray(stopLabels) ? stopLabels : [stopLabels]).map(normalizeLabel);
   let start = -1;
   for (let i = 0; i < lines.length; i++) {
     if (starts.includes(normalizeLabel(lines[i]))) { start = i + 1; break; }
   }
   if (start < 0) return '';
   const out = [];
   for (let i = start; i < lines.length; i++) {
     const label = normalizeLabel(lines[i]);
     if (stops.includes(label) || /^(?:آگهی های (?:استخدام )?(?:مشابه|مرتبط|پیشنهادی)|فرصت های شغلی مشابه)$/u.test(label)) break;
     if (lines[i]) out.push(lines[i]);
     if (out.length >= 1000 || out.join(' ').length >= 50000) break;
   }
   return clean(out.join(' • '));
 };
 const divarStopLabels = new Set([
   'آگهی‌های مشابه','آگهی های مشابه','آگهی‌های مرتبط','آگهی های مرتبط',
   'آگهی‌های پیشنهادی','آگهی های پیشنهادی','لینک های مرتبط','لینک‌های مرتبط'
 ].map(normalizeLabel));
 let divarAdLines = rootLines;
 if (source === 'divar') {
   const stopIndex = rootLines.findIndex(line => {
     const normalized = normalizeLabel(line);
     return [...divarStopLabels].some(stop => normalized === stop || normalized.startsWith(`${stop} `));
   });
   if (stopIndex > 0) divarAdLines = rootLines.slice(0, stopIndex);
 }

 // Build a conservative label/value map. Only short, local rows are accepted,
 // which prevents "similar jobs" cards from becoming job facts.
 const labelValues = {};
 const knownLabels = [
   'نوع همکاری','نوع قرارداد','نحوه حضور','شیوه پرداخت','روش پرداخت','حقوق','حقوق ماهانه','بازه حقوق','سابقه کار','سابقه','سابقه مورد نیاز','سابقه موردنیاز',
   'تحصیلات','حداقل تحصیلات','رشته تحصیلی','جنسیت','سن','بازه سنی','وضعیت سربازی','پایان خدمت/معافیت','پایان خدمت / معافیت',
   'تعداد نیروی مورد نیاز','تعداد نیروی موردنیاز','تعداد نفر','سطح شغلی','شیفت کاری',
   'ساعات کاری','ساعت کاری','روزهای کاری','بیمه','با بیمه','امکان دورکاری','با امکان دورکاری','محل کار','موقعیت مکانی','آدرس',
   'مزایا','تسهیلات و مزایا','سایر مزایا','مهارت‌ها','مهارت های مورد نیاز','مهارت‌های مورد نیاز','شرح وظایف','شرایط احراز',
   'حوزه فعالیت','نام شرکت','نام مجموعه','مهلت ارسال رزومه','مهلت درخواست','زمان شروع همکاری','زمان‌بندی جذب',
   'دوره آزمایشی','اضافه کاری','اضافه‌کاری','مراحل مصاحبه','روش مصاحبه','مهارت‌های رفتاری','مهارت های رفتاری',
   'امکان همکاری با افراد دارای معلولیت','محیط اصلی کار','محیط کار','مدارک لازم برای درخواست','مدارک مورد نیاز',
   'حداقل مدرک تحصیلی','مدرک تحصیلی'
 ];
 const candidates = source === 'divar'
   ? []
   : Array.from(root?.querySelectorAll?.('tr,li,dl,div,p,section') || []);
 for (const node of candidates) {
   const text = clean(node.innerText || node.textContent || '');
   if (!text || text.length > 800) continue;
   const children = Array.from(node.children || []).map(ch => clean(ch.innerText || ch.textContent || '')).filter(Boolean);
   if (children.length >= 2 && children.length <= 6) {
     const label = normalizeLabel(children[0]);
     const matched = knownLabels.find(k => { const nk = normalizeLabel(k); return label === nk || label.startsWith(`${nk} `); });
     if (matched) {
       const value = clean(children.slice(1).join(' '));
       if (value && value !== label && value.length <= 500 && !labelValues[matched]) labelValues[matched] = value;
     }
   }
   const colon = text.match(/^([^:：]{2,40})[:：]\s*(.{1,500})$/);
   if (colon) {
     const label = normalizeLabel(colon[1]);
     const matched = knownLabels.find(k => { const nk = normalizeLabel(k); return label === nk || label.startsWith(`${nk} `); });
     if (matched && !labelValues[matched]) labelValues[matched] = clean(colon[2]);
   }
 }

 // Divar is intentionally line-scoped rather than DOM-wide. Recommended cards
 // often live under the same <main>; accepting their chips would silently fill
 // missing fields with another vacancy's facts. Prefer an empty field over a
 // false value, because WordPress keeps the import as a reviewable draft.
 if (source === 'divar') {
   const booleanLabels = new Set(['با بیمه','با امکان دورکاری'].map(normalizeLabel));
   for (const key of knownLabels) {
     if (booleanLabels.has(normalizeLabel(key))) continue;
     const value = lineValueAfter(key, divarAdLines);
     if (value && !labelValues[key]) labelValues[key] = value;
   }
   for (const line of divarAdLines) {
     if (!line || line.length > 520) continue;
     const colon = line.match(/^([^:：]{2,40})[:：]\s*(.{1,500})$/);
     if (colon) {
       const label = normalizeLabel(colon[1]);
       const matched = knownLabels.find(k => normalizeLabel(k) === label);
       if (matched && !labelValues[matched]) labelValues[matched] = clean(colon[2]);
       continue;
     }
     const normalized = normalizeLabel(line);
     const matched = knownLabels
       .map(k => [k, normalizeLabel(k)])
       .filter(([,nk]) => !booleanLabels.has(nk) && normalized.startsWith(`${nk} `))
       .sort((a,b) => b[1].length - a[1].length)[0];
     if (matched) {
       const value = clean(normalized.slice(matched[1].length));
       if (value && value.length <= 300 && !labelValues[matched[0]]) labelValues[matched[0]] = value;
     }
   }
 }

 // Source-specific exact facts for E-Estekhdam. These values come from
 // the ad fact chips/sections, not from similar-job cards or page-wide guesses.
 if (source === 'e-estekhdam') {
   const exactFactValue = labels => {
     const wanted = (Array.isArray(labels) ? labels : [labels]).map(normalizeLabel);
     // 1) Exact adjacent lines from the rendered source.
     const lineValue = lineValueAfter(labels);
     if (lineValue) return lineValue;
     // 2) A compact fact-card where label/value are sibling descendants.
     const all = Array.from((root || document).querySelectorAll('div,li,section,article,dl,dt,dd,p,span'));
     for (const node of all) {
       const own = clean(node.innerText || node.textContent || '');
       if (!own || own.length > 360) continue;
       const descendants = Array.from(node.querySelectorAll?.('span,p,div,dt,dd,strong,b') || [])
         .map(x => clean(x.innerText || x.textContent || ''))
         .filter(Boolean);
       for (let i=0;i<descendants.length;i++) {
         if (!wanted.includes(normalizeLabel(descendants[i]))) continue;
         for (let j=i+1;j<Math.min(descendants.length,i+5);j++) {
           const candidate = clean(descendants[j]);
           if (!candidate || wanted.includes(normalizeLabel(candidate)) || candidate.length > 140) continue;
           if (/^(?:استان|شهر|جنسیت|سابقه کار|نوع همکاری|حقوق ماهانه|حقوق)$/u.test(normalizeLabel(candidate))) continue;
           return candidate;
         }
       }
       const normalizedOwn = normalizeLabel(own);
       for (const label of wanted) {
         if (normalizedOwn.startsWith(label + ' ')) {
           const candidate = clean(own.slice(own.indexOf(' ') + 1));
           if (candidate && candidate.length <= 140) return clean(normalizedOwn.slice(label.length));
         }
       }
     }
     return nearbyDomValue(labels);
   };
   const exactPairs = {
     'استان': exactFactValue('استان'),
     'شهر': exactFactValue('شهر'),
     'جنسیت': exactFactValue('جنسیت'),
     'سابقه کار': exactFactValue('سابقه کار'),
     'نوع همکاری': exactFactValue('نوع همکاری'),
     'نحوه حضور': exactFactValue('نحوه حضور'),
     'حقوق ماهانه': exactFactValue(['حقوق ماهانه','حقوق']),
     'حداقل تحصیلات': lineValueAfter(['حداقل تحصیلات','حداقل مدرک تحصیلی','مدرک تحصیلی','تحصیلات']),
     'رشته تحصیلی': lineValueAfter('رشته تحصیلی'),
     'نوع قرارداد': lineValueAfter('نوع قرارداد'),
     'شیفت کاری': lineValueAfter('شیفت کاری'),
     'ساعات کاری': exactFactValue(['ساعات کاری','ساعت کاری']),
     'روزهای کاری': exactFactValue('روزهای کاری'),
     'تعداد نیروی مورد نیاز': lineValueAfter(['تعداد نیروی مورد نیاز','تعداد نیروی موردنیاز','تعداد نفر']),
     'سطح شغلی': lineValueAfter('سطح شغلی'),
     'وضعیت سربازی': lineValueAfter('وضعیت سربازی'),
     'بازه سنی': lineValueAfter(['بازه سنی','سن']),
     'دوره آزمایشی': lineValueAfter('دوره آزمایشی'),
     'اضافه‌کاری': lineValueAfter(['اضافه‌کاری','اضافه کاری']),
     'مراحل مصاحبه': lineValueAfter(['مراحل مصاحبه','روش مصاحبه']),
     'مهلت ارسال رزومه': lineValueAfter(['مهلت ارسال رزومه','مهلت درخواست']),
     'مهارت‌های رفتاری': lineValueAfter(['مهارت‌های رفتاری','مهارت های رفتاری']),
     'امکان همکاری با افراد دارای معلولیت': lineValueAfter('امکان همکاری با افراد دارای معلولیت'),
     'محیط اصلی کار': lineValueAfter(['محیط اصلی کار','محیط کار']),
     'مدارک لازم برای درخواست': lineValueAfter(['مدارک لازم برای درخواست','مدارک مورد نیاز'])
   };
   for (const [k,v] of Object.entries(exactPairs)) if (v) labelValues[k] = v;
   const req = sectionLines(['شرایط احراز'], ['ساعات کاری','ساعت کاری','شرح وظایف','تسهیلات و مزایا','سایر مزایا','محل کار','اطلاعات تماس']);
   const benefitsPrimary = sectionLines(['تسهیلات و مزایا'], ['سایر مزایا','محل کار','اطلاعات تماس','آگهی‌های استخدام مشابه','آگهی های استخدام مشابه']);
   const benefitsOther = sectionLines(['سایر مزایا'], ['محل کار','اطلاعات تماس','آگهی‌های استخدام مشابه','آگهی های استخدام مشابه']);
   const benefitsSection = clean([...new Set([benefitsPrimary, benefitsOther].filter(Boolean))].join(' • '));
   const locationSection = sectionLines(['محل کار'], ['اطلاعات تماس','آگهی‌های استخدام مشابه','آگهی های استخدام مشابه']);
   if (req) labelValues['شرایط احراز'] = req;
   if (benefitsSection) {
     labelValues['مزایا'] = benefitsSection;
     labelValues['تسهیلات و مزایا'] = benefitsSection;
   }
   if (locationSection) labelValues['محل کار'] = locationSection;
   const addressLine = bodyLines.find(line => /^آدرس\s*[:：]?\s*\S/u.test(line));
   const addressFromSection = (locationSection.match(/(?:^|[•\n])\s*آدرس\s*[:：]?\s*([^•\n]{3,500})/u) || [])[1] || '';
   const exactAddress = clean(addressLine ? addressLine.replace(/^آدرس\s*[:：]?\s*/u,'') : addressFromSection);
   if (exactAddress) labelValues['آدرس'] = exactAddress;
 }

 // Divar's current jobs UI uses these labels (including diacritics on some
 // surfaces). Read exact adjacent values as a second conservative source.
 if (source === 'divar') {
   const exactPairs = {
     'نوع همکاری': lineValueAfter('نوع همکاری', divarAdLines),
     'شیوه پرداخت': lineValueAfter(['شیوه پرداخت','روش پرداخت'], divarAdLines),
     'حقوق': lineValueAfter(['حقوق','حقوق ماهانه','بازه حقوق'], divarAdLines),
     'سابقه مورد نیاز': lineValueAfter(['سابقه مورد نیاز','سابقه موردنیاز'], divarAdLines),
     'پایان خدمت/معافیت': lineValueAfter(['پایان خدمت/معافیت','پایان خدمت / معافیت'], divarAdLines),
     'بیمه': lineValueAfter('بیمه', divarAdLines),
     'امکان دورکاری': lineValueAfter('امکان دورکاری', divarAdLines)
   };
   // Source-scoped Divar facts take precedence over generic DOM candidates.
   for (const [k,v] of Object.entries(exactPairs)) if (v) labelValues[k] = v;
 }

 let eEstekhdamDescription = '';
 let eEstekhdamRequirements = '';
 let eEstekhdamBenefits = '';
 let eEstekhdamWorkHours = '';
 let eEstekhdamAddress = '';
 let eEstekhdamIntroLine = '';
 if (source === 'e-estekhdam') {
   // Deterministic source sections only. If a section is absent, leave it empty
   // rather than borrowing text from nearby cards/similar vacancies.
   eEstekhdamRequirements = cleanMultiline(String(
     labelValues['شرایط احراز'] ||
     sectionLines(['شرایط احراز'], ['ساعات کاری','ساعت کاری','تسهیلات و مزایا','سایر مزایا','محل کار','اطلاعات تماس']) ||
     ''
   ).replace(/\s*•\s*/g, '\n'));

   const benefitA = labelValues['تسهیلات و مزایا'] ||
     sectionLines(['تسهیلات و مزایا'], ['سایر مزایا','محل کار','اطلاعات تماس','آگهی‌های استخدام مشابه','آگهی های استخدام مشابه']) || '';
   const benefitB = labelValues['سایر مزایا'] ||
     sectionLines(['سایر مزایا'], ['محل کار','اطلاعات تماس','آگهی‌های استخدام مشابه','آگهی های استخدام مشابه']) || '';
   eEstekhdamBenefits = cleanMultiline([benefitA, benefitB].filter(Boolean).join('\n').replace(/\s*•\s*/g, '\n'));

   eEstekhdamWorkHours = cleanMultiline(String(
     labelValues['ساعات کاری'] || labelValues['ساعت کاری'] ||
     sectionLines(['ساعات کاری','ساعت کاری'], ['تسهیلات و مزایا','سایر مزایا','محل کار','اطلاعات تماس']) || ''
   ).replace(/\s*•\s*/g, '\n'));

   eEstekhdamAddress = cleanMultiline(String(
     labelValues['آدرس'] || labelValues['محل کار'] ||
     sectionLines(['محل کار'], ['اطلاعات تماس','آگهی‌های استخدام مشابه','آگهی های استخدام مشابه']) || ''
   ).replace(/\s*•\s*/g, '\n'));

   // The introductory company sentence on E-Estekhdam is normally the first
   // meaningful prose line below the title/date. Capture only an explicit hiring
   // sentence; never guess a company from arbitrary body text.
   const introCandidates = rootLines
     .map(clean)
     .filter(line => line && line.length >= 8 && line.length <= 420)
     .filter(line => !/(?:آگهی‌های استخدام مشابه|آگهی های استخدام مشابه|اطلاعات تماس|ثبت نام|ورود)/u.test(line));
   // First meaningful intro line is retained. Company extraction remains
   // deterministic and only accepts explicit separators.
   eEstekhdamIntroLine = introCandidates.find(line => /(?:شرکت|مجموعه|کارخانه|فروشگاه|کلینیک|رستوران|موسسه|مؤسسه).*(?:جهت|برای|دعوت|استخدام)/u.test(line)) || '';

   const sourceSections = [];
   const pushSection = (heading, value) => {
     const v = cleanMultiline(value);
     if (v) sourceSections.push(`${heading}\n${v}`);
   };
   pushSection('شرایط احراز', eEstekhdamRequirements);
   pushSection('ساعات کاری', eEstekhdamWorkHours);
   pushSection('تسهیلات و مزایا', eEstekhdamBenefits);
   pushSection('محل کار', eEstekhdamAddress);
   eEstekhdamDescription = cleanMultiline(sourceSections.join('\n\n'));

   // Only when the explicit sections are genuinely absent, keep an exact source
   // description fallback. It is never mixed with generated prose.
   if (!eEstekhdamDescription && jobPosting?.description) {
     eEstekhdamDescription = htmlToMultilineText(jobPosting.description);
   }
   if (!eEstekhdamDescription) {
     const sourceOnly = sectionLines(
       ['شرح شغل','شرح موقعیت شغلی','توضیحات'],
       ['آگهی‌های استخدام مشابه','آگهی های استخدام مشابه','اطلاعات تماس']
     );
     eEstekhdamDescription = cleanMultiline(String(sourceOnly || '').replace(/\s*•\s*/g, '\n'));
   }
 }

 const divarDescription = source === 'divar'
   ? sectionLines(
       ['توضیحات','شرح آگهی'],
       ['اطلاعات تماس','چت و تماس','گزارش آگهی','نکات امنیتی','آگهی‌های مشابه','آگهی های مشابه','آگهی‌های مرتبط','آگهی های مرتبط'],
       divarAdLines
     ) || htmlToMultilineText(jobPosting?.description || '')
   : '';

 const extractCompanyFromHiringLine = line => {
   const value = clean(line || '');
   if (!value) return '';
   const generic = /^(?:یک\s+)?(?:مجموعه|شرکت|کارفرما|آگهی[‌ -]*دهنده)(?:\s+معتبر)?$/u;
   const patterns = [
     /^(.{2,100}?)\s+(?:به\s+منظور|جهت|برای|در\s+(?:استان|شهر)|استخدام|دعوت\s+به\s+همکاری)/u,
     /^(?:شرکت|مجموعه|فروشگاه|کارخانه|رستوران|کافه|کلینیک|آزمایشگاه|موسسه|مؤسسه|گروه)\s+(.{2,120}?)\s+(?:در\s+(?:استان|شهر)|جهت\s+تکمیل\s+کادر|دعوت\s+به\s+همکاری|استخدام)/u,
     /^(.{2,140}?)\s+در\s+استان\s+قزوین(?:،|,|\s)/u,
     /^(.{2,140}?)\s+جهت\s+تکمیل\s+کادر/u
   ];
   for (const re of patterns) {
     const m = value.match(re);
     let candidate = clean(m?.[1] || '');
     candidate = candidate.replace(/^استخدام\s+/u,'').replace(/^(?:شرکت|مجموعه)\s+/u,'').trim();
     if (candidate && candidate.length <= 140 && !generic.test(candidate) && !/^(?:یک\s+مجموعه\s+معتبر|مجموعه\s+معتبر)$/u.test(candidate)) return candidate;
   }
   return '';
 };
 const divarIntroCompany = source === 'divar'
   ? (() => {
       const firstLines = cleanMultiline(divarDescription).split('\n').map(clean).filter(Boolean).slice(0, 4);
       for (const line of firstLines) {
         const found = extractCompanyFromHiringLine(line);
         if (found) return found;
       }
       return '';
     })()
   : '';

 const jsonAddress = jobPosting?.jobLocation?.address || jobPosting?.jobLocation?.[0]?.address || {};
 const cityExact = clean(
   labelValues['شهر'] ||
   jsonAddress?.addressLocality ||
   jsonAddress?.addressRegion ||
   labelValues['موقعیت مکانی'] ||
   labelValues['محل کار'] ||
   ''
 );
 const genericCompany = /^(?:آگهی[‌ -]*دهنده(?:\s+مستقیم)?|کارفرما|شرکت|مجموعه|مجموعه\s+معتبر|یک\s+مجموعه\s+معتبر|ای[‌ -]*استخدام|e[ -]?estekhdam|نامشخص)$/iu;
 const jsonCompany = clean(jobPosting?.hiringOrganization?.name || '');
 const explicitCompany = clean(labelValues['نام شرکت'] || labelValues['نام مجموعه'] || '');
 const eEstekhdamIntroCompany = source === 'e-estekhdam' ? extractCompanyFromHiringLine(eEstekhdamIntroLine) : '';
 const companyName = clean(
   (!genericCompany.test(explicitCompany) ? explicitCompany : '') ||
   (!genericCompany.test(jsonCompany) ? jsonCompany : '') ||
   eEstekhdamIntroCompany ||
   divarIntroCompany ||
   ''
 );
 const sourceCategory = clean(
   jobPosting?.occupationalCategory ||
   firstText([
     '[class*="job-category"]','[class*="category"] [class*="active"]',
     'nav[aria-label*="breadcrumb" i] a:nth-last-of-type(2)',
     '[class*="breadcrumb" i] a:nth-last-of-type(2)'
   ])
 );

 const metaDescription = clean(
   document.querySelector('meta[property="og:description"]')?.content ||
   document.querySelector('meta[name="description"]')?.content ||
   ''
 );
 // locationText is diagnostic only in 0.3.18. It is never used as the primary
 // city source because generic body/breadcrumb text can include other cities.
 const locationText = clean(`${cityExact} ${labelValues['آدرس'] || ''} ${metaDescription}`);

 const markerRegex = /اطلاعات تماس|نحوه ارتباط|راه ارتباطی|شماره تماس|موبایل|تلفن|واتس.?اپ|تلگرام|ایمیل|چت و تماس/i;
 const directContactEvidence = /(?:^|\D)(?:0?9(?:[\s\-().]*\d){9}|0?28(?:[\s\-().]*\d){7,8})(?!\d)|[A-Z0-9._%+-]+@[A-Z0-9.-]+\.[A-Z]{2,}/i;
 const contactSearchRoot = root || document;
 const markerNodes = Array.from(contactSearchRoot.querySelectorAll('h1,h2,h3,h4,strong,b,p,span,div,section,button,a'));
 let contactRoot = null;
 let bestContactScore = -1;
 for (const node of markerNodes) {
   const own = clean(node.innerText || node.textContent || '');
   if (!markerRegex.test(own) || own.length > 350) continue;
   // The marker itself is often only the heading. Start from its parent and
   // choose the smallest nearby container that actually contains a phone/email.
   let current = node.parentElement || node;
   for (let i = 0; i < 5 && current; i++, current = current.parentElement) {
     const text = clean(current.innerText || current.textContent || '');
     if (text.length < 8 || text.length > 7000) continue;
     const links = Array.from(current.querySelectorAll?.('a[href]') || [], a => a.href || '').join(' ');
     const evidence = directContactEvidence.test(toEnglishDigitsLocal(`${text} ${links}`));
     if (!evidence) continue;
     const score = 10000 - text.length;
     if (score > bestContactScore) { bestContactScore = score; contactRoot = current; }
     if (text.length < 1800) break;
   }
 }
 // For E-Estekhdam, absence of an explicit local contact block means there
 // is no direct employer contact. Never fall back to the full page: footer/admin
 // links belong to E-Estekhdam itself and must not qualify the vacancy.
 // No source falls back to the whole page for contact evidence.

 const eContactSectionText = source === 'e-estekhdam'
   ? sectionLines(
       ['اطلاعات تماس','نحوه ارتباط','راه ارتباطی','شماره تماس'],
       ['آگهی‌های استخدام مشابه','آگهی های استخدام مشابه','فرصت‌های شغلی مشابه','فرصت های شغلی مشابه']
     )
   : '';
 // Fallback for E-Estekhdam templates where the visible employer phone is
 // rendered in a normal paragraph/table row without an exact contact heading.
 // Keep only phone/email lines whose immediate neighbours contain contact words.
 const eLocalContactEvidence = source === 'e-estekhdam'
   ? (() => {
       const phoneRe = /(?<!\d)(?:(?:\+|00)?98[\s\-().]*)?(?:0?9(?:[\s\-().]*\d){9}|0?(?!9)\d{2}(?:[\s\-().]*\d){7,8}|[2-9]\d{7})(?!\d)/i;
       const emailRe = /[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/i;
       const contactWords = /(?:اطلاعات\s*تماس|نحوه\s*(?:تماس|ارتباط)|راه\s*ارتباطی|شماره\s*(?:تماس|تلفن|همراه)|تلفن|موبایل|تماس\s*با|واتس.?اپ|پیامک|تلگرام|ایمیل)/i;
       const badSiteWords = /(?:پشتیبانی|روابط\s*عمومی|دفتر\s*مرکزی|ای\s*استخدام|حقوق\s*سایت|قوانین\s*سایت)/i;
       const lines = String(root?.innerText || root?.textContent || '').split(/\n+/).map(clean).filter(Boolean);
       const out = [];
       for (let i = 0; i < lines.length; i++) {
         const current = toEnglishDigitsLocal(lines[i]);
         if (!phoneRe.test(current) && !emailRe.test(lines[i])) continue;
         const around = clean(lines.slice(Math.max(0, i - 2), Math.min(lines.length, i + 3)).join(' | '));
         if (contactWords.test(around) && !badSiteWords.test(around)) out.push(around);
       }
       return clean(out.join(' | '));
     })()
   : '';
 const scopedContactText = clean([contactRoot?.innerText || contactRoot?.textContent || '', eContactSectionText, eLocalContactEvidence].filter(Boolean).join(' '));
 const scopedLinks = Array.from((contactRoot || root)?.querySelectorAll?.('a[href]') || [], a => a.href)
   .filter(href => /^(tel:|sms:|mailto:)|wa\.me|whatsapp|t\.me/i.test(href))
   .filter(href => !/(?:e[-_]?estekhdam|eestekhdam|divar\.ir)/i.test(href));
 const contactLinks = [...new Set(scopedLinks)];
 const contactText = scopedContactText;

 const publishedAt = clean(
   jobPosting?.datePosted ||
   document.querySelector('meta[property="article:published_time"]')?.content ||
   root.querySelector('time[datetime]')?.getAttribute('datetime') ||
   ''
 );
 const publishedRelative = clean(
   (source === 'divar' ? divarAdLines : rootLines).find(line =>
     /(?:لحظات(?:ی)?\s*پیش|دقایق(?:ی)?\s*پیش|امروز|پریروز|دیروز|\d+\s*(?:دقیقه|ساعت|روز|هفته|ماه|سال)\s*(?:پیش|قبل))/u.test(toEnglishDigitsLocal(line))
   ) || ''
 );

 const hasExactRootText = wanted => {
   const target = normalizeLabel(wanted);
   if (source === 'divar') return divarAdLines.some(line => normalizeLabel(line) === target);
   return Array.from(root?.querySelectorAll?.('span,div,p,li,strong,b') || [])
     .some(node => normalizeLabel(node.innerText || node.textContent || '') === target);
 };
 const divarRemoteFlag = source === 'divar'
   ? clean(labelValues['امکان دورکاری'] || labelValues['با امکان دورکاری'] || '')
   : '';
 // Divar's «با امکان دورکاری» is only a boolean capability. It does not prove
 // that the job is explicitly hybrid or fully remote, so preserve the exact
 // source fact without fabricating a canonical workplace_mode.
 const divarRemotePossible = source === 'divar' && (
   /^(?:بله|دارد|فعال|امکان.?پذیر)$/u.test(divarRemoteFlag) ||
   hasExactRootText('با امکان دورکاری')
 ) ? 'بله' : '';
 const divarInsuranceHint = source === 'divar' && hasExactRootText('با بیمه') ? 'بیمه دارد' : '';

 const structured = {
   city_name: cityExact,
   source_city: cityExact,
   source_category: sourceCategory,
   company_name: companyName,
   company_activity: labelValues['حوزه فعالیت'] || clean(jobPosting?.industry || ''),
   source_intro: source === 'e-estekhdam' ? eEstekhdamIntroLine : (cleanMultiline(divarDescription).split('\n').filter(Boolean)[0] || ''),
   company_evidence: companyName ? (source === 'e-estekhdam' ? (eEstekhdamIntroCompany ? 'intro_line' : (!genericCompany.test(jsonCompany) ? 'jsonld' : 'explicit_label')) : (divarIntroCompany ? 'description_first_lines' : 'explicit_label')) : '',
   cooperation_type: labelValues['نوع همکاری'] || labelValues['نوع قرارداد'] || clean(jobPosting?.employmentType || ''),
   contract_type: labelValues['نوع قرارداد'] || '',
   workplace_mode: labelValues['نحوه حضور'] || '',
   remote_possible: divarRemotePossible,
   salary_structure: labelValues['شیوه پرداخت'] || labelValues['روش پرداخت'] || '',
   salary_range: labelValues['بازه حقوق'] || labelValues['حقوق ماهانه'] || labelValues['حقوق'] || '',
   experience_years: labelValues['سابقه کار'] || labelValues['سابقه مورد نیاز'] || labelValues['سابقه موردنیاز'] || labelValues['سابقه'] || labelValues['شرایط احراز'] || clean(jobPosting?.experienceRequirements || ''),
   education_level: labelValues['حداقل تحصیلات'] || labelValues['تحصیلات'] || clean(jobPosting?.educationRequirements || ''),
   study_field: labelValues['رشته تحصیلی'] || '',
   gender_preference: labelValues['جنسیت'] || '',
   age_range: labelValues['بازه سنی'] || labelValues['سن'] || '',
   military_status: labelValues['وضعیت سربازی'] || labelValues['پایان خدمت/معافیت'] || labelValues['پایان خدمت / معافیت'] || '',
   vacancy_count: labelValues['تعداد نیروی مورد نیاز'] || labelValues['تعداد نیروی موردنیاز'] || labelValues['تعداد نفر'] || '',
   seniority_level: labelValues['سطح شغلی'] || '',
   preferred_shift: labelValues['شیفت کاری'] || '',
   work_days: labelValues['روزهای کاری'] || '',
   work_hours: source === 'e-estekhdam' ? eEstekhdamWorkHours : (labelValues['ساعات کاری'] || labelValues['ساعت کاری'] || ''),
   trial_period: labelValues['دوره آزمایشی'] || '',
   overtime: labelValues['اضافه‌کاری'] || labelValues['اضافه کاری'] || '',
   interview_method: labelValues['مراحل مصاحبه'] || labelValues['روش مصاحبه'] || '',
   insurance: labelValues['بیمه'] || labelValues['با بیمه'] || divarInsuranceHint || '',
   address_detail: source === 'e-estekhdam' ? eEstekhdamAddress : (labelValues['آدرس'] || labelValues['محل کار'] || ''),
   benefits_description: source === 'e-estekhdam' ? eEstekhdamBenefits : (labelValues['تسهیلات و مزایا'] || labelValues['مزایا'] || labelValues['سایر مزایا'] || ''),
   technical_skills: source === 'e-estekhdam' ? eEstekhdamRequirements : (labelValues['مهارت‌ها'] || labelValues['مهارت های مورد نیاز'] || labelValues['مهارت‌های مورد نیاز'] || labelValues['شرایط احراز'] || ''),
   soft_skills: labelValues['مهارت‌های رفتاری'] || labelValues['مهارت های رفتاری'] || '',
   disability_support: labelValues['امکان همکاری با افراد دارای معلولیت'] || '',
   work_environment: labelValues['محیط اصلی کار'] || labelValues['محیط کار'] || '',
   required_documents: labelValues['مدارک لازم برای درخواست'] || labelValues['مدارک مورد نیاز'] || '',
   responsibilities: labelValues['شرح وظایف'] || '',
   requirements: source === 'e-estekhdam' ? eEstekhdamRequirements : (labelValues['شرایط احراز'] || ''),
   application_deadline: labelValues['مهلت ارسال رزومه'] || labelValues['مهلت درخواست'] || '',
   hiring_timeline: labelValues['زمان‌بندی جذب'] || labelValues['زمان شروع همکاری'] || '',
   job_description: cleanMultiline(source === 'e-estekhdam' ? eEstekhdamDescription : divarDescription)
 };

 root.remove();
 return {
   title, contentText, contentHtml, contactText, contactLinks, publishedAt, publishedRelative,
   sourceDescriptionText: cleanMultiline(source === 'e-estekhdam' ? eEstekhdamDescription : divarDescription),
   sourceDescriptionKind: source === 'e-estekhdam' ? (eEstekhdamDescription ? 'e_estekhdam_description' : 'fallback') : (divarDescription ? 'divar_description' : 'fallback'),
   locationText, cityExact, sourceCategory, companyName, labelValues, structured,
   employerEvidence: {
     explicit: explicitCompany,
     jsonld: jsonCompany,
     // Read small current-ad company labels only, never the whole company card.
     companyElements: Array.from(root.querySelectorAll('[itemprop="hiringOrganization"] [itemprop="name"], [class*="company-name" i], [class*="companyName"], [data-company-name]'))
       .map(node => clean(node.getAttribute('data-company-name') || node.innerText || node.textContent || ''))
       .filter(text => text.length >= 2 && text.length <= 160),
     lines: rootLines.filter(line => line.length <= 420),
     sourceTitles: [jobPosting?.title, document.querySelector('meta[property="og:title"]')?.content, document.title]
   }
 };
 }, { source });
 if (source === 'e-estekhdam') {
   const employer = resolveEmployerEvidence(data.employerEvidence);
   data.companyName = employer.name;
   data.structured.company_name = employer.name;
   data.structured.company_evidence = employer.evidence;
   if (employer.intro) data.structured.source_intro = employer.intro;
 }
 delete data.employerEvidence;
 return data;
}

