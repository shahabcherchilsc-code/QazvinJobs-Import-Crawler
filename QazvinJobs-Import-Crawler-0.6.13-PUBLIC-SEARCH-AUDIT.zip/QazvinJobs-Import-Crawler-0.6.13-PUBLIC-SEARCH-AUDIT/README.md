QazvinJobs Import Crawler 0.6.13 — public source audit repair.
Read README-SOURCE-AUDIT-FA.md first. Production freshness and identity parsing are unchanged. Keep the host scheduler on --daily-test.
