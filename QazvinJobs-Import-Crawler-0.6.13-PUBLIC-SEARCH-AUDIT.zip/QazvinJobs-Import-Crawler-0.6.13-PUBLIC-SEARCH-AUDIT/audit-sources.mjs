// Separate, read-only entrypoint. Never import crawler.mjs: it executes imports.
import { chromium } from 'playwright';
import { writeFile } from 'node:fs/promises';
import { ImportLedger } from './import-ledger.mjs';
import { extractJob } from './source-parser.mjs';
import { collectDiscoveryRows, discoveryMeta } from './freshness.mjs';
import { preferNewestEEstekhdam } from './eestekhdam-discovery.mjs';
import { identity, auditRecord, allowRequest } from './audit-utils.mjs';

const selected = process.env.QZIH_SOURCES || 'both';
if (!['both', 'e-estekhdam', 'divar'].includes(selected)) throw new Error('Invalid audit source');
const sources = selected === 'both' ? ['e-estekhdam', 'divar'] : [selected];
const seeds = String(process.env.QZIH_SEED_URLS || '').split(/[\n,]+/).map(v => v.trim()).filter(Boolean);
if (seeds.length > 8) throw new Error('Audit accepts at most eight source URLs');
const seedIdentities = seeds.map(identity);
if (seedIdentities.some(x => !sources.includes(x.source))) throw new Error('Seed source differs from selected source');
const ledger = new ImportLedger(process.env.QZIH_IMPORT_HISTORY_FILE || '', process.env.QZIH_IMPORT_ENDPOINT || '');
await ledger.load(); // load only; never acknowledge or save.
const report = { crawler_version: '0.6.13', audit_only: true, total_sent: 0, records: [], sources: {},
  limits: { freshness_mode: 'today_yesterday', max_details_per_source: 4 },
  note: 'Diagnostic sample only. Page-ID history is not a verdict about vacancy-level duplicates. No receiver requests or contact reveal.' };
const search = {
  'e-estekhdam': 'https://www.e-estekhdam.com/jobs/استخدام-در-قزوین',
  divar: 'https://divar.ir/s/qazvin/jobs'
};
const browser = await chromium.launch({ executablePath: process.env.QZIH_TEST_BROWSER || undefined, headless: true,
  args: ['--no-sandbox', '--disable-dev-shm-usage', '--disable-blink-features=AutomationControlled'] });
const deadline = Date.now() + 6 * 60_000;
try {
  const context = await browser.newContext({ locale: 'fa-IR', timezoneId: 'Asia/Tehran', serviceWorkers: 'block',
    userAgent: 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/128.0.0.0 Safari/537.36',
    viewport: { width: 1365, height: 900 }, extraHTTPHeaders: { 'Accept-Language': 'fa-IR,fa;q=0.9,en;q=0.5' } });
  let currentSource = '';
  await context.route('**/*', route => {
    const request = route.request();
    const allowed = allowRequest(request.url(), request.method(), request.resourceType(), request.postData() || '');
    if (request.method() === 'POST' && report.sources[currentSource]) {
      const key = allowed ? 'public_read_posts_allowed' : 'posts_blocked';
      report.sources[currentSource][key]++;
    }
    return allowed ? route.continue() : route.abort();
  });
  for (const source of sources) {
    currentSource = source;
    const stats = report.sources[source] = { discovered: 0, inspected: 0, errors: 0, accepted: 0, fresh_discovered: 0,
      too_old: 0, unknown_age: 0, previously_imported: 0, discovery_sort_status: 'not_attempted', discovery_sort_verified: false,
      search_stage: 'not_started', search_status: 'not_attempted', search_http_status: 0, public_read_posts_allowed: 0, posts_blocked: 0 };
    const candidates = new Map();
    for (const own of seedIdentities.filter(x => x.source === source)) candidates.set(own.id, { own, card: {} });
    const page = await context.newPage();
    page.setDefaultTimeout(5_000);
    try {
      if (!seeds.length) {
        stats.search_stage = 'navigation';
        const response = await page.goto(search[source], { waitUntil: 'domcontentloaded', timeout: 25_000 });
        stats.search_http_status = response?.status() || 0;
        if (response && response.status() >= 400) throw new Error('search_http_error');
        stats.search_stage = 'listing_wait';
        await page.locator(source === 'divar' ? 'main a[href*="/v/"]' : 'main a[href*="/k"]').first().waitFor({ timeout: 20_000 });
        if (source === 'e-estekhdam') {
          stats.search_stage = 'sort';
          const sort = await preferNewestEEstekhdam(page);
          stats.discovery_sort_status = sort.status;
          stats.discovery_sort_verified = Boolean(sort.selected);
        }
        for (let n = 0; n < 3 && candidates.size < 4; n++) {
          stats.search_stage = 'collection';
          const rows = await page.evaluate(collectDiscoveryRows, { source });
          for (const row of rows) {
            let own;
            try { own = identity(row.href); } catch { continue; }
            if (own.source !== source || candidates.has(own.id)) continue;
            candidates.set(own.id, { own, card: discoveryMeta(row.context, 1, 1, row.rowIndex, row.dateTime), navigation_url: row.href });
            if (candidates.size >= 4) break;
          }
          if (candidates.size < 4) { await page.mouse.wheel(0, 1200); await page.waitForTimeout(700); }
        }
      }
      stats.discovered = candidates.size;
      stats.fresh_discovered = [...candidates.values()].filter(({ card }) => Number.isFinite(card.ageDays) && card.ageDays <= 1).length;
      if (!candidates.size) throw new Error('no_source_links');
      stats.search_status = 'listing_ready';
      stats.search_stage = 'details';
      for (const { own, card, navigation_url } of [...candidates.values()].slice(0, seeds.length ? 8 : 4)) {
        if (Date.now() > deadline) { stats.errors++; break; }
        try {
          const response = await page.goto(navigation_url || own.url, { waitUntil: 'domcontentloaded', timeout: 25_000 });
          if (response && response.status() >= 400) throw new Error('detail_http_error');
          await page.locator('h1').first().waitFor({ timeout: 8_000 });
          await page.waitForTimeout(500);
          const current = identity(page.url());
          if (current.source !== own.source || current.id !== own.id) throw new Error('identity_mismatch');
          const data = await extractJob(page, source);
          const row = auditRecord(own, data, card, ledger.entries);
          report.records.push(row);
          stats.inspected++;
          if (row.status !== 'parsed') stats.errors++;
          if (row.decision.reason === 'old') stats.too_old++;
          if (row.decision.reason === 'unknown') stats.unknown_age++;
          if (row.page_id_acknowledged || row.acknowledged_position_ids) stats.previously_imported++;
        } catch (error) {
          stats.errors++;
          const status = ['detail_http_error', 'identity_mismatch', 'invalid_source_url'].includes(error.message) ? error.message : 'detail_read_failed';
          report.records.push({ source: own.source, source_id: own.id, source_url: own.url, status });
        }
      }
    } catch (error) {
      stats.errors++;
      stats.search_status = 'source_read_failed';
      stats.search_error = ['search_http_error', 'no_source_links'].includes(error.message) ? error.message
        : error.name === 'TimeoutError' ? 'timeout' : 'navigation_or_render_error';
      console.error(`SOURCE_AUDIT_ERROR source=${source} stage=${stats.search_stage} code=${stats.search_error} http=${stats.search_http_status}`);
    } finally { await page.close(); }
  }
} finally {
  await browser.close();
  await writeFile('audit-report.json', JSON.stringify(report, null, 2) + '\n');
  await writeFile('run-summary.json', JSON.stringify(report, null, 2) + '\n');
}
const rows = report.records.map(r => `| ${r.source} | ${r.source_id} | ${r.status} | ${r.published_at || r.relative_evidence_kind || '-'} | ${r.decision?.reason || '-'} | ${r.page_id_acknowledged ? 'yes' : 'no'} / ${r.acknowledged_position_ids || 0} | ${r.warning || '-'} |`).join('\n');
const sourceRows = Object.entries(report.sources).map(([name,s]) => `| ${name} | ${s.discovered} | ${s.inspected} | ${s.errors} | ${s.search_stage} | ${s.search_error || 'none'} | ${s.search_http_status || '-'} | ${s.public_read_posts_allowed} |`).join('\n');
const summary = `## Source detail audit — no imports\n\nSample only; no draft created. Dates use the existing production parser. Ambiguous date warnings require review.\n\n| Source | Found | Inspected | Errors | Stage | Error code | HTTP | Public read POSTs |\n|---|---:|---:|---:|---|---|---:|---:|\n${sourceRows}\n\n| Source | ID | Status | Date evidence | Freshness | Page / position history | Warning |\n|---|---|---|---|---|---|---|\n${rows}\n\nDownload audit-report.json for safe date evidence. Previously acknowledged position IDs do not prove a duplicate vacancy.\n`;
console.log(summary);
if (process.env.GITHUB_STEP_SUMMARY) {
  const { appendFile } = await import('node:fs/promises');
  await appendFile(process.env.GITHUB_STEP_SUMMARY, summary);
}
if (Object.values(report.sources).some(s => !s.inspected || s.errors)) {
  console.error('Audit incomplete: at least one source or detail could not be read. See the report; no import was attempted.');
  process.exitCode = 1;
}
