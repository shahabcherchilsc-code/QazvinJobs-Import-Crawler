import { readFile, appendFile } from 'node:fs/promises';

const file = process.argv[2] || 'run-summary.json';
let report;
try { report = JSON.parse(await readFile(file, 'utf8')); }
catch (error) {
  console.log(`No crawl result to summarize (${error.code || error.message}); this is expected for validation or account connection runs.`);
  process.exit(0);
}
const e = report.sources?.['e-estekhdam'] || {};
const d = report.sources?.divar || {};
const sent = Number(report.total_sent || 0);
const reasons = [];
if (!sent) reasons.push('No eligible ads were sent to WordPress; GitHub success means only that the crawler completed.');
if ((e.too_old || 0) > 0 && !(e.accepted || 0)) reasons.push(`E-Estekhdam: ${e.too_old} old candidates; fresh cards: ${e.fresh_discovered || 0}. Verify dates and current listing order.`);
if (!d.auth_loaded && (d.no_contact || d.contact_reveal_failed || 0)) reasons.push('Divar: no saved authenticated session; use the manual connect_divar action and enter the SMS code in WordPress Import Hub.');
if ((d.non_job_category || 0) > 0) reasons.push(`Divar: ${d.non_job_category} links failed the strict current-ad jobs-category check; do not disable this gate without checking sample pages.`);
if ((e.errors || 0) + (d.errors || 0)) reasons.push(`Parser/runtime errors: ${(e.errors || 0) + (d.errors || 0)}; inspect logs.`);
const table = `| Source | Discovered | Inspected | Too old | Missing direct contact | Sent |\n|---|---:|---:|---:|---:|---:|\n| E-Estekhdam | ${e.discovered || 0} | ${e.inspected || 0} | ${e.too_old || 0} | ${e.no_contact || 0} | ${e.accepted || 0} |\n| Divar | ${d.discovered || 0} | ${d.inspected || 0} | ${d.too_old || 0} | ${d.no_contact || 0} | ${d.accepted || 0} |`;
const markdown = `## QazvinJobs daily crawler - actual import results\n\n**WordPress items accepted:** ${sent}  \n**Freshness:** ${report.limits?.freshness_mode || 'rolling'}  \n**Divar authenticated session loaded:** ${Boolean(d.auth_loaded)}\n\n${table}\n\n${reasons.map(x => '- ' + x).join('\n')}\n`;
console.log(markdown);
if (!sent) console.log('::warning title=QazvinJobs: 0 imported ads::Crawler completed, but no new eligible job reached WordPress. See job summary for source-specific blockers.');
if (process.env.GITHUB_STEP_SUMMARY) await appendFile(process.env.GITHUB_STEP_SUMMARY, markdown, 'utf8');
