# QazvinJobs Import Crawler 0.4.1

- رفع خطای `ReferenceError: cleanMultiline is not defined` داخل `page.evaluate()` در استخراج ای‌استخدام.
- انتقال helperهای `cleanMultiline` و `htmlToMultilineText` به context مرورگر همان تابع استخراج.
- جلوگیری از سبز شدن اشتباه GitHub Action وقتی همه آگهی‌های بررسی‌شده با خطای parser/runtime شکست می‌خورند و هیچ موردی ارسال نشده است.
- حفظ تمام اصلاحات نسخه 0.4.0 مربوط به جلوگیری از اختلاط Draftها، نگاشت فیلدها، پوشش بیشتر، توضیحات واقعی و زمان‌بندی صبحگاهی.
