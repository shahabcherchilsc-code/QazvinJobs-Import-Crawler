QazvinJobs Import Hub 0.3.35 — Contract Boundary Sync

- هماهنگ با Crawler 0.3.37 و QazvinJobs 2.3.11.
- کلیدهای canonical در آخرین مرز ذخیره‌سازی بر aliasهای قدیمی اولویت دارند.
- software_tools و work_schedule_text پیش از ساخت پیش‌نویس به‌صورت قطعی همگام می‌شوند.
- snapshot نهایی فیلدها در _qzih_final_fields_snapshot ذخیره می‌شود تا عیب‌یابی از حالت حدس و تکرار خارج شود.
- منطق Duplicate Protection، کنترل تست یک‌باره، تماس دیوار و انتشار دستی تغییر نکرده است.
