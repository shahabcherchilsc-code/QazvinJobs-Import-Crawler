<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class QZIH_Importer {
    const QUEUE_POST_TYPE = 'qzih_import';
    const PAGE_SLUG = 'qazvinjobs-import-hub';
    const REST_NAMESPACE = 'qazvinjobs-import/v1';
    const TOKEN_OPTION = 'qzih_import_token';

    private static $instance = null;

    public static function get_instance() {
        if ( null === self::$instance ) { self::$instance = new self(); }
        return self::$instance;
    }

    public static function activate() {
        self::get_instance()->register_post_type();
        if ( ! get_option( self::TOKEN_OPTION ) ) {
            add_option( self::TOKEN_OPTION, wp_generate_password( 48, false, false ), '', false );
        }
        if ( false === get_option( 'qzih_max_batch', false ) ) {
            add_option( 'qzih_max_batch', 20, '', false );
        }
        if ( false === get_option( 'qzih_auto_draft', false ) ) {
            add_option( 'qzih_auto_draft', 1, '', false );
        }
        self::get_instance()->ensure_import_user();
        update_option( 'qzih_plugin_version', QZIH_VERSION, false );
        self::get_instance()->repair_orphaned_state();
        self::get_instance()->repair_invalid_created_links();
        self::get_instance()->backfill_import_flags();
        flush_rewrite_rules();
    }

    public static function deactivate() { flush_rewrite_rules(); }

    private function __construct() {
        add_action( 'init', array( $this, 'register_post_type' ), 8 );
        add_action( 'init', array( $this, 'maybe_upgrade' ), 9 );
        add_action( 'admin_menu', array( $this, 'admin_menu' ), 99 );
        add_action( 'rest_api_init', array( $this, 'register_rest_routes' ) );
        add_action( 'admin_post_qzih_approve', array( $this, 'approve' ) );
        add_action( 'admin_post_qzih_approve_with_contact', array( $this, 'approve_with_contact' ) );
        add_action( 'admin_post_qzih_reject', array( $this, 'reject' ) );
        add_action( 'admin_post_qzih_clear_logs', array( $this, 'clear_logs' ) );
        add_action( 'admin_post_qzih_rotate_token', array( $this, 'rotate_token' ) );
        add_action( 'admin_post_qzih_save_settings', array( $this, 'save_settings' ) );
        add_action( 'admin_post_qzih_reset_stale', array( $this, 'reset_stale' ) );
        add_action( 'admin_post_qzih_arm_test_reimport', array( $this, 'arm_test_reimport' ) );
        add_action( 'admin_post_qzih_clear_test_reimport', array( $this, 'clear_test_reimport' ) );
        add_filter( 'plugin_action_links_' . plugin_basename( QZIH_FILE ), array( $this, 'plugin_links' ) );
    }

    public function maybe_upgrade() {
        $installed = (string) get_option( 'qzih_plugin_version', '' );
        if ( QZIH_VERSION === $installed ) { return; }
        if ( false === get_option( 'qzih_auto_draft', false ) ) {
            add_option( 'qzih_auto_draft', 1, '', false );
        }
        $this->ensure_import_user();
        $this->repair_orphaned_state();
        $this->repair_invalid_created_links();
        $this->backfill_import_flags();
        update_option( 'qzih_plugin_version', QZIH_VERSION, false );
    }

    public function repair_orphaned_state( $hard_reset = false ) {
        global $wpdb;

        // نسخه‌های قبلی ممکن بود نشانگر «دیده‌شده» بسازند، بدون اینکه صف یا پیش‌نویس واقعی وجود داشته باشد.
        $like = $wpdb->esc_like( 'qzih_seen_' ) . '%';
        $wpdb->query( $wpdb->prepare( "DELETE FROM {$wpdb->options} WHERE option_name LIKE %s", $like ) );

        // آیتم‌های داخل زباله نباید مانع ورود دوباره شوند. اگر آگهی واقعی ساخته نشده، برای همیشه پاک شوند.
        $trashed = get_posts( array(
            'post_type'      => self::QUEUE_POST_TYPE,
            'post_status'    => 'trash',
            'posts_per_page' => 500,
            'fields'         => 'ids',
        ) );
        foreach ( $trashed as $trash_id ) {
            $created_id = absint( get_post_meta( $trash_id, '_qzih_created_ad_id', true ) );
            if ( ! $created_id || ! get_post( $created_id ) ) {
                wp_delete_post( $trash_id, true );
            }
        }

        // در بازنشانی دستی، صف‌های نیمه‌کاره‌ای که آگهی واقعی ندارند نیز پاک می‌شوند تا دریافت تازه انجام شود.
        if ( $hard_reset ) {
            $stale = get_posts( array(
                'post_type'      => self::QUEUE_POST_TYPE,
                'post_status'    => array( 'pending', 'draft' ),
                'posts_per_page' => 500,
                'fields'         => 'ids',
            ) );
            foreach ( $stale as $stale_id ) {
                $created_id = absint( get_post_meta( $stale_id, '_qzih_created_ad_id', true ) );
                if ( ! $created_id || ! get_post( $created_id ) ) {
                    wp_delete_post( $stale_id, true );
                }
            }
            return;
        }

        // آیتم Draft بدون آگهی واقعی دوباره به صف مدیر برگردد.
        $orphans = get_posts( array(
            'post_type'      => self::QUEUE_POST_TYPE,
            'post_status'    => 'draft',
            'posts_per_page' => 500,
            'fields'         => 'ids',
        ) );
        foreach ( $orphans as $orphan_id ) {
            $created_id = absint( get_post_meta( $orphan_id, '_qzih_created_ad_id', true ) );
            if ( ! $created_id || ! get_post( $created_id ) ) {
                delete_post_meta( $orphan_id, '_qzih_created_ad_id' );
                wp_update_post( array( 'ID' => absint( $orphan_id ), 'post_status' => 'pending' ) );
            }
        }

        // رکوردهای تکراری قدیمی صف را یکپارچه کن؛ اولویت با رکوردی است که آگهی واقعی دارد، سپس pending.
        $all = get_posts( array(
            'post_type'      => self::QUEUE_POST_TYPE,
            'post_status'    => array( 'pending', 'draft' ),
            'posts_per_page' => 1000,
            'fields'         => 'ids',
            'orderby'        => 'ID',
            'order'          => 'ASC',
        ) );
        $keepers = array();
        foreach ( $all as $queue_id ) {
            $source_id = (string) get_post_meta( $queue_id, '_qzih_source_id', true );
            $source_url = (string) get_post_meta( $queue_id, '_qzih_source_url', true );
            $key = $source_id ? 'id:' . $source_id : 'url:' . md5( $source_url );
            if ( ! $source_id && ! $source_url ) { continue; }
            if ( ! isset( $keepers[ $key ] ) ) {
                $keepers[ $key ] = $queue_id;
                continue;
            }
            $keep_id = $keepers[ $key ];
            $keep_created = absint( get_post_meta( $keep_id, '_qzih_created_ad_id', true ) );
            $this_created = absint( get_post_meta( $queue_id, '_qzih_created_ad_id', true ) );
            if ( $this_created && get_post( $this_created ) && ( ! $keep_created || ! get_post( $keep_created ) ) ) {
                wp_delete_post( $keep_id, true );
                $keepers[ $key ] = $queue_id;
            } else {
                wp_delete_post( $queue_id, true );
            }
        }
    }

    private function backfill_import_flags() {
        if ( ! class_exists( 'QazvinJobs_Compat' ) ) { return; }
        $ids = get_posts( array(
            'post_type'      => QazvinJobs_Compat::ad_post_types(),
            'post_status'    => array( 'publish', 'pending', 'draft', 'private', 'future' ),
            'posts_per_page' => 500,
            'fields'         => 'ids',
            'meta_query'     => array(
                array( 'key' => '_qz_import_hub_owned', 'value' => '1' ),
            ),
        ) );
        foreach ( $ids as $ad_id ) {
            update_post_meta( $ad_id, '_qz_is_imported', 1 );
            if ( ! get_post_meta( $ad_id, 'qazvinjobs_ad_import_source', true ) ) {
                update_post_meta( $ad_id, 'qazvinjobs_ad_import_source', sanitize_key( get_post_meta( $ad_id, '_qz_source_key', true ) ) );
            }
        }
    }

    public function plugin_links( $links ) {
        array_unshift( $links, '<a href="' . esc_url( admin_url( 'admin.php?page=' . self::PAGE_SLUG ) ) . '">تنظیمات</a>' );
        return $links;
    }

    public function register_post_type() {
        register_post_type( self::QUEUE_POST_TYPE, array(
            'labels' => array( 'name' => 'صف ورود آگهی', 'singular_name' => 'آگهی ورودی' ),
            'public' => false,
            'show_ui' => false,
            'show_in_rest' => false,
            'supports' => array( 'title', 'editor', 'custom-fields' ),
            'capability_type' => 'post',
            'map_meta_cap' => true,
        ) );
    }

    public function register_rest_routes() {
        register_rest_route( self::REST_NAMESPACE, '/status', array(
            'methods' => 'GET',
            'callback' => array( $this, 'rest_status' ),
            'permission_callback' => array( $this, 'rest_permission' ),
        ) );
        register_rest_route( self::REST_NAMESPACE, '/batch', array(
            'methods' => 'POST',
            'callback' => array( $this, 'rest_receive_batch' ),
            'permission_callback' => array( $this, 'rest_permission' ),
        ) );
    }

    public function rest_permission( WP_REST_Request $request ) {
        $saved = (string) get_option( self::TOKEN_OPTION, '' );
        $provided = trim( (string) $request->get_header( 'x-qzih-token' ) );
        if ( ! $provided ) {
            $authorization = trim( (string) $request->get_header( 'authorization' ) );
            if ( 0 === stripos( $authorization, 'Bearer ' ) ) { $provided = trim( substr( $authorization, 7 ) ); }
        }
        return $saved && $provided && hash_equals( $saved, $provided );
    }

    public function rest_status() {
        $armed = get_transient( 'qzih_test_reimport_once' );
        $controlled_test = array( 'active' => false );
        if ( is_array( $armed ) && ! empty( $armed['url'] ) ) {
            $armed_at = absint( $armed['armed_at'] ?? 0 );
            $expires_in = $armed_at ? max( 0, ( 20 * MINUTE_IN_SECONDS ) - ( time() - $armed_at ) ) : 0;
            $controlled_test = array(
                'active' => true,
                'url' => $this->normalize_source_url( $armed['url'] ),
                'source_id' => sanitize_key( $armed['source_id'] ?? '' ),
                'expires_in' => $expires_in,
            );
        }
        return rest_ensure_response( array(
            'ok' => true,
            'version' => QZIH_VERSION,
            'queue' => $this->queue_count(),
            'contact_review_queue' => $this->contact_review_queue_count(),
            'auto_draft' => (bool) get_option( 'qzih_auto_draft', 1 ),
            'controlled_test' => $controlled_test,
            'time' => current_time( 'mysql' ),
        ) );
    }

    public function rest_receive_batch( WP_REST_Request $request ) {
        $payload = $request->get_json_params();
        $payload = is_array( $payload ) ? $payload : array();

        $diagnostics = isset( $payload['diagnostics'] ) && is_array( $payload['diagnostics'] )
            ? $this->sanitize_crawler_diagnostics( $payload['diagnostics'] )
            : array();
        if ( $diagnostics ) {
            $diagnostics['received_at'] = current_time( 'mysql' );
            update_option( 'qzih_last_crawler_diagnostics', $diagnostics, false );
        }

        $items = isset( $payload['items'] ) && is_array( $payload['items'] ) ? $payload['items'] : array();
        $max = max( 1, min( 50, absint( get_option( 'qzih_max_batch', 20 ) ) ) );
        $items = array_slice( $items, 0, $max );
        $summary = array(
            'received' => count( $items ), 'accepted' => 0, 'review_queue' => 0, 'duplicates' => 0,
            'no_location' => 0, 'no_contact' => 0, 'invalid' => 0, 'errors' => 0,
            'results' => array(),
        );

        foreach ( $items as $raw ) {
            $result = $this->process_received_item( is_array( $raw ) ? $raw : array() );
            $status = isset( $result['status'] ) ? $result['status'] : 'errors';
            if ( isset( $summary[ $status ] ) ) { $summary[ $status ]++; }
            else { $summary['errors']++; }
            $summary['results'][] = $result;
        }
        if ( $items ) {
            update_option( 'qzih_last_receiver_run', array_merge( $summary, array( 'time' => current_time( 'mysql' ) ) ), false );
            $armed = get_transient( 'qzih_test_reimport_once' );
            if ( is_array( $armed ) && ! empty( $armed['url'] ) ) {
                $armed_url = $this->normalize_source_url( $armed['url'] );
                foreach ( $items as $raw_item ) {
                    $raw_url = is_array( $raw_item ) ? $this->normalize_source_url( $raw_item['url'] ?? '' ) : '';
                    $raw_id = is_array( $raw_item ) ? sanitize_key( $raw_item['source_id'] ?? '' ) : '';
                    $raw_position_index = is_array( $raw_item ) ? absint( $raw_item['position_index'] ?? 0 ) : 0;
                    $raw_position_count = is_array( $raw_item ) ? max( 1, absint( $raw_item['position_count'] ?? 1 ) ) : 1;
                    $raw_controlled_last = is_array( $raw_item ) && ! empty( $raw_item['controlled_test_last'] );
                    if ( $armed_url && $raw_url && hash_equals( (string) $armed_url, (string) $raw_url )
                        && $this->is_position_scoped_source_id( $raw_id, 'e-estekhdam' )
                        && ( $raw_controlled_last || $raw_position_index >= $raw_position_count ) ) {
                        delete_transient( 'qzih_test_reimport_once' );
                        break;
                    }
                }
            }
        }
        $summary['diagnostics_saved'] = (bool) $diagnostics;
        return rest_ensure_response( $summary );
    }

    private function sanitize_crawler_diagnostics( $raw ) {
        $out = array(
            'crawler_version' => sanitize_text_field( $raw['crawler_version'] ?? '' ),
            'source_mode'     => sanitize_key( $raw['source_mode'] ?? '' ),
            'duration_seconds'=> absint( $raw['duration_seconds'] ?? 0 ),
            'sources'         => array(),
        );
        $allowed = array( 'e-estekhdam', 'divar' );
        foreach ( $allowed as $source ) {
            $row = isset( $raw['sources'][ $source ] ) && is_array( $raw['sources'][ $source ] )
                ? $raw['sources'][ $source ]
                : array();
            $out['sources'][ $source ] = array(
                'name'        => sanitize_text_field( $row['name'] ?? $this->source_label( $source ) ),
                'discovered'  => absint( $row['discovered'] ?? 0 ),
                'inspected'   => absint( $row['inspected'] ?? 0 ),
                'accepted'    => absint( $row['accepted'] ?? 0 ),
                'review_only' => absint( $row['review_only'] ?? 0 ),
                'no_location' => absint( $row['no_location'] ?? 0 ),
                'no_contact'  => absint( $row['no_contact'] ?? 0 ),
                'login_required' => absint( $row['login_required'] ?? 0 ),
                'auth_loaded' => ! empty( $row['auth_loaded'] ),
                'auth_status' => sanitize_key( $row['auth_status'] ?? '' ),
                'contact_reveal_failed' => absint( $row['contact_reveal_failed'] ?? 0 ),
                'duplicates'  => absint( $row['duplicates'] ?? 0 ),
                'positions_found' => absint( $row['positions_found'] ?? 0 ),
                'errors'      => absint( $row['errors'] ?? 0 ),
            );
        }
        return $out;
    }

private function process_received_item( $raw ) {
    $url   = $this->normalize_source_url( isset( $raw['url'] ) ? $raw['url'] : '' );
    $title = sanitize_text_field( isset( $raw['title'] ) ? $raw['title'] : '' );
    $host  = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
    $source = sanitize_key( isset( $raw['source'] ) ? $raw['source'] : $this->detect_source_from_url( $url ) );
    if ( ! $source ) { $source = $this->detect_source_from_url( $url ); }

    $source_id = $this->normalize_source_id(
        isset( $raw['source_id'] ) ? $raw['source_id'] : '',
        $url,
        $source
    );
    $parent_source_id = sanitize_key( isset( $raw['parent_source_id'] ) ? $raw['parent_source_id'] : '' );
    $position_index = absint( isset( $raw['position_index'] ) ? $raw['position_index'] : 0 );
    $position_count = max( 1, absint( isset( $raw['position_count'] ) ? $raw['position_count'] : 1 ) );
    $multi_position = ! empty( $raw['multi_position'] ) || $this->is_position_scoped_source_id( $source_id, $source );

    $invalid_reasons = array();
    if ( ! $title ) { $invalid_reasons[] = 'عنوان خالی است'; }
    if ( ! $url ) { $invalid_reasons[] = 'لینک منبع خالی یا نامعتبر است'; }
    if ( ! $source ) { $invalid_reasons[] = 'منبع تشخیص داده نشد'; }
    if ( $url && ! $this->is_allowed_source_host( $host, $source ) ) { $invalid_reasons[] = 'دامنه منبع مجاز نیست'; }
    if ( $url && $source && ! $this->is_job_url( $url, $source ) ) { $invalid_reasons[] = 'قالب لینک آگهی پشتیبانی نمی‌شود'; }
    if ( ! $source_id ) { $invalid_reasons[] = 'شناسه منبع ساخته نشد'; }

    if ( $invalid_reasons ) {
        $reason = 'ورودی نامعتبر: ' . implode( '؛ ', $invalid_reasons );
        $this->log( 'رد', $reason, $title, '', $url );
        return array( 'status' => 'invalid', 'source_id' => $source_id, 'reason' => 'invalid_item', 'details' => $invalid_reasons );
    }

    $content_text = isset( $raw['content_text'] ) ? (string) $raw['content_text'] : '';
    $content_html = isset( $raw['content_html'] ) ? (string) $raw['content_html'] : '';
    $plain_content = $this->normalize_text( $content_text . ' ' . wp_strip_all_tags( $content_html ) );

    // 0.3.17: source-first contract. Structured values sent by the crawler are
    // trusted before any text fallback. This is the key protection against a
    // Qazvin ad being classified as Alvand because of "similar ads" text.
    $source_fields = array();
    if ( isset( $raw['fields'] ) && is_array( $raw['fields'] ) ) {
        $source_fields = $raw['fields'];
    }
    if ( isset( $raw['structured'] ) && is_array( $raw['structured'] ) ) {
        $source_fields = array_merge( $source_fields, $raw['structured'] );
    }
    $source_fields = $this->sanitize_source_fields( $source_fields );

    // Hard Divar source gate: only items positively confirmed by the crawler as
    // belonging to Divar's Jobs category are allowed to enter the queue/drafts.
    // This prevents unrelated /v/ ads (housing, vehicles, services, etc.) from
    // becoming job drafts if they appear in search-page navigation/recommendations.
    if ( 'divar' === $source ) {
        $source_is_job = ! empty( $raw['source_is_job'] );
        if ( ! $source_is_job ) {
            $fingerprint = hash( 'sha256', $source . '|' . $source_id . '|non-job|' . $this->normalize_text( $title ) );
            $this->remember_seen( $source_id, 'non_job_category', $fingerprint );
            $this->log( 'رد', 'دیوار: آگهی خارج از دسته کاریابی/استخدام است؛ پیش‌نویس ساخته نشد', $title, '', $url );
            return array( 'status' => 'invalid', 'source_id' => $source_id, 'reason' => 'divar_non_job_category' );
        }
    }

    $city = $this->resolve_city_source_first( $raw, $source_fields, $title, $plain_content, $source );
    if ( ! $city ) {
        $fingerprint = hash( 'sha256', $source . '|' . $source_id . '|' . $this->normalize_text( $title . ' ' . $plain_content ) );
        $this->remember_seen( $source_id, 'no_location', $fingerprint );
        $this->log( 'رد', 'شهر معتبر استان قزوین از فیلد محل کار منبع تشخیص داده نشد', $title, '', $url );
        return array( 'status' => 'no_location', 'source_id' => $source_id, 'reason' => 'no_qazvin_location' );
    }

    $role = sanitize_key( isset( $raw['role'] ) ? $raw['role'] : '' );
    if ( ! in_array( $role, array( 'employer', 'job_seeker' ), true ) ) {
        $role_fallback_text = $plain_content;
        if ( 'divar' === $source ) {
            $role_fallback_text = $this->normalize_text( implode( ' ', array_filter( array(
                $source_fields['job_description'] ?? '',
                $source_fields['requirements'] ?? '',
                $source_fields['technical_skills'] ?? '',
            ) ) ) );
        }
        $role = $this->detect_ad_role( $title, $role_fallback_text, $source );
    }

    // Contact policy is source-specific. For E-Estekhdam we trust only the
    // crawler's scoped contact block; re-parsing the whole page can capture
    // E-Estekhdam's own footer/admin links and create a false employer contact.
    $crawler_contacts = $this->merge_contacts(
        isset( $raw['contacts'] ) && is_array( $raw['contacts'] ) ? $raw['contacts'] : array(),
        array()
    );
    // Crawler contact blocks are authoritative for both sources. Never re-scan
    // the complete Divar page in WordPress: footer/support/recommendation numbers
    // must not become the employer contact. If reveal is unavailable, the item
    // stays a draft with manual-contact review instead of guessing a phone.
    $contacts = $crawler_contacts;
    $has_direct_contact = $this->has_direct_contact( $contacts );

    $contact_reveal = isset( $raw['contact_reveal'] ) && is_array( $raw['contact_reveal'] )
        ? array(
            'clicked'                => absint( $raw['contact_reveal']['clicked'] ?? 0 ),
            'contact_available'      => ! empty( $raw['contact_reveal']['contact_available'] ),
            'network_response_count' => absint( $raw['contact_reveal']['network_response_count'] ?? 0 ),
            'extraction_status'      => sanitize_key( $raw['contact_reveal']['extraction_status'] ?? '' ),
        )
        : array();
    $crawler_review_flag = ! empty( $raw['contact_review_required'] );
    // Final source policy:
    // - E-Estekhdam: direct public employer contact is mandatory.
    // - Divar: a valid Qazvin job may remain a draft with manual contact review.
    $manual_contact_required = ( 'divar' === $source && ! $has_direct_contact );
    $contact_review_required = $manual_contact_required;
    $contact_review_label = $contact_review_required
        ? sanitize_text_field(
            $raw['contact_review_label']
            ?? 'اطلاعات تماس مستقیم دیوار استخراج نشد؛ قبل از انتشار بررسی شود'
        )
        : '';

    $controlled_test_match = $this->test_reimport_matches( $source_id, $url );
    $controlled_test_no_contact = false;

    // Defense in depth: even if a future crawler accidentally sends an
    // E-Estekhdam item without contact, WordPress must refuse to create a queue
    // item or draft. A controlled test may collect diagnostics, but it never
    // bypasses this production rule.
    if ( 'e-estekhdam' === $source && ! $has_direct_contact ) {
        if ( $controlled_test_match ) {
            $this->consume_test_reimport_if_matches( $source_id, $url );
        }
        $contact_fingerprint = hash( 'sha256', $source . '|' . $source_id . '|no-direct-contact|' . $this->normalize_text( $title ) );
        $this->remember_seen( $source_id, 'no_contact', $contact_fingerprint );
        $this->log( 'رد', 'ای‌استخدام: اطلاعات تماس عمومی و مستقیم کارفرما وجود ندارد؛ پیش‌نویس ساخته نشد', $title, $city, $url );
        return array( 'status' => 'no_contact', 'source_id' => $source_id, 'reason' => 'e_estekhdam_requires_direct_public_contact' );
    }

    $source_category = sanitize_text_field(
        $source_fields['source_category']
        ?? $raw['source_category']
        ?? ''
    );
    // Divar category fallback must be scoped to the current vacancy too. A
    // generic title such as «استخدام نیروی کار» must not inherit a specialty
    // from a recommended card elsewhere on the Divar page.
    $classification_text = $plain_content;
    if ( 'divar' === $source ) {
        $classification_text = $this->normalize_text( implode( ' ', array_filter( array(
            $source_fields['job_description'] ?? '',
            $source_fields['requirements'] ?? '',
            $source_fields['technical_skills'] ?? '',
        ) ) ) );
    }
    $classification_map = $this->classify_source_job( $title, $source_category, $classification_text );
    // Crawler 0.4.9+ sends a canonical category resolved from the exact vacancy title.
    // Prefer it over a noisy source breadcrumb/category (for example a stale IT category
    // on a warehouse-worker page), but only when it is one of QazvinJobs' canonical keys.
    $explicit_category_key = sanitize_key( $source_fields['category_key'] ?? '' );
    $explicit_specialty_key = sanitize_key( $source_fields['specialty_key'] ?? '' );
    $valid_category_keys = array(
        'finance-accounting','admin-office','human-resources','sales-marketing-commerce','it-digital',
        'technical-engineering','industrial-production','construction-architecture','services-support',
        'transport-logistics','restaurant-food','medical-beauty','education-cultural','design-media-content',
        'legal-contracts','agriculture-livestock'
    );
    if ( $explicit_category_key && in_array( $explicit_category_key, $valid_category_keys, true ) ) {
        $classification_map['canonical_key'] = $explicit_category_key;
        $classification_map['legacy_key'] = $explicit_category_key;
        if ( $explicit_specialty_key ) { $classification_map['specialty_key'] = $explicit_specialty_key; }
    }
    $fields = $this->merge_source_and_fallback_fields( $source_fields, $plain_content, $city, $title, $role, $source );
    $fields['job_title'] = $this->canonical_job_title( $title, $city );
    $fields['city_name'] = $city;
    $fields['province'] = 'قزوین';
    $fields['category_key'] = $classification_map['canonical_key'];
    $fields['specialty_key'] = $classification_map['specialty_key'];
    // Canonical software/tools field is shared by web, WordPress and Android.
    // Keep office_tools as an additive legacy twin so older frozen UIs still
    // display the value until every installed client has moved to 2.3.9+.
    $candidate_tools = sanitize_text_field( $source_fields['software_tools'] ?? $source_fields['office_tools'] ?? $source_fields['software_skills'] ?? '' );
    if ( $candidate_tools ) {
        $fields['software_tools'] = $candidate_tools;
        if ( empty( $fields['office_tools'] ) ) { $fields['office_tools'] = $candidate_tools; }
    }
    if ( $source_category ) { $fields['source_category'] = $source_category; }
    $fields['source_city'] = $city;
    $fields['source_raw_title'] = $title;
    $fields['source_name'] = $this->source_label( $source );
    $fields['source_url'] = $url;
    $fields['source_ad_id'] = $source_id;

    if ( ! empty( $contacts['phones'][0] ) ) {
        $fields['contact_phone'] = $contacts['phones'][0];
        $normalized_contact_phone = $this->normalize_phone( $contacts['phones'][0] );
        if ( preg_match( '/^09\d{9}$/', $normalized_contact_phone ) ) { $fields['mobile_phone'] = $normalized_contact_phone; }
        elseif ( preg_match( '/^0(?!9)\d{9,10}$/', $normalized_contact_phone ) ) { $fields['landline_phone'] = $normalized_contact_phone; }
    }
    if ( ! empty( $contacts['emails'][0] ) ) { $fields['contact_email'] = $contacts['emails'][0]; }
    if ( ! empty( $contacts['whatsapp'][0] ) ) { $fields['whatsapp'] = $contacts['whatsapp'][0]; }

    if ( class_exists( 'QazvinJobs_Job_Contract' ) ) {
        // Canonical normalization is additive here. Category-specific UI fields
        // such as office_tools/software_tools must survive for the frozen current UI.
        $canonical_fields = QazvinJobs_Job_Contract::normalize_payload( $fields );
        if ( is_array( $canonical_fields ) ) {
            // Source-first: canonical normalizer may add aliases/defaults, but must not
            // replace fields explicitly extracted from the current source row.
            $fields = array_merge( $canonical_fields, $fields );
        }
        // Classification is determined from the position title/source and is authoritative.
        $fields['category_key'] = $classification_map['canonical_key'];
        $fields['specialty_key'] = $classification_map['specialty_key'];
    }

    $fingerprint_basis = array(
        'source' => $source,
        'source_id' => $source_id,
        'title' => $title,
        'city' => $city,
        'fields' => $fields,
        'contacts' => $contacts,
    );
    $fingerprint = hash( 'sha256', wp_json_encode( $fingerprint_basis, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) );

    $item = array(
        'source'         => $source,
        'source_name'    => $this->source_label( $source ),
        'source_id'      => $source_id,
        'url'            => $url,
        'title'          => $title,
        'role'           => $role,
        'raw_text'       => $plain_content,
        'content_html'   => $this->clean_content_html( $content_html ?: wpautop( esc_html( $content_text ) ) ),
        'published_at'   => sanitize_text_field( isset( $raw['published_at'] ) ? $raw['published_at'] : '' ),
        'source_category'=> $source_category,
        'parent_source_id' => $parent_source_id,
        'position_index' => $position_index,
        'position_count' => $position_count,
        'multi_position' => $multi_position,
    );
    $classification = array(
        'source' => $source,
        'role' => $role,
        'city' => $city,
        'contacts' => $contacts,
        'fields' => $fields,
        'source_fields_snapshot' => $source_fields,
        'legacy_category_key' => $classification_map['legacy_key'],
        'canonical_category_key' => $classification_map['canonical_key'],
        'specialty_key' => $classification_map['specialty_key'],
        'source_category' => $source_category,
        'fingerprint' => $fingerprint,
        'contact_review_required' => $contact_review_required,
        'contact_review_label' => $contact_review_label,
        'contact_reveal' => $contact_reveal,
        'manual_contact_required' => $manual_contact_required,
        'parent_source_id' => $parent_source_id,
        'position_index' => $position_index,
        'position_count' => $position_count,
        'multi_position' => $multi_position,
        'controlled_test_no_contact' => $controlled_test_no_contact,
    );

    if ( $this->consume_test_reimport_if_matches( $source_id, $url ) ) {
        return $this->create_controlled_test_draft( $item, $classification, $source_id );
    }

    $recovered = $this->recover_existing_ad( $item, $classification );
    if ( is_wp_error( $recovered ) ) {
        $this->log( 'خطا', $recovered->get_error_message(), $title, $city, $url );
        return array( 'status' => 'errors', 'source_id' => $source_id, 'reason' => $recovered->get_error_message() );
    }
    if ( is_array( $recovered ) ) { return $recovered; }

    $this->purge_stale_queue_for_source( $source_id, $url, $source );
    if ( $this->is_duplicate( $source_id, $fingerprint, $url, $source ) ) {
        $this->log( 'رد', 'تکراری واقعی؛ آگهی وارداتی معتبر از قبل وجود دارد', $title, $city, $url );
        return array( 'status' => 'duplicates', 'source_id' => $source_id, 'reason' => 'duplicate' );
    }

    $queue_id = $this->queue_item( $item, $classification );
    if ( is_wp_error( $queue_id ) ) {
        $this->log( 'خطا', $queue_id->get_error_message(), $title, $city, $url );
        return array( 'status' => 'errors', 'source_id' => $source_id, 'reason' => $queue_id->get_error_message() );
    }

    if ( $contact_review_required && ! get_option( 'qzih_auto_draft', 1 ) ) {
        $this->remember_seen( $source_id, 'review_queue', $fingerprint );
        $this->log( 'صف بررسی', $contact_review_label . '؛ ساخت خودکار پیش‌نویس غیرفعال است', $title, $city, $url );
        return array(
            'status' => 'review_queue',
            'source_id' => $source_id,
            'queue_id' => $queue_id,
            'mode' => 'contact_review',
            'label' => $contact_review_label,
        );
    }

    if ( get_option( 'qzih_auto_draft', 1 ) && class_exists( 'QazvinJobs_Compat' ) ) {
        $ad_id = $this->create_ad_draft_from_queue( $queue_id );
        if ( ! is_wp_error( $ad_id ) ) {
            $this->remember_seen( $source_id, 'draft_created', $fingerprint );
            if ( $contact_review_required ) {
                $this->log( 'پیش‌نویس', 'پیش‌نویس ساخته شد؛ اطلاعات تماس مستقیم باید پیش از انتشار بررسی شود', $title, $city, $url );
                return array( 'status' => 'accepted', 'source_id' => $source_id, 'queue_id' => $queue_id, 'ad_id' => $ad_id, 'mode' => 'contact_review_draft', 'manual_contact_required' => true );
            }
            $this->log( 'پیش‌نویس', 'پیش‌نویس با شهر، عنوان، دسته و فیلدهای منبع‌محور ساخته شد', $title, $city, $url );
            return array( 'status' => 'accepted', 'source_id' => $source_id, 'queue_id' => $queue_id, 'ad_id' => $ad_id, 'mode' => 'source_first_draft' );
        }
        $this->log( 'هشدار', 'ساخت پیش‌نویس خودکار ناموفق بود؛ مورد در صف مدیر باقی ماند: ' . $ad_id->get_error_message(), $title, $city, $url );
    }

    $this->remember_seen( $source_id, 'queued', $fingerprint );
    $this->log( 'پذیرفته', 'آگهی معتبر قزوین آماده بررسی مدیر است', $title, $city, $url );
    return array( 'status' => 'accepted', 'source_id' => $source_id, 'queue_id' => $queue_id, 'mode' => 'queue' );
}


    public function admin_menu() {
        global $menu;
        $parent_exists = false;
        if ( is_array( $menu ) ) {
            foreach ( $menu as $item ) {
                if ( isset( $item[2] ) && 'qazvinjobs-settings' === $item[2] ) { $parent_exists = true; break; }
            }
        }
        if ( $parent_exists ) {
            add_submenu_page( 'qazvinjobs-settings', 'ورود آگهی‌های مجاز', 'ورود آگهی‌ها', 'manage_options', self::PAGE_SLUG, array( $this, 'admin_page' ) );
        } else {
            add_menu_page( 'QazvinJobs Import Hub', 'ورود آگهی‌ها', 'manage_options', self::PAGE_SLUG, array( $this, 'admin_page' ), 'dashicons-download', 58 );
        }
    }

    public function admin_page() {
        if ( ! current_user_can( 'manage_options' ) ) { return; }
        $queue = get_posts( array(
            'post_type' => self::QUEUE_POST_TYPE, 'post_status' => 'pending', 'posts_per_page' => 100,
            'orderby' => 'date', 'order' => 'DESC',
        ) );
        $created = get_posts( array(
            'post_type' => self::QUEUE_POST_TYPE, 'post_status' => 'draft', 'posts_per_page' => 50,
            'orderby' => 'date', 'order' => 'DESC',
            'meta_query' => array( array( 'key' => '_qzih_created_ad_id', 'compare' => 'EXISTS' ) ),
        ) );
        $logs = get_option( 'qzih_logs', array() );
        $last = get_option( 'qzih_last_receiver_run', array() );
        $diagnostics = get_option( 'qzih_last_crawler_diagnostics', array() );
        $token = (string) get_option( self::TOKEN_OPTION, '' );
        $endpoint = rest_url( self::REST_NAMESPACE . '/batch' );
        $status_endpoint = rest_url( self::REST_NAMESPACE . '/status' );
        $core_active = class_exists( 'QazvinJobs_Compat' );
        ?>
        <div class="wrap" dir="rtl">
            <h1>QazvinJobs Import Hub — دریافت از خزنده مرورگری</h1>
            <?php $this->render_notice_from_query(); ?>
            <div class="notice notice-info inline"><p><strong>روش دریافت:</strong> خزنده GitHub با مرورگر واقعی اجرا می‌شود. Import Hub 0.3.48 با Crawler 0.3.48 و قرارداد داده QazvinJobs 2.3.24 / Form v3 هماهنگ است؛ شهر، عنوان، دسته و فیلدها ابتدا از داده ساختاریافته خود منبع خوانده می‌شوند و متن آگهی فقط نقش fallback دارد. دیوار بدون شماره نیز به‌صورت پیش‌نویس نیازمند تکمیل تماس ذخیره می‌شود.</p></div>
            <div class="notice <?php echo $core_active ? 'notice-success' : 'notice-warning'; ?> inline"><p>
                <?php echo $core_active ? 'افزونه اصلی قزوین‌جابز شناسایی شد. تأیید مدیر فقط پیش‌نویس ایجاد می‌کند.' : 'افزونه اصلی قزوین‌جابز شناسایی نشد؛ صف فعال است اما تبدیل به پیش‌نویس انجام نمی‌شود.'; ?>
            </p></div>

            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="max-width:1280px;background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:14px 18px;margin:14px 0">
                <input type="hidden" name="action" value="qzih_save_settings">
                <?php wp_nonce_field( 'qzih_save_settings' ); ?>
                <label style="font-weight:700"><input type="checkbox" name="auto_draft" value="1" <?php checked( get_option( 'qzih_auto_draft', 1 ) ); ?>> پس از تأیید شرایط قزوین و تماس مستقیم، پیش‌نویس آگهی قزوین‌جابز خودکار ساخته شود</label>
                <span style="color:#646970;margin-right:10px">(پیشنهادی؛ انتشار نهایی همچنان دستی است)</span>
                <button class="button button-primary" style="margin-right:14px">ذخیره</button>
            </form>

            <div style="display:grid;grid-template-columns:minmax(320px,760px) minmax(280px,1fr);gap:18px;align-items:start;max-width:1280px">
                <div style="background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:20px">
                    <h2 style="margin-top:0">اتصال GitHub Crawler</h2>
                    <p>این سه مقدار را در مخزن GitHub داخل <code>Settings → Secrets and variables → Actions</code> بسازید:</p>
                    <table class="widefat striped">
                        <tr><th>نام Secret</th><th>مقدار</th></tr>
                        <tr><td><code>QZIH_SITE_URL</code></td><td dir="ltr"><code><?php echo esc_html( home_url( '/' ) ); ?></code></td></tr>
                        <tr><td><code>QZIH_IMPORT_ENDPOINT</code></td><td dir="ltr"><code><?php echo esc_html( $endpoint ); ?></code></td></tr>
                        <tr><td><code>QZIH_IMPORT_TOKEN</code></td><td><input id="qzih-token" type="password" readonly class="large-text ltr" dir="ltr" value="<?php echo esc_attr( $token ); ?>"><button type="button" class="button" onclick="var i=document.getElementById('qzih-token');i.type=i.type==='password'?'text':'password';">نمایش/پنهان</button></td></tr>
                    </table>
                    <p><strong>آزمون اتصال:</strong> <span dir="ltr"><code><?php echo esc_html( $status_endpoint ); ?></code></span></p>
                    <p><a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=qzih_rotate_token' ), 'qzih_rotate_token' ) ); ?>" onclick="return confirm('توکن قبلی بلافاصله باطل شود؟');">ساخت توکن جدید</a> <a class="button button-secondary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=qzih_reset_stale' ), 'qzih_reset_stale' ) ); ?>" onclick="return confirm('نشانگرهای تکراری و صف‌های نیمه‌کاره پاک شوند؟ پیش‌نویس‌های واقعی حذف نمی‌شوند.');">بازنشانی موارد تکراری قدیمی</a></p>
                    <?php $armed_test = get_transient( 'qzih_test_reimport_once' ); ?>
                    <div style="margin-top:14px;padding:12px;border:1px solid #dcdcde;border-radius:10px;background:#f6f7f7">
                        <strong>بازآزمایی کنترل‌شده یک منبع</strong>
                        <p style="margin:6px 0;color:#646970">برای تست Parser بدون حذف یا دست‌کاری آگهی منتشرشده، لینک آگهی را وارد کنید. Crawler 0.3.48 لینک فعال را مستقیماً از همین Hub می‌خواند؛ بنابراین برای تست، در GitHub مقدار seed_url را خالی بگذارید. فقط همان منبع طی ۲۰ دقیقه بررسی می‌شود و Duplicate Protection اجرای روزانه همچنان فعال می‌ماند.</p>
                        <?php if ( is_array( $armed_test ) && ! empty( $armed_test['url'] ) ) : ?>
                            <p><span style="color:#008a20;font-weight:700">فعال:</span> <code dir="ltr"><?php echo esc_html( $armed_test['url'] ); ?></code>
                            <a class="button button-small" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=qzih_clear_test_reimport' ), 'qzih_clear_test_reimport' ) ); ?>">لغو</a></p>
                        <?php else : ?>
                            <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                                <input type="hidden" name="action" value="qzih_arm_test_reimport">
                                <?php wp_nonce_field( 'qzih_arm_test_reimport' ); ?>
                                <input type="url" required class="regular-text ltr" dir="ltr" name="source_url" placeholder="https://www.e-estekhdam.com/k...">
                                <button class="button">فعال‌کردن بازآزمایی یک‌باره</button>
                            </form>
                        <?php endif; ?>
                    </div>
                </div>
                <div style="background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:20px">
                    <h2 style="margin-top:0">آخرین دریافت</h2>
                    <?php if ( empty( $last ) ) : ?><p>هنوز هیچ بسته‌ای از GitHub دریافت نشده است.</p><?php else : ?>
                        <p><strong>زمان:</strong> <?php echo esc_html( $last['time'] ?? '' ); ?></p>
                        <ul style="line-height:1.9">
                            <li>دریافت‌شده: <?php echo absint( $last['received'] ?? 0 ); ?></li>
                            <li>پذیرفته / پیش‌نویس ساخته‌شده: <?php echo absint( $last['accepted'] ?? 0 ); ?></li>
                            <li>صف بررسی تماس دیوار: <?php echo absint( $last['review_queue'] ?? 0 ); ?></li>
                            <li>تکراری: <?php echo absint( $last['duplicates'] ?? 0 ); ?></li>
                            <li>خارج از قزوین: <?php echo absint( $last['no_location'] ?? 0 ); ?></li>
                            <li>بدون تماس مستقیم: <?php echo absint( $last['no_contact'] ?? 0 ); ?></li>
                            <li>نامعتبر/خطا: <?php echo absint( ($last['invalid'] ?? 0) + ($last['errors'] ?? 0) ); ?></li>
                        </ul>
                    <?php endif; ?>
                </div>
            </div>

            <?php QZIH_Divar_Auth::render_admin_card(); ?>

            <div style="max-width:1280px;background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:20px;margin-top:18px">
                <h2 style="margin-top:0">وضعیت منابع در آخرین اجرای خزنده</h2>
                <?php if ( empty( $diagnostics ) ) : ?>
                    <p>هنوز گزارش تفکیکی منبع دریافت نشده است. پس از اجرای Crawler 0.3.48 این بخش تکمیل می‌شود.</p>
                <?php else : ?>
                    <p><strong>زمان دریافت:</strong> <?php echo esc_html( $diagnostics['received_at'] ?? '' ); ?>
                    <span style="margin-right:14px"><strong>نسخه خزنده:</strong> <?php echo esc_html( $diagnostics['crawler_version'] ?? '' ); ?></span>
                    <span style="margin-right:14px"><strong>مدت:</strong> <?php echo absint( $diagnostics['duration_seconds'] ?? 0 ); ?> ثانیه</span></p>
                    <table class="widefat striped">
                        <thead><tr><th>منبع</th><th>لینک کشف‌شده</th><th>بررسی‌شده</th><th>پذیرفته</th><th>صف بررسی تماس</th><th>ورود مجدد لازم</th><th>خارج از قزوین</th><th>بدون تماس مستقیم</th><th>خطا</th><th>نتیجه</th></tr></thead>
                        <tbody>
                        <?php foreach ( array( 'e-estekhdam', 'divar' ) as $source_key ) :
                            $row = isset( $diagnostics['sources'][ $source_key ] ) ? (array) $diagnostics['sources'][ $source_key ] : array();
                            $accepted_count = absint( $row['accepted'] ?? 0 );
                            $review_count = absint( $row['review_only'] ?? 0 );
                            $login_required_count = absint( $row['login_required'] ?? 0 );
                            $inspected_count = absint( $row['inspected'] ?? 0 );
                            $result_label = $login_required_count
                                ? 'نشست دیوار موجود نیست یا منقضی شده؛ ورود مجدد لازم است'
                                : ( $review_count
                                    ? 'آگهی‌های بدون شماره برای بررسی مدیر صف شدند'
                                    : ( $accepted_count ? 'پیش‌نویس معتبر ارسال شد' : ( $inspected_count ? 'بررسی شد؛ مورد واجد شرایط پیدا نشد' : 'در این اجرا بررسی نشد' ) ) );
                        ?>
                            <tr>
                                <td><strong><?php echo esc_html( $row['name'] ?? $this->source_label( $source_key ) ); ?></strong></td>
                                <td><?php echo absint( $row['discovered'] ?? 0 ); ?></td>
                                <td><?php echo $inspected_count; ?></td>
                                <td><?php echo $accepted_count; ?></td>
                                <td><?php echo $review_count; ?></td>
                                <td><?php echo $login_required_count; ?></td>
                                <td><?php echo absint( $row['no_location'] ?? 0 ); ?></td>
                                <td><?php echo absint( $row['no_contact'] ?? 0 ); ?></td>
                                <td><?php echo absint( $row['errors'] ?? 0 ); ?></td>
                                <td><?php echo esc_html( $result_label ); ?></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                    <p style="margin-bottom:0;color:#646970">در نسخه ۰.۳.۱۲، آمار خزنده و نتیجه گیرنده وردپرس از هم جدا هستند. مواردی که خزنده با وضعیت بررسی تماس می‌فرستد، باید در جدول «صف آماده بررسی مدیر» ظاهر شوند؛ شماره استخراج‌شده نیز مستقیماً به پیش‌نویس منتقل می‌شود.</p>
                <?php endif; ?>
            </div>

            <h2 style="margin-top:30px">صف آماده بررسی مدیر <span class="count">(<?php echo count( $queue ); ?>)</span></h2>
            <table class="widefat striped" style="max-width:1280px">
                <thead><tr><th>عنوان</th><th>شهر</th><th>تماس مستقیم</th><th>دریافت</th><th>منبع</th><th>عملیات</th></tr></thead>
                <tbody>
                <?php if ( ! $queue ) : ?><tr><td colspan="6">هنوز مورد قابل قبولی وارد صف نشده است.</td></tr><?php endif; ?>
                <?php foreach ( $queue as $item ) :
                    $city = get_post_meta( $item->ID, '_qzih_city', true );
                    $contacts = get_post_meta( $item->ID, '_qzih_contacts', true );
                    $url = get_post_meta( $item->ID, '_qzih_source_url', true ); ?>
                    <tr>
                        <td><strong><?php echo esc_html( $item->post_title ); ?></strong><details><summary>پیش‌نمایش متن</summary><div style="max-width:620px;max-height:260px;overflow:auto;background:#fff;padding:12px;border:1px solid #ddd;margin-top:8px"><?php echo wp_kses_post( $item->post_content ); ?></div></details></td>
                        <td><?php echo esc_html( $city ); ?></td>
                        <td>
                            <?php
                            $contact_review = (bool) get_post_meta( $item->ID, '_qzih_contact_review_required', true );
                            $contact_text = $this->contact_summary( is_array( $contacts ) ? $contacts : array() );
                            if ( $contact_review ) {
                                $review_label = sanitize_text_field( get_post_meta( $item->ID, '_qzih_contact_review_label', true ) ?: 'نیازمند بررسی اطلاعات تماس در دیوار' );
                                $reveal_meta = get_post_meta( $item->ID, '_qzih_contact_reveal', true );
                                $reveal_meta = is_array( $reveal_meta ) ? $reveal_meta : array();
                                echo '<span style="display:inline-block;background:#fff3cd;color:#7a5200;border:1px solid #f0cf76;border-radius:999px;padding:4px 9px;font-weight:700">' . esc_html( $review_label ) . '</span>';
                                echo '<div style="margin-top:6px;color:#646970;font-size:12px">دکمه تماس: ' . ( ! empty( $reveal_meta['contact_available'] ) ? 'شناسایی شد' : 'نامشخص' ) . ' | کلیک: ' . absint( $reveal_meta['clicked'] ?? 0 ) . ' | وضعیت: ' . esc_html( $reveal_meta['extraction_status'] ?? 'manager_review' ) . '</div>';
                            } else {
                                echo '<span dir="ltr">' . esc_html( $contact_text ) . '</span>';
                            }
                            ?>
                        </td>
                        <td><?php echo esc_html( get_the_date( 'Y/m/d H:i', $item ) ); ?></td>
                        <td><?php $source_name = get_post_meta( $item->ID, '_qzih_source_name', true ) ?: $this->source_label( get_post_meta( $item->ID, '_qzih_source', true ) ); ?><a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $source_name ); ?></a></td>
                        <td style="white-space:nowrap">
                            <a class="button" href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener">بررسی منبع</a>
                            <?php if ( $contact_review ) : ?>
                                <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display:flex;gap:5px;align-items:center;margin-top:6px">
                                    <input type="hidden" name="action" value="qzih_approve_with_contact">
                                    <input type="hidden" name="id" value="<?php echo absint( $item->ID ); ?>">
                                    <?php wp_nonce_field( 'qzih_item_' . $item->ID ); ?>
                                    <input type="tel" name="manual_phone" dir="ltr" inputmode="tel" placeholder="09xxxxxxxxx" style="width:125px">
                                    <button class="button button-primary">ثبت شماره و ساخت پیش‌نویس</button>
                                </form>
                                <a class="button" style="margin-top:5px" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=qzih_approve&id=' . $item->ID ), 'qzih_item_' . $item->ID ) ); ?>">ساخت بدون شماره</a>
                            <?php else : ?>
                                <a class="button button-primary" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=qzih_approve&id=' . $item->ID ), 'qzih_item_' . $item->ID ) ); ?>">تبدیل به پیش‌نویس</a>
                            <?php endif; ?>
                            <a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=qzih_reject&id=' . $item->ID ), 'qzih_item_' . $item->ID ) ); ?>">رد</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <h2 style="margin-top:30px">پیش‌نویس‌های ساخته‌شده <span class="count">(<?php echo count( $created ); ?>)</span></h2>
            <table class="widefat striped" style="max-width:1280px">
                <thead><tr><th>عنوان</th><th>شهر</th><th>وضعیت آگهی</th><th>منبع</th><th>عملیات</th></tr></thead>
                <tbody>
                <?php if ( ! $created ) : ?><tr><td colspan="5">هنوز پیش‌نویسی ساخته نشده است.</td></tr><?php endif; ?>
                <?php foreach ( $created as $item ) :
                    $ad_id = absint( get_post_meta( $item->ID, '_qzih_created_ad_id', true ) );
                    $ad = $ad_id ? get_post( $ad_id ) : null;
                    $status_object = $ad ? get_post_status_object( $ad->post_status ) : null;
                    $url = get_post_meta( $item->ID, '_qzih_source_url', true ); ?>
                    <tr>
                        <td>
                            <strong><?php echo esc_html( $ad ? get_the_title( $ad_id ) : $item->post_title ); ?></strong>
                            <?php if ( $ad && $item->post_title && $item->post_title !== get_the_title( $ad_id ) ) : ?>
                                <div style="margin-top:4px;color:#646970;font-size:12px">عنوان منبع: <?php echo esc_html( $item->post_title ); ?></div>
                            <?php endif; ?>
                            <div style="margin-top:4px;color:#8c8f94;font-size:11px">Queue #<?php echo absint( $item->ID ); ?> / Ad #<?php echo absint( $ad_id ); ?> / Source ID: <code><?php echo esc_html( get_post_meta( $item->ID, '_qzih_source_id', true ) ); ?></code></div>
                        </td>
                        <td><?php echo esc_html( get_post_meta( $item->ID, '_qzih_city', true ) ); ?></td>
                        <td><?php echo $ad ? esc_html( $status_object ? $status_object->label : $ad->post_status ) : 'یافت نشد'; ?></td>
                        <td><?php $source_name = get_post_meta( $item->ID, '_qzih_source_name', true ) ?: $this->source_label( get_post_meta( $item->ID, '_qzih_source', true ) ); ?><a href="<?php echo esc_url( $url ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $source_name ); ?></a></td>
                        <td><?php if ( $ad ) : ?><a class="button button-primary" href="<?php echo esc_url( get_edit_post_link( $ad_id ) ); ?>">بازکردن همین پیش‌نویس</a><?php else : ?>—<?php endif; ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

            <div style="display:flex;align-items:center;justify-content:space-between;max-width:1280px;margin-top:28px"><h2 style="margin:0">گزارش پذیرش و رد</h2><a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=qzih_clear_logs' ), 'qzih_clear_logs' ) ); ?>">پاک‌کردن گزارش</a></div>
            <table class="widefat striped" style="max-width:1280px;margin-top:10px"><thead><tr><th>زمان</th><th>نتیجه</th><th>دلیل</th><th>عنوان</th><th>شهر</th><th>لینک</th></tr></thead><tbody>
            <?php if ( empty( $logs ) ) : ?><tr><td colspan="6">گزارشی ثبت نشده است.</td></tr><?php endif; ?>
            <?php foreach ( array_slice( (array) $logs, 0, 100 ) as $log ) : ?><tr><td><?php echo esc_html( $log['time'] ?? '' ); ?></td><td><?php echo esc_html( $log['status'] ?? '' ); ?></td><td><?php echo esc_html( $log['reason'] ?? '' ); ?></td><td><?php echo esc_html( $log['title'] ?? '' ); ?></td><td><?php echo esc_html( $log['city'] ?? '' ); ?></td><td><a href="<?php echo esc_url( $log['url'] ?? '' ); ?>" target="_blank" rel="noopener">مشاهده</a></td></tr><?php endforeach; ?>
            </tbody></table>
        </div>
        <?php
    }

    private function render_notice_from_query() {
        $status = isset( $_GET['qzih_status'] ) ? sanitize_key( wp_unslash( $_GET['qzih_status'] ) ) : '';
        $map = array(
            'approved' => array( 'success', 'آگهی به صورت پیش‌نویس در قزوین‌جابز ساخته شد.' ),
            'approved_contact' => array( 'success', 'شماره تماس تأیید و پیش‌نویس آگهی ساخته شد.' ),
            'rejected' => array( 'success', 'مورد از صف رد شد.' ),
            'error' => array( 'error', 'عملیات کامل نشد. گزارش را بررسی کنید.' ),
            'logs_cleared' => array( 'success', 'گزارش پاک شد.' ),
            'token_rotated' => array( 'success', 'توکن جدید ساخته شد؛ Secret گیت‌هاب را هم به‌روزرسانی کنید.' ),
            'settings_saved' => array( 'success', 'تنظیمات ذخیره شد.' ),
            'divar_otp_saved' => array( 'success', 'کد پیامکی ثبت شد؛ اکشن GitHub در حال تکمیل ورود است.' ),
            'divar_otp_invalid' => array( 'error', 'کد پیامکی نامعتبر است یا زمان درخواست تمام شده.' ),
            'divar_session_missing' => array( 'error', 'درخواست فعال ورود دیوار پیدا نشد؛ اکشن ورود را دوباره اجرا کنید.' ),
            'divar_session_cleared' => array( 'success', 'نشست و درخواست ورود دیوار پاک شد.' ),
            'stale_reset' => array( 'success', 'موارد تکراری قدیمی و صف‌های نیمه‌کاره پاک شدند؛ اکنون خزنده GitHub را دوباره اجرا کنید.' ),
            'test_reimport_armed' => array( 'success', 'بازآزمایی یک‌باره برای همین منبع فعال شد؛ Crawler 0.3.48 این لینک را خودکار از Hub می‌خواند. در GitHub seed_url را خالی بگذارید.' ),
            'test_reimport_cleared' => array( 'success', 'بازآزمایی یک‌باره لغو شد.' ),
            'test_reimport_invalid' => array( 'error', 'لینک منبع برای بازآزمایی معتبر نیست.' ),
        );
        if ( isset( $map[ $status ] ) ) {
            printf( '<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>', esc_attr( $map[ $status ][0] ), esc_html( $map[ $status ][1] ) );
        }
    }

    public function save_settings() {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Forbidden' ); }
        check_admin_referer( 'qzih_save_settings' );
        update_option( 'qzih_auto_draft', isset( $_POST['auto_draft'] ) ? 1 : 0, false );
        $this->redirect( 'settings_saved' );
    }

    public function reset_stale() {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Forbidden' ); }
        check_admin_referer( 'qzih_reset_stale' );
        $this->repair_orphaned_state( true );
        $this->log( 'بازنشانی', 'نشانگرها و صف‌های نیمه‌کاره پاک شدند؛ خزنده را دوباره اجرا کنید', '', '', '' );
        $this->redirect( 'stale_reset' );
    }

    public function arm_test_reimport() {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Forbidden' ); }
        check_admin_referer( 'qzih_arm_test_reimport' );
        $url = $this->normalize_source_url( wp_unslash( $_POST['source_url'] ?? '' ) );
        $source = $this->detect_source_from_url( $url );
        $source_id = $this->normalize_source_id( '', $url, $source );
        if ( ! $url || ! $source || ! $source_id || ! $this->is_job_url( $url, $source ) ) {
            $this->redirect( 'test_reimport_invalid' );
        }
        set_transient( 'qzih_test_reimport_once', array(
            'url' => $url,
            'source_id' => $source_id,
            'armed_at' => time(),
        ), 20 * MINUTE_IN_SECONDS );
        $this->log( 'تست', 'بازآزمایی یک‌باره برای این منبع فعال شد', '', '', $url );
        $this->redirect( 'test_reimport_armed' );
    }

    public function clear_test_reimport() {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Forbidden' ); }
        check_admin_referer( 'qzih_clear_test_reimport' );
        delete_transient( 'qzih_test_reimport_once' );
        $this->redirect( 'test_reimport_cleared' );
    }

    public function rotate_token() {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Forbidden' ); }
        check_admin_referer( 'qzih_rotate_token' );
        update_option( self::TOKEN_OPTION, wp_generate_password( 48, false, false ), false );
        $this->redirect( 'token_rotated' );
    }

    public function approve() {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Forbidden' ); }
        $id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
        check_admin_referer( 'qzih_item_' . $id );
        $ad_id = $this->create_ad_draft_from_queue( $id, get_current_user_id() );
        if ( is_wp_error( $ad_id ) ) {
            $queue = get_post( $id );
            $this->log( 'خطا', $ad_id->get_error_message(), $queue ? $queue->post_title : '', get_post_meta( $id, '_qzih_city', true ), get_post_meta( $id, '_qzih_source_url', true ) );
            $this->redirect( 'error' );
        }
        $this->redirect( 'approved' );
    }


    public function approve_with_contact() {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Forbidden' ); }
        $id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
        check_admin_referer( 'qzih_item_' . $id );
        if ( self::QUEUE_POST_TYPE !== get_post_type( $id ) ) { $this->redirect( 'error' ); }

        $phone = $this->normalize_phone( wp_unslash( $_POST['manual_phone'] ?? '' ) );
        if ( ! preg_match( '/^0\d{9,10}$/', $phone ) ) {
            $queue = get_post( $id );
            $this->log( 'خطا', 'شماره تماس واردشده معتبر نیست', $queue ? $queue->post_title : '', get_post_meta( $id, '_qzih_city', true ), get_post_meta( $id, '_qzih_source_url', true ) );
            $this->redirect( 'error' );
        }

        $contacts = get_post_meta( $id, '_qzih_contacts', true );
        $contacts = is_array( $contacts ) ? $contacts : array();
        $phones = isset( $contacts['phones'] ) && is_array( $contacts['phones'] ) ? $contacts['phones'] : array();
        $phones[] = $phone;
        $contacts['phones'] = array_values( array_unique( array_filter( array_map( array( $this, 'normalize_phone' ), $phones ) ) ) );
        update_post_meta( $id, '_qzih_contacts', $contacts );
        update_post_meta( $id, '_qzih_manual_phone_verified', 1 );
        update_post_meta( $id, '_qzih_contact_review_required', 0 );
        update_post_meta( $id, '_qzih_contact_review_label', 'شماره تماس توسط مدیر تأیید شد' );

        $ad_id = $this->create_ad_draft_from_queue( $id, get_current_user_id() );
        if ( is_wp_error( $ad_id ) ) {
            $queue = get_post( $id );
            $this->log( 'خطا', $ad_id->get_error_message(), $queue ? $queue->post_title : '', get_post_meta( $id, '_qzih_city', true ), get_post_meta( $id, '_qzih_source_url', true ) );
            $this->redirect( 'error' );
        }
        $this->log( 'تأیید تماس', 'شماره تماس توسط مدیر ثبت و پیش‌نویس ساخته شد', get_the_title( $id ), get_post_meta( $id, '_qzih_city', true ), get_post_meta( $id, '_qzih_source_url', true ) );
        $this->redirect( 'approved_contact' );
    }

private function create_ad_draft_from_queue( $id, $author_id = 0 ) {
    $id = absint( $id );
    $queue = get_post( $id );
    if ( ! $queue || self::QUEUE_POST_TYPE !== $queue->post_type || ! in_array( $queue->post_status, array( 'pending', 'draft' ), true ) ) {
        return new WP_Error( 'qzih_invalid_queue', 'مورد صف معتبر نیست.' );
    }
    if ( ! class_exists( 'QazvinJobs_Compat' ) ) {
        return new WP_Error( 'qzih_core_missing', 'افزونه اصلی قزوین‌جابز شناسایی نشد.' );
    }

    $source_id   = (string) get_post_meta( $id, '_qzih_source_id', true );
    $source_url  = (string) get_post_meta( $id, '_qzih_source_url', true );
    $source      = sanitize_key( get_post_meta( $id, '_qzih_source', true ) ?: $this->detect_source_from_url( $source_url ) );
    $source_name = sanitize_text_field( get_post_meta( $id, '_qzih_source_name', true ) ?: $this->source_label( $source ) );
    $role        = sanitize_key( get_post_meta( $id, '_qzih_role', true ) ?: 'employer' );
    if ( ! in_array( $role, array( 'employer', 'job_seeker' ), true ) ) { $role = 'employer'; }

    $already = absint( get_post_meta( $id, '_qzih_created_ad_id', true ) );
    $existing_ad_id = 0;
    if ( $already && get_post( $already ) ) {
        $owned = (int) get_post_meta( $already, '_qz_import_hub_owned', true );
        $same_source = $source_id && hash_equals( $source_id, (string) get_post_meta( $already, '_qz_source_id', true ) );
        if ( $owned && $same_source ) { $existing_ad_id = $already; }
        else { delete_post_meta( $id, '_qzih_created_ad_id' ); }
    }

    $contacts = get_post_meta( $id, '_qzih_contacts', true );
    $contacts = is_array( $contacts ) ? $contacts : array();
    $payload  = $this->build_trusted_payload( $queue, $contacts, $role );
    $fields   = $payload['fields'];
    if ( class_exists( 'QazvinJobs_Field_Schema' ) ) { $normalized_fields = QazvinJobs_Field_Schema::normalize_values( $fields, $role ); if ( is_array( $normalized_fields ) ) { $fields = array_merge( $fields, $normalized_fields ); } }

    // Keep the public number usable even for SMS/WhatsApp-only sources, but
    // determine the UI contact-method checkboxes from explicit channel evidence.
    $phone_direct = ! empty( $contacts['phones'][0] ) ? $contacts['phones'][0] : '';
    $sms          = ! empty( $contacts['sms'][0] ) ? $contacts['sms'][0] : '';
    $email        = ! empty( $contacts['emails'][0] ) ? $contacts['emails'][0] : '';
    $whatsapp     = ! empty( $contacts['whatsapp'][0] ) ? $contacts['whatsapp'][0] : '';
    $phone        = $phone_direct ?: ( $sms ?: $whatsapp );
    $author_id = $this->ensure_import_user();

    $postarr = array(
        'post_type'    => QazvinJobs_Compat::primary_ad_post_type(),
        'post_status'  => 'draft',
        'post_title'   => $payload['title'],
        'post_content' => $payload['content'],
        'post_excerpt' => $payload['excerpt'],
        'post_author'  => $author_id,
    );
    if ( $existing_ad_id ) {
        $postarr['ID'] = $existing_ad_id;
        $ad_id = wp_update_post( $postarr, true );
    } else {
        $ad_id = wp_insert_post( $postarr, true );
    }
    if ( is_wp_error( $ad_id ) ) { return $ad_id; }

    // Schedule belongs to the dedicated Web/App schedule block, not to the
    // category field bag. Preserve it before normalize_values_for_category()
    // filters the dynamic fields.
    $schedule_fields = array(
        'schedule_mode'   => sanitize_text_field( $fields['schedule_mode'] ?? '' ),
        'work_days'       => isset( $fields['work_days'] ) ? array_values( array_filter( (array) $fields['work_days'] ) ) : array(),
        'work_start'      => sanitize_text_field( $fields['work_start'] ?? '' ),
        'work_end'        => sanitize_text_field( $fields['work_end'] ?? '' ),
        'preferred_shift' => isset( $fields['preferred_shift'] ) ? array_values( array_filter( (array) $fields['preferred_shift'] ) ) : array(),
        'schedule_note'   => sanitize_textarea_field( $fields['schedule_note'] ?? ( $fields['work_schedule_text'] ?? '' ) ),
    );
    if ( class_exists( 'QazvinJobs_Field_Schema' ) ) {
        $schedule_fields['schedule_mode'] = QazvinJobs_Field_Schema::normalize_field_value( 'schedule_mode', $schedule_fields['schedule_mode'], $role );
        $schedule_fields['work_days'] = QazvinJobs_Field_Schema::normalize_field_value( 'work_days', $schedule_fields['work_days'], $role );
        $schedule_fields['preferred_shift'] = QazvinJobs_Field_Schema::normalize_field_value( 'preferred_shift', $schedule_fields['preferred_shift'], $role );
    }

    $city = $payload['city'];
    $category_key = $payload['category_key']; // legacy/UI key
    $canonical_category_key = sanitize_key( $payload['canonical_category_key'] ?? ( $fields['category_key'] ?? '' ) );
    $specialty_key = sanitize_key( $payload['specialty_key'] ?? ( $fields['specialty_key'] ?? '' ) );
    $salary_display = $this->salary_display_from_fields( $fields );
    $salary_explicit = $this->has_explicit_salary_fields( $fields );
    $contact_methods = array();
    if ( $phone_direct ) { $contact_methods[] = 'phone'; }
    if ( $sms ) { $contact_methods[] = 'sms'; }
    if ( $whatsapp ) { $contact_methods[] = 'whatsapp'; }
    if ( $email ) { $contact_methods[] = 'email'; }
    // Keep imported contact channels inside the same canonical contract as web/app.
    if ( class_exists( 'QazvinJobs_Field_Schema' ) ) { $contact_methods = QazvinJobs_Field_Schema::normalize_field_value( 'contact_methods', $contact_methods, $role ); }

    update_post_meta( $ad_id, '_qazvinjobs_ad', 1 );
    update_post_meta( $ad_id, 'qazvinjobs_ad_type', $role );
    update_post_meta( $ad_id, 'qazvinjobs_ad_category_key', $category_key ); // legacy key kept only for frozen field-schema/UI compatibility
    update_post_meta( $ad_id, 'qazvinjobs_ad_canonical_category_key', $canonical_category_key );
    update_post_meta( $ad_id, 'qazvinjobs_ad_specialty_key', $specialty_key );
    update_post_meta( $ad_id, 'qazvinjobs_ad_canonical_category_label', $this->canonical_category_label( $canonical_category_key ) );
    update_post_meta( $ad_id, 'qazvinjobs_ad_specialty_label', $this->specialty_label( $canonical_category_key, $specialty_key ) );
    update_post_meta( $ad_id, 'qazvinjobs_ad_schema_version', defined( 'QAZVINJOBS_VERSION' ) ? QAZVINJOBS_VERSION : QZIH_VERSION );
    // Recovered drafts must represent the latest source exactly. Remove stale
    // imported field metas first (for example an old food benefit) and then
    // write the current source-first payload. This only runs on Import Hub-owned
    // drafts and does not touch manually created ads.
    foreach ( array_keys( (array) get_post_meta( $ad_id ) ) as $meta_key ) {
        if ( 0 === strpos( $meta_key, 'qazvinjobs_ad_field_' ) ) { delete_post_meta( $ad_id, $meta_key ); }
    }
    if ( class_exists( 'QazvinJobs_Field_Schema' ) ) {
        $all_source_fields = $fields;
        $canonical_storage_fields = method_exists( 'QazvinJobs_Field_Schema', 'normalize_values_for_category' )
            ? QazvinJobs_Field_Schema::normalize_values_for_category( $fields, $category_key, $role )
            : QazvinJobs_Field_Schema::normalize_values( $fields, $role );
        if ( is_array( $canonical_storage_fields ) ) { $fields = $canonical_storage_fields; }
        $unmapped_fields = array_diff_key( (array) $all_source_fields, (array) $fields );
        update_post_meta( $ad_id, '_qzih_unmapped_fields_snapshot', $unmapped_fields );
    }
    if ( empty( $fields['software_tools'] ) && ! empty( $fields['office_tools'] ) ) {
        $fields['software_tools'] = sanitize_text_field( $fields['office_tools'] );
    }
    update_post_meta( $ad_id, 'qazvinjobs_ad_category_fields', $fields );
    foreach ( $fields as $key => $value ) { update_post_meta( $ad_id, 'qazvinjobs_ad_field_' . sanitize_key( $key ), $value ); }
    // Exact post-import snapshot for deterministic QA. If the editor ever shows a
    // different value, this meta tells us immediately whether the crawler/Hub or UI is responsible.
    update_post_meta( $ad_id, '_qzih_final_fields_snapshot', $fields );
    if ( class_exists( 'QazvinJobs_Field_Schema' ) && method_exists( 'QazvinJobs_Field_Schema', 'missing_required_fields' ) ) {
        update_post_meta( $ad_id, '_qzih_missing_required_fields', QazvinJobs_Field_Schema::missing_required_fields( $fields, $category_key, $role ) );
    }
    $source_snapshot = get_post_meta( $id, '_qzih_source_fields_snapshot', true );
    if ( is_array( $source_snapshot ) ) { update_post_meta( $ad_id, '_qzih_source_fields_snapshot', $source_snapshot ); }
    // Deterministic QA: list source keys that did not survive into the final field bag.
    $missing_source_keys = array();
    foreach ( (array) $source_snapshot as $source_key => $source_value ) {
        $source_key = sanitize_key( $source_key );
        if ( ! $source_key || '' === $source_value || null === $source_value || array() === $source_value ) { continue; }
        $canonical_key = class_exists( 'QazvinJobs_Job_Contract' ) ? QazvinJobs_Job_Contract::canonical_field_key( $source_key ) : $source_key;
        if ( ! array_key_exists( $source_key, $fields ) && ! array_key_exists( $canonical_key, $fields ) ) { $missing_source_keys[] = $source_key; }
    }
    update_post_meta( $ad_id, '_qzih_missing_source_field_keys', array_values( array_unique( $missing_source_keys ) ) );

    update_post_meta( $ad_id, 'qazvinjobs_ad_city_name', $city );
    update_post_meta( $ad_id, 'qazvinjobs_ad_location', $payload['location'] );
    update_post_meta( $ad_id, 'qazvinjobs_ad_address_detail', $payload['address'] );
    update_post_meta( $ad_id, '_qz_import_salary_explicit', $salary_explicit ? 1 : 0 );
    update_post_meta( $ad_id, 'qazvinjobs_ad_salary', $salary_explicit ? $salary_display : '' );
    if ( ! $salary_explicit ) {
        // Never let a stale legacy/UI fallback turn an absent source salary into «توافقی».
        delete_post_meta( $ad_id, 'qazvinjobs_salary_display' );
        delete_post_meta( $ad_id, '_qazvinjobs_salary_display' );
        delete_post_meta( $ad_id, '_price' );
        delete_post_meta( $ad_id, '_regular_price' );
    }
    update_post_meta( $ad_id, 'qazvinjobs_ad_job_type', $fields['cooperation_type'] ?? '' );
    $work_days = array_values( array_unique( array_filter( array_map( 'sanitize_text_field', (array) $schedule_fields['work_days'] ) ) ) );
    update_post_meta( $ad_id, 'qazvinjobs_ad_work_days', $work_days );
    update_post_meta( $ad_id, 'qazvinjobs_ad_work_start', sanitize_text_field( $schedule_fields['work_start'] ) );
    update_post_meta( $ad_id, 'qazvinjobs_ad_work_end', sanitize_text_field( $schedule_fields['work_end'] ) );
    $shift_values = array_values( array_filter( array_map( 'sanitize_text_field', (array) $schedule_fields['preferred_shift'] ) ) );
    update_post_meta( $ad_id, 'qazvinjobs_ad_shift_label', $shift_values ? reset( $shift_values ) : '' ); // legacy only.
    update_post_meta( $ad_id, 'qazvinjobs_ad_field_schedule_mode', sanitize_text_field( $schedule_fields['schedule_mode'] ) );
    update_post_meta( $ad_id, 'qazvinjobs_ad_field_preferred_shift', $shift_values );
    update_post_meta( $ad_id, 'qazvinjobs_ad_field_schedule_note', sanitize_textarea_field( $schedule_fields['schedule_note'] ) );
    update_post_meta( $ad_id, 'qazvinjobs_ad_requirements', $payload['requirements'] );
    update_post_meta( $ad_id, 'qazvinjobs_ad_benefits', $payload['benefits'] );
    update_post_meta( $ad_id, 'qazvinjobs_ad_full_description', wp_strip_all_tags( $payload['content'] ) );
    update_post_meta( $ad_id, 'qazvinjobs_publication_model', 'import_review' );
    update_post_meta( $ad_id, 'qazvinjobs_ad_contact_methods', $contact_methods );
    $contact_review_required = (bool) get_post_meta( $id, '_qzih_contact_review_required', true );
    update_post_meta( $ad_id, 'qazvinjobs_phone_visibility', $contact_review_required ? 'hidden' : 'public' );
    update_post_meta( $ad_id, '_qz_import_contact_review_required', $contact_review_required ? 1 : 0 );
    update_post_meta( $ad_id, '_qz_import_manual_contact_required', $contact_review_required ? 1 : 0 );
    update_post_meta( $ad_id, '_qz_import_contact_review_label', $contact_review_required ? sanitize_text_field( get_post_meta( $id, '_qzih_contact_review_label', true ) ?: 'نیازمند بررسی اطلاعات تماس منبع' ) : '' );
    update_post_meta( $ad_id, 'qazvinjobs_ad_contact_phone_public', $phone );
    $mobile_phone = sanitize_text_field( $all_source_fields['mobile_phone'] ?? ( preg_match( '/^09\d{9}$/', $phone ) ? $phone : '' ) );
    $landline_phone = sanitize_text_field( $all_source_fields['landline_phone'] ?? ( preg_match( '/^0(?!9)\d{9,10}$/', $phone ) ? $phone : '' ) );
    $phone_extension = preg_replace( '/\D+/', '', (string) ( $all_source_fields['phone_extension'] ?? '' ) );
    $contact_instructions = sanitize_textarea_field( $all_source_fields['contact_instructions'] ?? '' );
    update_post_meta( $ad_id, 'qazvinjobs_ad_mobile', $mobile_phone );
    update_post_meta( $ad_id, 'qazvinjobs_ad_landline', $landline_phone );
    update_post_meta( $ad_id, 'qazvinjobs_ad_landline_extension', $phone_extension );
    update_post_meta( $ad_id, 'qazvinjobs_ad_contact_instructions', $contact_instructions );
    update_post_meta( $ad_id, 'qazvinjobs_ad_whatsapp', $whatsapp );
    $email = sanitize_email( $email );
    $source_email_explicit = ( $email && is_email( $email ) );
    update_post_meta( $ad_id, 'qazvinjobs_ad_contact_email_public', $source_email_explicit ? $email : '' );
    update_post_meta( $ad_id, '_qz_import_source_email_explicit', $source_email_explicit ? 1 : 0 );
    update_post_meta( $ad_id, '_custom_phone', $phone );
    update_post_meta( $ad_id, 'ad_phone', $phone );
    if ( $source_email_explicit ) {
        update_post_meta( $ad_id, '_custom_email', $email );
        update_post_meta( $ad_id, 'ad_email', $email );
        delete_post_meta( $ad_id, '_email_show' );
    } else {
        // Source has no public email: never leak qz_importer/admin account email via Charsoogh fallback.
        delete_post_meta( $ad_id, '_custom_email' );
        delete_post_meta( $ad_id, 'ad_email' );
        update_post_meta( $ad_id, '_email_show', 'on' );
    }

    update_post_meta( $ad_id, '_qz_source_name', $source_name );
    update_post_meta( $ad_id, '_qz_source_key', $source );
    update_post_meta( $ad_id, '_qz_source_raw_title', (string) get_post_meta( $id, '_qzih_source_title', true ) );
    update_post_meta( $ad_id, '_qz_source_category', (string) get_post_meta( $id, '_qzih_source_category', true ) );
    update_post_meta( $ad_id, '_qz_source_city', $city );
    update_post_meta( $ad_id, '_qz_source_id', $source_id );
    update_post_meta( $ad_id, '_qz_source_url', $source_url );
    update_post_meta( $ad_id, '_qz_parent_source_id', sanitize_key( get_post_meta( $id, '_qzih_parent_source_id', true ) ) );
    update_post_meta( $ad_id, '_qz_source_position_index', absint( get_post_meta( $id, '_qzih_position_index', true ) ) );
    update_post_meta( $ad_id, '_qz_source_position_count', max( 1, absint( get_post_meta( $id, '_qzih_position_count', true ) ) ) );
    update_post_meta( $ad_id, '_qz_source_multi_position', absint( get_post_meta( $id, '_qzih_multi_position', true ) ) ? 1 : 0 );
    update_post_meta( $ad_id, '_qz_source_received_at', current_time( 'mysql' ) );
    update_post_meta( $ad_id, '_qz_source_raw_text', (string) get_post_meta( $id, '_qzih_raw_text', true ) );
    update_post_meta( $ad_id, '_qz_import_hub_version', QZIH_VERSION );
    update_post_meta( $ad_id, '_qz_import_mapped_field_keys', array_values( array_keys( $fields ) ) );
    update_post_meta( $ad_id, '_qz_import_hub_owned', 1 );
    update_post_meta( $ad_id, '_qz_is_imported', 1 );
    update_post_meta( $ad_id, 'qazvinjobs_ad_import_source', $source );
    update_post_meta( $ad_id, '_qz_import_needs_admin_review', 1 );
    if ( ! empty( $classification['controlled_test_no_contact'] ) ) {
        update_post_meta( $ad_id, '_qz_test_no_direct_contact', 1 );
    }
    update_post_meta( $ad_id, '_qz_import_image_pending', 1 );
    update_post_meta( $ad_id, '_yoast_wpseo_focuskw', $payload['focus_keyword'] );
    update_post_meta( $ad_id, '_yoast_wpseo_title', $payload['seo_title'] );
    update_post_meta( $ad_id, '_yoast_wpseo_metadesc', $payload['seo_description'] );

    $company_name = sanitize_text_field( $fields['company_name'] ?? '' );
    if ( 'employer' === $role && ( ! $company_name || $this->is_generic_company_name( $company_name ) ) && 'e-estekhdam' === $source ) {
        $company_name = $this->extract_eestekhdam_company_name( (string) get_post_meta( $id, '_qzih_raw_text', true ) );
    }
    update_post_meta( $ad_id, 'qazvinjobs_ad_company_name', 'employer' === $role ? $company_name : 'کارجوی قزوین' );

    if ( 'product' === get_post_type( $ad_id ) ) {
        update_post_meta( $ad_id, '_stock_status', 'instock' );
        update_post_meta( $ad_id, '_virtual', 'yes' );
        update_post_meta( $ad_id, '_visibility', 'visible' );
        delete_post_meta( $ad_id, '_price' );
        delete_post_meta( $ad_id, '_regular_price' );
        if ( taxonomy_exists( 'product_type' ) ) { wp_set_object_terms( $ad_id, 'simple', 'product_type', false ); }
    }

    $this->assign_category_term( $ad_id, $category_key, $canonical_category_key );
    $this->assign_city_term( $ad_id, $city );
    if ( class_exists( 'QazvinJobs_Listing_Integration' ) ) { QazvinJobs_Listing_Integration::sync_ad_meta( $ad_id, $fields ); }

    update_post_meta( $id, '_qzih_created_ad_id', $ad_id );
    wp_update_post( array( 'ID' => $id, 'post_status' => 'draft' ) );

    // Image generation is intentionally outside the importer contract: fields,
    // contact policy, duplicate protection and draft status are already final.
    // Core 2.3.24+ listens to this event and queues the existing background AI
    // image worker without blocking or changing the importer result.
    do_action( 'qazvinjobs_import_draft_ready', $ad_id, $source );

    $this->log( $existing_ad_id ? 'به‌روزرسانی' : 'تأیید', 'پیش‌نویس با عنوان کوتاه، متن کامل و مزایای منتقل‌شده ذخیره شد', $payload['title'], $city, $source_url );
    return $ad_id;
}


    private function category_key_from_label( $label ) {
        $map = array(
            'خدمات و پشتیبانی' => 'services-support',
            'منابع انسانی' => 'human-resources',
            'حقوقی و قراردادها' => 'legal-contracts',
            'عمران، ساختمان و معماری' => 'construction-architecture',
            'کشاورزی، دام و صنایع وابسته' => 'agriculture-livestock',
            'تولید و کارگر' => 'industrial-production',
            'فنی و مهندسی' => 'technical-engineering',
            'فناوری اطلاعات' => 'it-digital',
            'فروش و بازاریابی' => 'sales-marketing-commerce',
            'آموزش' => 'education-cultural',
            'رانندگی و حمل‌ونقل' => 'transport-logistics',
            'رستوران و صنایع غذایی' => 'restaurant-food',
            'درمان و سلامت' => 'medical-beauty',
            'مالی و حسابداری' => 'finance-accounting',
            'اداری و منابع انسانی' => 'human-resources',
            'سایر مشاغل' => 'services-support',
        );
        return isset( $map[ $label ] ) ? $map[ $label ] : 'services-support';
    }

    private function assign_category_term( $ad_id, $category_key, $canonical_category_key = '' ) {
        if ( ! class_exists( 'QazvinJobs_Compat' ) || ! class_exists( 'QazvinJobs_Submission' ) ) { return; }
        $taxonomy = QazvinJobs_Compat::ad_taxonomy();
        if ( ! taxonomy_exists( $taxonomy ) ) { return; }

        $lookup_key = sanitize_key( $canonical_category_key ?: $category_key );
        $submission = QazvinJobs_Submission::get_instance();
        if ( $lookup_key && method_exists( $submission, 'get_category_term_by_key' ) ) {
            $term = $submission->get_category_term_by_key( $lookup_key, $taxonomy );
            if ( $term && ! is_wp_error( $term ) ) {
                wp_set_object_terms( $ad_id, array( absint( $term->term_id ) ), $taxonomy, false );
                return;
            }
        }

        // Compatibility fallback for an older core: aliases stay inside the
        // same semantic category and never fall through to a different group.
        $canonical_labels = array(
            'finance-accounting' => array( 'مالی و حسابداری', 'مالی، حسابداری' ),
            'human-resources' => array( 'منابع انسانی' ),
            'admin-office' => array( 'اداری و امور دفتری', 'اداری و دفتری' ),
            'services-support' => array( 'خدمات و پشتیبانی', 'خدماتی و پشتیبانی' ),
            'industrial-production' => array( 'صنعت، تولید و کنترل کیفیت', 'صنعتی، تولیدی و کارگاهی' ),
            'technical-engineering' => array( 'فنی و مهندسی' ),
            'construction-architecture' => array( 'عمران، ساختمان و معماری' ),
            'it-digital' => array( 'فناوری اطلاعات و دیجیتال' ),
            'sales-marketing-commerce' => array( 'فروش، بازاریابی و بازرگانی' ),
            'education-cultural' => array( 'آموزش، مشاوره و فرهنگی', 'آموزش و فرهنگی' ),
            'transport-logistics' => array( 'حمل‌ونقل، انبار و لجستیک', 'حمل‌ونقل و لجستیک' ),
            'restaurant-food' => array( 'رستوران، کافه و صنایع غذایی', 'رستوران، کافه و مواد غذایی' ),
            'medical-beauty' => array( 'پزشکی، درمان، دارو و زیبایی', 'پزشکی، درمانی و زیبایی' ),
            'design-media-content' => array( 'طراحی، رسانه و تولید محتوا' ),
            'legal-contracts' => array( 'حقوقی و قراردادها' ),
            'agriculture-livestock' => array( 'کشاورزی، دام و صنایع وابسته', 'کشاورزی، دامداری و گلخانه' ),
        );
        foreach ( (array) ( $canonical_labels[ $lookup_key ] ?? array() ) as $label ) {
            $term = get_term_by( 'name', $label, $taxonomy );
            if ( $term && ! is_wp_error( $term ) ) {
                wp_set_object_terms( $ad_id, array( absint( $term->term_id ) ), $taxonomy, false );
                return;
            }
        }

        $catalog = $submission->get_category_catalog();
        if ( empty( $catalog[ $lookup_key ]['name'] ) ) { return; }
        $term = get_term_by( 'name', $catalog[ $lookup_key ]['name'], $taxonomy );
        if ( $term && ! is_wp_error( $term ) ) { wp_set_object_terms( $ad_id, array( absint( $term->term_id ) ), $taxonomy, false ); }
    }

    private function assign_city_term( $ad_id, $city ) {
        if ( ! class_exists( 'QazvinJobs_Cities' ) || ! QazvinJobs_Cities::is_available() ) { return; }
        foreach ( QazvinJobs_Cities::get_terms() as $term ) {
            if ( $this->normalize_text( $term->name ) === $this->normalize_text( $city ) ) {
                QazvinJobs_Cities::assign_to_post( $ad_id, $term->term_id );
                return;
            }
        }
    }

    public function reject() {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Forbidden' ); }
        $id = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
        check_admin_referer( 'qzih_item_' . $id );
        if ( self::QUEUE_POST_TYPE === get_post_type( $id ) ) {
            $title = get_the_title( $id ); $city = get_post_meta( $id, '_qzih_city', true ); $url = get_post_meta( $id, '_qzih_source_url', true );
            wp_trash_post( $id ); $this->log( 'رد مدیر', 'مدیر از صف حذف کرد', $title, $city, $url );
        }
        $this->redirect( 'rejected' );
    }

    public function clear_logs() {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'Forbidden' ); }
        check_admin_referer( 'qzih_clear_logs' ); delete_option( 'qzih_logs' ); $this->redirect( 'logs_cleared' );
    }

private function queue_item( $item, $classification ) {
    $post_id = wp_insert_post( array(
        'post_type' => self::QUEUE_POST_TYPE,
        'post_status' => 'pending',
        'post_title' => wp_trim_words( $item['title'], 20, '' ),
        'post_content' => $item['content_html'],
        'post_author' => $this->ensure_import_user(),
    ), true );
    if ( is_wp_error( $post_id ) ) { return $post_id; }

    update_post_meta( $post_id, '_qzih_source', sanitize_key( $item['source'] ?? 'e-estekhdam' ) );
    update_post_meta( $post_id, '_qzih_source_name', sanitize_text_field( $item['source_name'] ?? $this->source_label( $item['source'] ?? '' ) ) );
    update_post_meta( $post_id, '_qzih_source_id', $item['source_id'] );
    update_post_meta( $post_id, '_qzih_source_url', $item['url'] );
    update_post_meta( $post_id, '_qzih_source_title', $item['title'] );
    update_post_meta( $post_id, '_qzih_parent_source_id', sanitize_key( $item['parent_source_id'] ?? '' ) );
    update_post_meta( $post_id, '_qzih_position_index', absint( $item['position_index'] ?? 0 ) );
    update_post_meta( $post_id, '_qzih_position_count', max( 1, absint( $item['position_count'] ?? 1 ) ) );
    update_post_meta( $post_id, '_qzih_multi_position', ! empty( $item['multi_position'] ) ? 1 : 0 );
    update_post_meta( $post_id, '_qzih_role', sanitize_key( $item['role'] ?? $classification['role'] ?? 'employer' ) );
    update_post_meta( $post_id, '_qzih_raw_text', $item['raw_text'] ?? '' );
    update_post_meta( $post_id, '_qzih_source_date', $item['published_at'] );
    update_post_meta( $post_id, '_qzih_city', $classification['city'] );
    update_post_meta( $post_id, '_qzih_contacts', $classification['contacts'] );
    update_post_meta( $post_id, '_qzih_fields', $classification['fields'] );
    update_post_meta( $post_id, '_qzih_source_fields_snapshot', isset( $classification['source_fields_snapshot'] ) ? $classification['source_fields_snapshot'] : array() );
    update_post_meta( $post_id, '_qzih_legacy_category_key', sanitize_key( $classification['legacy_category_key'] ?? '' ) );
    update_post_meta( $post_id, '_qzih_canonical_category_key', sanitize_key( $classification['canonical_category_key'] ?? '' ) );
    update_post_meta( $post_id, '_qzih_specialty_key', sanitize_key( $classification['specialty_key'] ?? '' ) );
    update_post_meta( $post_id, '_qzih_source_category', sanitize_text_field( $classification['source_category'] ?? '' ) );
    update_post_meta( $post_id, '_qzih_fingerprint', $classification['fingerprint'] );
    update_post_meta( $post_id, '_qzih_contact_review_required', ! empty( $classification['contact_review_required'] ) ? 1 : 0 );
    update_post_meta( $post_id, '_qzih_contact_review_label', sanitize_text_field( $classification['contact_review_label'] ?? '' ) );
    update_post_meta( $post_id, '_qzih_contact_reveal', isset( $classification['contact_reveal'] ) && is_array( $classification['contact_reveal'] ) ? $classification['contact_reveal'] : array() );
    update_post_meta( $post_id, '_qzih_controlled_test_no_contact', ! empty( $classification['controlled_test_no_contact'] ) ? 1 : 0 );
    return $post_id;
}



private function test_reimport_matches( $source_id, $url ) {
    $armed = get_transient( 'qzih_test_reimport_once' );
    if ( ! is_array( $armed ) ) { return false; }
    $armed_id = sanitize_key( $armed['source_id'] ?? '' );
    $armed_url = $this->normalize_source_url( $armed['url'] ?? '' );
    $incoming_id = sanitize_key( (string) $source_id );

    if ( $armed_id && $incoming_id && hash_equals( (string) $armed_id, (string) $incoming_id ) ) { return true; }

    // A multi-position E-Estekhdam page sends stable child IDs such as
    // k41uo1-pos-<hash>. They still belong to the armed parent source k41uo1.
    if ( $armed_id && preg_match( '/^(k[a-z0-9]+)-pos-[a-f0-9]{12}(?:-\d+)?$/i', $incoming_id, $m ) ) {
        if ( hash_equals( (string) $armed_id, strtolower( (string) $m[1] ) ) ) { return true; }
    }

    // Redirected/normalized E-Estekhdam slugs can differ while the stable k...
    // identifier remains the same. Prefer that identity over the full slug URL.
    $url_source_id = $url ? $this->source_id_from_url( $url, 'e-estekhdam' ) : '';
    if ( $armed_id && $url_source_id && hash_equals( (string) $armed_id, (string) $url_source_id ) ) { return true; }

    return ( $armed_url && $url && hash_equals( (string) $armed_url, (string) $this->normalize_source_url( $url ) ) );
}

private function consume_test_reimport_if_matches( $source_id, $url ) {
    if ( ! $this->test_reimport_matches( $source_id, $url ) ) { return false; }
    if ( ! $this->is_position_scoped_source_id( $source_id, 'e-estekhdam' ) ) {
        delete_transient( 'qzih_test_reimport_once' );
    }
    return true;
}

private function create_controlled_test_draft( $item, $classification, $original_source_id ) {
    if ( ! class_exists( 'QazvinJobs_Compat' ) ) {
        return array( 'status' => 'errors', 'source_id' => $original_source_id, 'reason' => 'core_missing' );
    }

    $test_source_id = 'qztest-' . sanitize_key( $original_source_id ) . '-' . gmdate( 'YmdHis' );
    $test_item = $item;
    $test_item['source_id'] = $test_source_id;

    $test_classification = $classification;
    $test_classification['fingerprint'] = hash( 'sha256', $classification['fingerprint'] . '|' . $test_source_id );
    if ( ! isset( $test_classification['fields'] ) || ! is_array( $test_classification['fields'] ) ) {
        $test_classification['fields'] = array();
    }
    // فیلد منبع واقعی برای ارزیابی Parser حفظ می‌شود؛ شناسه qztest فقط هویت فنی پیش‌نویس تستی است.
    $test_classification['fields']['source_ad_id'] = $original_source_id;
    $test_classification['fields']['source_url'] = $item['url'];

    $queue_id = $this->queue_item( $test_item, $test_classification );
    if ( is_wp_error( $queue_id ) ) {
        return array( 'status' => 'errors', 'source_id' => $original_source_id, 'reason' => $queue_id->get_error_message() );
    }
    update_post_meta( $queue_id, '_qzih_test_reimport', 1 );
    update_post_meta( $queue_id, '_qzih_original_source_id', $original_source_id );
    update_post_meta( $queue_id, '_qzih_original_source_url', $item['url'] );

    if ( ! get_option( 'qzih_auto_draft', 1 ) ) {
        $this->log( 'تست', 'بازآزمایی یک‌باره در صف مدیر ساخته شد؛ ساخت خودکار پیش‌نویس غیرفعال است', $item['title'], $classification['city'], $item['url'] );
        return array( 'status' => 'accepted', 'source_id' => $original_source_id, 'queue_id' => $queue_id, 'mode' => 'controlled_test_queue' );
    }

    $ad_id = $this->create_ad_draft_from_queue( $queue_id );
    if ( is_wp_error( $ad_id ) ) {
        return array( 'status' => 'errors', 'source_id' => $original_source_id, 'queue_id' => $queue_id, 'reason' => $ad_id->get_error_message() );
    }
    update_post_meta( $ad_id, '_qzih_test_reimport', 1 );
    update_post_meta( $ad_id, '_qz_test_original_source_id', $original_source_id );
    update_post_meta( $ad_id, '_qz_test_original_source_url', $item['url'] );
    update_post_meta( $ad_id, '_qz_import_needs_admin_review', 1 );
    if ( ! empty( $classification['controlled_test_no_contact'] ) ) {
        update_post_meta( $ad_id, '_qz_test_no_direct_contact', 1 );
    }
    $this->log( 'پیش‌نویس تست', 'پیش‌نویس تستی تازه بدون دست‌کاری آگهی منتشرشده یا Duplicate Protection ساخته شد', $item['title'], $classification['city'], $item['url'] );
    return array(
        'status' => 'accepted',
        'source_id' => $original_source_id,
        'queue_id' => absint( $queue_id ),
        'ad_id' => absint( $ad_id ),
        'mode' => 'controlled_test_reimport',
        'test_source_id' => $test_source_id,
    );
}

private function recover_existing_ad( $item, $classification ) {
    if ( ! class_exists( 'QazvinJobs_Compat' ) ) { return false; }
    $source_id = (string) $item['source_id'];
    $url = (string) $item['url'];
    $source = sanitize_key( $item['source'] ?? '' );

    // ادعای منبع نسخه‌های قدیمی روی آگهی‌های عادی را جدا کن؛ این آگهی‌ها هرگز قابل بازیابی نیستند.
    $legacy = get_posts( array(
        'post_type' => QazvinJobs_Compat::ad_post_types(),
        'post_status' => array( 'publish', 'pending', 'draft', 'private', 'future', 'trash' ),
        'posts_per_page' => 50,
        'fields' => 'ids',
        'meta_query' => $this->identity_meta_query( $source_id, $url, $source, '_qz_source_id', '_qz_source_url' ),
    ) );
    foreach ( $legacy as $legacy_id ) {
        if ( (int) get_post_meta( $legacy_id, '_qz_import_hub_owned', true ) ) { continue; }
        delete_post_meta( $legacy_id, '_qz_source_name' );
        delete_post_meta( $legacy_id, '_qz_source_id' );
        delete_post_meta( $legacy_id, '_qz_source_url' );
        delete_post_meta( $legacy_id, '_qz_import_needs_admin_review' );
        delete_post_meta( $legacy_id, '_qz_import_hub_version' );
        $this->log( 'اصلاح', 'پیوند منبع اشتباه از آگهی قدیمی و نامرتبط جدا شد', get_the_title( $legacy_id ), '', $url );
    }

    $existing = get_posts( array(
        'post_type' => QazvinJobs_Compat::ad_post_types(),
        'post_status' => array( 'publish', 'pending', 'draft', 'private' ),
        'posts_per_page' => 1,
        'fields' => 'ids',
        'orderby' => 'ID', 'order' => 'DESC',
        'meta_query' => array(
            'relation' => 'AND',
            array( 'key' => '_qz_import_hub_owned', 'value' => '1' ),
            $this->identity_meta_query( $source_id, $url, $source, '_qz_source_id', '_qz_source_url' ),
        ),
    ) );
    if ( ! $existing ) { return false; }
    $ad_id = absint( $existing[0] );
    $ad = get_post( $ad_id );
    if ( ! $ad ) { return false; }
    if ( 'publish' === $ad->post_status ) {
        $this->log( 'رد', 'آگهی وارداتی همین منبع قبلاً توسط مدیر منتشر شده است (ID ' . $ad_id . ')؛ برای تست دوباره از بخش بازآزمایی کنترل‌شده استفاده کنید', $item['title'], $classification['city'], $url );
        return array( 'status' => 'duplicates', 'source_id' => $source_id, 'ad_id' => $ad_id, 'reason' => 'already_published' );
    }

    $queue_ids = get_posts( array(
        'post_type' => self::QUEUE_POST_TYPE,
        'post_status' => array( 'pending', 'draft', 'trash' ),
        'posts_per_page' => 1, 'fields' => 'ids', 'orderby' => 'ID', 'order' => 'DESC',
        'meta_query' => $this->identity_meta_query( $source_id, $url, $source, '_qzih_source_id', '_qzih_source_url' ),
    ) );
    if ( $queue_ids ) {
        $queue_id = absint( $queue_ids[0] );
        if ( 'trash' === get_post_status( $queue_id ) ) { wp_untrash_post( $queue_id ); }
        wp_update_post( array( 'ID' => $queue_id, 'post_status' => 'draft', 'post_title' => wp_trim_words( $item['title'], 20, '' ), 'post_content' => $item['content_html'] ) );
        update_post_meta( $queue_id, '_qzih_source', sanitize_key( $item['source'] ?? 'e-estekhdam' ) );
        update_post_meta( $queue_id, '_qzih_source_name', sanitize_text_field( $item['source_name'] ?? $this->source_label( $item['source'] ?? '' ) ) );
        update_post_meta( $queue_id, '_qzih_source_title', $item['title'] );
        update_post_meta( $queue_id, '_qzih_parent_source_id', sanitize_key( $item['parent_source_id'] ?? '' ) );
        update_post_meta( $queue_id, '_qzih_position_index', absint( $item['position_index'] ?? 0 ) );
        update_post_meta( $queue_id, '_qzih_position_count', max( 1, absint( $item['position_count'] ?? 1 ) ) );
        update_post_meta( $queue_id, '_qzih_multi_position', ! empty( $item['multi_position'] ) ? 1 : 0 );
        update_post_meta( $queue_id, '_qzih_role', sanitize_key( $item['role'] ?? $classification['role'] ?? 'employer' ) );
        update_post_meta( $queue_id, '_qzih_raw_text', $item['raw_text'] ?? '' );
        update_post_meta( $queue_id, '_qzih_city', $classification['city'] );
        update_post_meta( $queue_id, '_qzih_contacts', $classification['contacts'] );
        update_post_meta( $queue_id, '_qzih_fields', $classification['fields'] );
        update_post_meta( $queue_id, '_qzih_source_fields_snapshot', isset( $classification['source_fields_snapshot'] ) ? $classification['source_fields_snapshot'] : array() );
        update_post_meta( $queue_id, '_qzih_legacy_category_key', sanitize_key( $classification['legacy_category_key'] ?? '' ) );
        update_post_meta( $queue_id, '_qzih_canonical_category_key', sanitize_key( $classification['canonical_category_key'] ?? '' ) );
        update_post_meta( $queue_id, '_qzih_specialty_key', sanitize_key( $classification['specialty_key'] ?? '' ) );
        update_post_meta( $queue_id, '_qzih_source_category', sanitize_text_field( $classification['source_category'] ?? '' ) );
        update_post_meta( $queue_id, '_qzih_fingerprint', $classification['fingerprint'] );
        update_post_meta( $queue_id, '_qzih_contact_review_required', ! empty( $classification['contact_review_required'] ) ? 1 : 0 );
        update_post_meta( $queue_id, '_qzih_contact_review_label', sanitize_text_field( $classification['contact_review_label'] ?? '' ) );
        update_post_meta( $queue_id, '_qzih_contact_reveal', isset( $classification['contact_reveal'] ) && is_array( $classification['contact_reveal'] ) ? $classification['contact_reveal'] : array() );
    } else {
        $queue_id = $this->queue_item( $item, $classification );
        if ( is_wp_error( $queue_id ) ) { return $queue_id; }
        wp_update_post( array( 'ID' => absint( $queue_id ), 'post_status' => 'draft' ) );
    }
    update_post_meta( $queue_id, '_qzih_created_ad_id', $ad_id );
    $updated_ad_id = $this->create_ad_draft_from_queue( $queue_id );
    if ( is_wp_error( $updated_ad_id ) ) { return $updated_ad_id; }
    $this->remember_seen( $source_id, 'draft_created', $classification['fingerprint'] );
    $this->log( 'بازیابی', 'پیش‌نویس هم‌منبع با نگاشت و متن جدید به‌روزرسانی شد', $item['title'], $classification['city'], $url );
    return array( 'status' => 'accepted', 'source_id' => $source_id, 'queue_id' => absint( $queue_id ), 'ad_id' => $updated_ad_id, 'mode' => 'recovered_owned_draft' );
}


    private function purge_stale_queue_for_source( $source_id, $url, $source = '' ) {
        $ids = get_posts( array(
            'post_type'      => self::QUEUE_POST_TYPE,
            'post_status'    => array( 'pending', 'draft', 'trash' ),
            'posts_per_page' => 100,
            'fields'         => 'ids',
            'meta_query'     => $this->identity_meta_query( $source_id, $url, $source, '_qzih_source_id', '_qzih_source_url' ),
        ) );
        foreach ( $ids as $queue_id ) {
            $created_id = absint( get_post_meta( $queue_id, '_qzih_created_ad_id', true ) );
            if ( ! $created_id || ! get_post( $created_id ) ) {
                wp_delete_post( $queue_id, true );
            }
        }
    }

    private function is_duplicate( $source_id, $fingerprint, $url, $source = '' ) {
        $queue = get_posts( array(
            'post_type' => self::QUEUE_POST_TYPE,
            'post_status' => array( 'pending', 'draft' ),
            'posts_per_page' => 1, 'fields' => 'ids',
            'meta_query' => $this->identity_meta_query( $source_id, $url, $source, '_qzih_source_id', '_qzih_source_url' ),
        ) );
        if ( $queue ) { return true; }
        if ( class_exists( 'QazvinJobs_Compat' ) ) {
            $existing = get_posts( array(
                'post_type' => QazvinJobs_Compat::ad_post_types(),
                'post_status' => array( 'publish', 'pending', 'draft', 'private' ),
                'posts_per_page' => 1, 'fields' => 'ids',
                'meta_query' => array(
                    'relation' => 'AND',
                    array( 'key' => '_qz_import_hub_owned', 'value' => '1' ),
                    $this->identity_meta_query( $source_id, $url, $source, '_qz_source_id', '_qz_source_url' ),
                ),
            ) );
            if ( $existing ) { return true; }
        }
        $seen_key = 'qzih_seen_' . md5( $source_id );
        $seen = get_option( $seen_key, array() );
        if ( is_array( $seen ) && ! empty( $seen['fingerprint'] ) && hash_equals( (string) $seen['fingerprint'], (string) $fingerprint ) ) {
            $status = sanitize_key( $seen['status'] ?? '' );
            $age = time() - absint( $seen['time'] ?? 0 );
            $is_divar = 0 === strpos( (string) $source_id, 'divar-' );
            if ( $is_divar && in_array( $status, array( 'no_contact', 'invalid', 'review_queue' ), true ) ) {
                delete_option( $seen_key );
            } elseif ( in_array( $status, array( 'no_location', 'no_contact', 'invalid' ), true ) && $age < 12 * HOUR_IN_SECONDS ) {
                return true;
            } else {
                delete_option( $seen_key );
            }
        }
        return false;
    }

    private function is_position_scoped_source_id( $source_id, $source = '' ) {
        $source_id = sanitize_key( (string) $source_id );
        $source = sanitize_key( (string) $source );
        return 'e-estekhdam' === $source && false !== strpos( $source_id, '-pos-' );
    }

    private function identity_meta_query( $source_id, $url, $source, $id_key, $url_key ) {
        $source_id = sanitize_key( (string) $source_id );
        $url = $this->normalize_source_url( $url );
        if ( $this->is_position_scoped_source_id( $source_id, $source ) ) {
            // A multi-position E-Estekhdam page intentionally shares one URL
            // across several independent jobs. URL must never collapse siblings.
            return array( array( 'key' => $id_key, 'value' => $source_id ) );
        }
        return array(
            'relation' => 'OR',
            array( 'key' => $id_key, 'value' => $source_id ),
            array( 'key' => $url_key, 'value' => $url ),
        );
    }

    private function remember_seen( $source_id, $status, $fingerprint ) { update_option( 'qzih_seen_' . md5( $source_id ), array( 'status' => sanitize_key( $status ), 'fingerprint' => $fingerprint, 'time' => time() ), false ); }
    private function queue_count() { $counts = wp_count_posts( self::QUEUE_POST_TYPE ); return isset( $counts->pending ) ? absint( $counts->pending ) : 0; }

private function normalize_source_url( $url ) {
    $url = esc_url_raw( trim( (string) $url ) );
    if ( ! $url ) { return ''; }

    $host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
    $path = (string) wp_parse_url( $url, PHP_URL_PATH );
    if ( ! $host || ! $path ) { return ''; }

    // پارامترهایی مانند ref=android در اعتبار آگهی نقشی ندارند و ممکن است
    // بین لینک اپ و وب متفاوت باشند؛ لینک منبع به فرم پایدار تبدیل می‌شود.
    return esc_url_raw( 'https://' . $host . '/' . ltrim( $path, '/' ) );
}

private function normalize_source_id( $raw_source_id, $url, $source ) {
    $raw_source_id = sanitize_key( (string) $raw_source_id );

    if ( 'divar' === $source ) {
        $raw_source_id = preg_replace( '/^divar-/', '', $raw_source_id );
        if ( $raw_source_id && 'divar' !== $raw_source_id ) {
            return 'divar-' . $raw_source_id;
        }
    } elseif ( $raw_source_id ) {
        return $raw_source_id;
    }

    return $this->source_id_from_url( $url, $source );
}

private function source_id_from_url( $url, $source = '' ) {
    $source = $source ?: $this->detect_source_from_url( $url );
    $path = trim( (string) wp_parse_url( $url, PHP_URL_PATH ), '/' );
    if ( 'e-estekhdam' === $source && preg_match( '#(?:^|/)(k[a-z0-9]+)(?:-|/|$)#i', '/' . $path, $m ) ) {
        return strtolower( $m[1] );
    }
    if ( 'divar' === $source ) {
        $parts = array_values( array_filter( explode( '/', rawurldecode( $path ) ) ) );
        if ( $parts && 'v' === strtolower( (string) reset( $parts ) ) ) { array_shift( $parts ); }

        // دیوار دو قالب معتبر دارد:
        // /v/{token} و /v/{slug}/{token}. توکن معمولاً لاتین است.
        foreach ( array_reverse( $parts ) as $part ) {
            if ( preg_match( '/^[a-z0-9_-]{5,}$/i', (string) $part ) ) {
                return 'divar-' . strtolower( sanitize_key( $part ) );
            }
        }

        // اگر دیوار قالب لینک را تغییر دهد، به‌جای ردکردن آگهی یک شناسه پایدار
        // از خود URL ساخته می‌شود تا دریافت و جلوگیری از تکرار ادامه پیدا کند.
        return $url ? 'divar-url-' . substr( md5( $url ), 0, 20 ) : '';
    }
    return '';
}

private function is_job_url( $url, $source = '' ) {
    $source = $source ?: $this->detect_source_from_url( $url );
    $path = (string) wp_parse_url( $url, PHP_URL_PATH );
    if ( 'e-estekhdam' === $source ) { return (bool) preg_match( '#^/k[a-z0-9]+(?:-|/|$)#i', $path ); }
    if ( 'divar' === $source ) {
        // پشتیبانی از لینک اشتراک‌گذاری اپ /v/{token} و لینک کامل وب
        // /v/{slug}/{token}؛ query string توسط wp_parse_url از path جدا شده است.
        return 0 === strpos( $path, '/v/' ) && strlen( trim( $path, '/' ) ) > 2;
    }
    return false;
}



    private function contact_review_queue_count() {
        $query = new WP_Query( array(
            'post_type'      => self::QUEUE_POST_TYPE,
            'post_status'    => 'pending',
            'posts_per_page' => 1,
            'fields'         => 'ids',
            'meta_query'     => array(
                array( 'key' => '_qzih_contact_review_required', 'value' => '1' ),
            ),
        ) );
        return absint( $query->found_posts );
    }


    /**
     * Keep structured crawler values intact, sanitize recursively, and let the
     * canonical contract (QazvinJobs 2.3.7+) normalize only known public keys.
     */
    private function sanitize_source_fields( $fields ) {
        $fields = is_array( $fields ) ? $fields : array();
        $clean = array();
        foreach ( $fields as $key => $value ) {
            $key = sanitize_key( (string) $key );
            if ( ! $key ) { continue; }
            if ( is_array( $value ) ) {
                $values = array();
                foreach ( $value as $v ) {
                    if ( is_scalar( $v ) && '' !== trim( (string) $v ) ) { $values[] = sanitize_text_field( (string) $v ); }
                }
                $clean[ $key ] = array_values( array_unique( $values ) );
            } elseif ( is_scalar( $value ) ) {
                $clean[ $key ] = sanitize_text_field( (string) $value );
            }
        }
        return $clean;
    }

    private function normalize_qazvin_city_name( $value ) {
        $value = $this->normalize_text( (string) $value );
        if ( ! $value ) { return ''; }
        $aliases = array(
            'بوئین زهرا' => 'بوئین‌زهرا',
            'بوئین‌زهرا' => 'بوئین‌زهرا',
        );
        if ( isset( $aliases[ $value ] ) ) { return $aliases[ $value ]; }

        $cities = array(
            'محمودآباد نمونه','بوئین‌زهرا','معلم کلایه','دانسفهان','اسفرورین','ضیاءآباد',
            'محمدیه','اقبالیه','خرمدشت','تاکستان','آبیک','الوند','آوج','آبگرم','رازمیان',
            'کوهین','سیردان','نرجه','ارداق','سگزآباد','خاکعلی','بیدستان','شال','قزوین'
        );
        foreach ( $cities as $city ) {
            if ( $this->normalize_text( $city ) === $value ) { return $city; }
        }

        // Trusted location strings may contain province/region too. Prefer an
        // explicit "شهر ..." fragment instead of the first arbitrary city name.
        if ( preg_match( '/(?:شهر|محل\s*کار|موقعیت)\s*[:：\-]?\s*([^،؛|\n]{2,40})/u', $value, $m ) ) {
            $candidate = trim( $m[1] );
            foreach ( $cities as $city ) {
                if ( $this->contains( $candidate, $city ) ) { return $city; }
            }
        }
        return '';
    }

    private function city_from_title( $title ) {
        $title = $this->normalize_text( $title );
        $cities = array(
            'محمودآباد نمونه','بوئین زهرا','بوئین‌زهرا','معلم کلایه','دانسفهان','اسفرورین','ضیاءآباد',
            'محمدیه','اقبالیه','خرمدشت','تاکستان','آبیک','الوند','آوج','آبگرم','رازمیان',
            'کوهین','سیردان','نرجه','ارداق','سگزآباد','خاکعلی','بیدستان','شال','قزوین'
        );
        foreach ( $cities as $city ) {
            $pattern = '/(?:^|\s|در|شهر|استان)[\s،\-]*' . preg_quote( str_replace( 'بوئین زهرا', 'بوئین‌زهرا', $this->normalize_text( $city ) ), '/' ) . '(?:$|\s|،|\-|\/)/u';
            if ( preg_match( $pattern, $title . ' ' ) ) {
                return str_replace( 'بوئین زهرا', 'بوئین‌زهرا', $city );
            }
        }
        return '';
    }

    private function resolve_city_source_first( $raw, $source_fields, $title, $plain_content, $source ) {
        $trusted = array(
            $source_fields['city_name'] ?? '',
            $source_fields['source_city'] ?? '',
            $raw['city_exact'] ?? '',
            $raw['location_city'] ?? '',
        );
        foreach ( $trusted as $candidate ) {
            $city = $this->normalize_qazvin_city_name( $candidate );
            if ( $city ) { return $city; }
        }

        // E-estekhdam H1 normally carries the actual city and is substantially
        // safer than scanning the page body (which contains similar ads).
        $city = $this->city_from_title( $title );
        if ( $city ) { return $city; }

        // Only trust crawler "city" directly when 0.3.17+ also states how it
        // was obtained. Old 0.3.15 could derive it from the whole page.
        if ( ! empty( $raw['city_source'] ) ) {
            $city = $this->normalize_qazvin_city_name( $raw['city'] ?? '' );
            if ( $city ) { return $city; }
        }

        $location_section = $this->extract_section(
            $plain_content,
            array( 'محل کار', 'موقعیت مکانی', 'آدرس محل کار' ),
            array( 'اطلاعات تماس', 'آگهی‌های استخدام مشابه', 'آگهی های استخدام مشابه', 'مشاغل مشابه' )
        );
        if ( $location_section ) {
            $city = $this->detect_qazvin_city( $location_section );
            if ( $city ) { return $city; }
        }

        // Divar candidates come from a configured city feed. New crawler sends
        // city_source=feed; this fallback only protects direct/legacy tests.
        if ( 'divar' === $source && 'قزوین' === sanitize_text_field( $raw['city'] ?? '' ) ) {
            return 'قزوین';
        }
        return '';
    }

    private function canonical_job_title( $source_title, $city = '' ) {
        $title = sanitize_text_field( $source_title );
        $title = preg_replace( '/^\s*استخدام\s+/u', '', $title );
        $title = preg_replace( '/\s*[-–|].*(?:ای\s*استخدام|دیوار).*$/u', '', $title );
        if ( $city ) {
            $title = preg_replace( '/\s+(?:در|استان|شهر)\s+' . preg_quote( $city, '/' ) . '\s*$/u', '', $title );
        }
        return trim( preg_replace( '/\s+/u', ' ', $title ), " -–|،" );
    }

    private function salary_display_from_fields( $fields ) {
        $fields = is_array( $fields ) ? $fields : array();
        if ( ! empty( $fields['salary_negotiable'] ) || ( isset( $fields['salary_range'] ) && 'توافقی' === $fields['salary_range'] ) ) {
            return 'توافقی';
        }
        $min = isset( $fields['salary_min'] ) ? trim( (string) $fields['salary_min'] ) : '';
        $max = isset( $fields['salary_max'] ) ? trim( (string) $fields['salary_max'] ) : '';
        $period = sanitize_text_field( $fields['salary_period'] ?? '' );
        if ( $min || $max ) {
            if ( $min && $max ) { $value = $min . ' تا ' . $max; }
            elseif ( $min ) { $value = 'از ' . $min; }
            else { $value = 'تا ' . $max; }
            return trim( $value . ( $period ? ' ' . $period : ' میلیون تومان / ماه' ) );
        }
        return trim( (string) ( $fields['salary_structure'] ?? '' ) . ' | ' . (string) ( $fields['salary_range'] ?? '' ), ' |' );
    }

    private function has_explicit_salary_fields( $fields ) {
        $fields = is_array( $fields ) ? $fields : array();
        if ( ! empty( $fields['salary_negotiable'] ) ) { return true; }
        foreach ( array( 'salary_min', 'salary_max', 'salary_range', 'salary_structure', 'salary_period' ) as $key ) {
            if ( isset( $fields[ $key ] ) && '' !== trim( (string) $fields[ $key ] ) ) { return true; }
        }
        return false;
    }

    private function canonical_category_label( $key ) {
        $key = sanitize_key( $key );
        if ( class_exists( 'QazvinJobs_Job_Contract' ) && method_exists( 'QazvinJobs_Job_Contract', 'category_registry' ) ) {
            $registry = QazvinJobs_Job_Contract::category_registry();
            if ( isset( $registry[ $key ] ) ) { return sanitize_text_field( $registry[ $key ] ); }
        }
        $fallback = array(
            'finance-accounting'=>'مالی و حسابداری','admin-office'=>'اداری و امور دفتری','human-resources'=>'منابع انسانی',
            'sales-marketing-commerce'=>'فروش، بازاریابی و بازرگانی','it-digital'=>'فناوری اطلاعات و دیجیتال',
            'technical-engineering'=>'فنی و مهندسی','industrial-production'=>'صنعت، تولید و کنترل کیفیت',
            'construction-architecture'=>'عمران، ساختمان و معماری','services-support'=>'خدمات و پشتیبانی',
            'transport-logistics'=>'حمل‌ونقل، انبار و لجستیک','restaurant-food'=>'رستوران، کافه و صنایع غذایی',
            'medical-beauty'=>'پزشکی، درمان، دارو و زیبایی','education-cultural'=>'آموزش، مشاوره و فرهنگی',
            'design-media-content'=>'طراحی، رسانه و تولید محتوا','legal-contracts'=>'حقوقی و قراردادها',
            'agriculture-livestock'=>'کشاورزی، دام و صنایع وابسته',
        );
        return $fallback[ $key ] ?? $key;
    }

    private function specialty_label( $category_key, $specialty_key ) {
        $category_key = sanitize_key( $category_key );
        $specialty_key = sanitize_key( $specialty_key );
        if ( ! $specialty_key ) { return ''; }
        if ( class_exists( 'QazvinJobs_Job_Contract' ) && method_exists( 'QazvinJobs_Job_Contract', 'specialty_registry' ) ) {
            $registry = QazvinJobs_Job_Contract::specialty_registry();
            if ( isset( $registry[ $category_key ][ $specialty_key ] ) ) { return sanitize_text_field( $registry[ $category_key ][ $specialty_key ] ); }
        }
        return $specialty_key;
    }

    private function merge_source_and_fallback_fields( $source_fields, $text, $city, $title, $role, $source = '' ) {
        $source = sanitize_key( $source );

        // E-Estekhdam is a structured source. Never re-parse the whole page here:
        // the page contains similar-job cards and navigation hints that can create
        // false salary/benefit/category values. The crawler payload is authoritative.
        if ( 'e-estekhdam' === $source ) {
            $fields = is_array( $source_fields ) ? $source_fields : array();

            // An explicit empty benefit list is meaningful: it prevents legacy
            // fallback text from turning unrelated words such as «غذا» into a benefit.
            if ( ! array_key_exists( 'benefits_list', $fields ) ) {
                $fields['benefits_list'] = array();
            }

            // Older/edge E-Estekhdam chips may only say «دارای سابقه کار» while
            // the numeric requirement is inside «شرایط احراز». Recover it locally.
            if ( empty( $fields['experience_years'] ) ) {
                $experience_text = trim( implode( ' ', array_filter( array(
                    $fields['requirements'] ?? '',
                    $fields['technical_skills'] ?? '',
                    $fields['job_description'] ?? '',
                ) ) ) );
                $experience = $this->extract_experience_value( $experience_text );
                if ( $experience ) { $fields['experience_years'] = $experience; }
            }

            // Software/tools are canonical across all categories. Keep office_tools
            // only as a temporary display alias for older installed UIs.
            if ( empty( $fields['office_tools'] ) && empty( $fields['software_tools'] ) ) {
                $tool_text = trim( implode( ' ', array_filter( array(
                    $fields['requirements'] ?? '',
                    $fields['technical_skills'] ?? '',
                    $fields['job_description'] ?? '',
                ) ) ) );
                $tools = $this->extract_software_tools_value( $tool_text );
                if ( $tools ) {
                    $fields['office_tools'] = $tools;
                    $fields['software_tools'] = $tools;
                }
            }

            // Salary is intentionally absent when the source has no explicit
            // salary field. Never infer it from page text such as similar-salary links.
            if ( isset( $fields['salary_range'] ) && preg_match( '/حقوق\s+افراد\s+دارای\s+شغل\s+مشابه|حقوق\s+شغل\s+مشابه/u', (string) $fields['salary_range'] ) ) {
                unset( $fields['salary_range'], $fields['salary_structure'], $fields['salary_negotiable'], $fields['salary_min'], $fields['salary_max'], $fields['salary_period'] );
            }

            $fields = $this->enrich_explicit_source_fields( $fields, $source );

            if ( class_exists( 'QazvinJobs_Field_Schema' ) ) {
                $normalized_fields = QazvinJobs_Field_Schema::normalize_values( $fields, $role );
                if ( is_array( $normalized_fields ) ) { $fields = array_merge( $fields, $normalized_fields ); }
            }
            return $this->validate_import_field_values( $fields, $role );
        }

        if ( 'divar' === $source ) {
            // Divar is source-first too. Never fill a missing select from the full
            // page because related-ad cards can contain unrelated salary/benefit
            // values. Fallback is limited to text that the crawler already scoped
            // into the current ad's structured fields.
            $fields = is_array( $source_fields ) ? $source_fields : array();
            $trusted_parts = array(
                $fields['requirements'] ?? '',
                $fields['technical_skills'] ?? '',
                $fields['job_description'] ?? '',
                $fields['benefits_description'] ?? '',
            );
            $trusted_text = $this->normalize_text( implode( ' ', array_filter( $trusted_parts ) ) );
            if ( $trusted_text ) {
                $fallback = $this->map_trusted_fields( $trusted_text, $city, $title, $role );
                foreach ( $fallback as $key => $value ) {
                    if ( ! array_key_exists( $key, $fields ) || '' === $fields[ $key ] || null === $fields[ $key ] ) {
                        $fields[ $key ] = $value;
                    }
                }
            }
            $fields = $this->enrich_explicit_source_fields( $fields, $source );
            if ( class_exists( 'QazvinJobs_Field_Schema' ) ) {
                $normalized_fields = QazvinJobs_Field_Schema::normalize_values( $fields, $role );
                if ( is_array( $normalized_fields ) ) { $fields = array_merge( $fields, $normalized_fields ); }
            }
            return $this->validate_import_field_values( $fields, $role );
        }

        $fallback = $this->map_trusted_fields( $text, $city, $title, $role );
        $fields = $fallback;
        foreach ( (array) $source_fields as $key => $value ) {
            if ( '' === $value || null === $value ) { continue; }
            // For arrays, an explicit empty list is authoritative and must replace fallback.
            if ( is_array( $value ) ) {
                $fields[ sanitize_key( $key ) ] = $value;
                continue;
            }
            $fields[ sanitize_key( $key ) ] = $value;
        }
        $fields = $this->enrich_explicit_source_fields( $fields, $source );
        if ( class_exists( 'QazvinJobs_Field_Schema' ) ) {
            $normalized_fields = QazvinJobs_Field_Schema::normalize_values( $fields, $role );
            if ( is_array( $normalized_fields ) ) { $fields = array_merge( $fields, $normalized_fields ); }
        }
        return $this->validate_import_field_values( $fields, $role );
    }

    /**
     * Import-only validation guard. Structured sources may occasionally put a
     * whole requirement sentence into a select field when a label is missing.
     * Keep free-text data in requirements/technical_skills, but never persist
     * arbitrary sentences in canonical select/multiselect fields.
     */
    private function canonical_options( $key, $role, $fallback = array() ) {
        if ( class_exists( 'QazvinJobs_Field_Schema' ) ) {
            $options = QazvinJobs_Field_Schema::options( $key, $role );
            if ( is_array( $options ) && $options ) { return $options; }
        }
        return $fallback;
    }

    private function validate_import_field_values( $fields, $role = '' ) {
        $fields = is_array( $fields ) ? $fields : array();
        $role = sanitize_key( $role );
        if ( class_exists( 'QazvinJobs_Field_Schema' ) ) { $fields = QazvinJobs_Field_Schema::normalize_values( $fields, $role ); }

        $selects = array(
            'cooperation_type' => $this->canonical_options( 'cooperation_type', $role, array( 'تمام‌وقت','پاره‌وقت','پروژه‌ای / پیمانکاری','کارآموزی','ساعتی / روزانه','فریلنسری' ) ),
            'workplace_mode' => $this->canonical_options( 'workplace_mode', $role, array( 'حضوری','دورکاری','ترکیبی' ) ),
            'schedule_mode' => $this->canonical_options( 'schedule_mode', $role, array( 'ثابت','شیفتی','شناور','توافقی' ) ),
            'experience_years' => $this->canonical_options( 'experience_years', $role, array( 'بدون نیاز به سابقه','کمتر از ۱ سال','۱ تا ۳ سال','۳ تا ۵ سال','بیشتر از ۵ سال' ) ),
            'education_level' => $this->canonical_options( 'education_level', $role, array( 'مهم نیست','زیر دیپلم','دیپلم','کاردانی','کارشناسی','کارشناسی ارشد','دکتری','فنی و حرفه‌ای' ) ),
            'age_range' => $this->canonical_options( 'age_range', $role, array( 'مهم نیست','۱۸ تا ۲۴ سال','۲۵ تا ۳۰ سال','۳۱ تا ۳۵ سال','۳۶ تا ۴۰ سال','۴۱ تا ۵۰ سال','بیشتر از ۵۰ سال' ) ),
            'military_status' => $this->canonical_options( 'military_status', $role, array( 'مهم نیست','پایان خدمت / معافیت الزامی','مشمول هم پذیرفته می‌شود' ) ),
            'vacancy_count' => $this->canonical_options( 'vacancy_count', $role, array( '۱ نفر','۲ نفر','۳ نفر','۴ تا ۵ نفر','۶ تا ۱۰ نفر','بیشتر از ۱۰ نفر' ) ),
            'seniority_level' => $this->canonical_options( 'seniority_level', $role, array( 'کارآموز','تازه‌کار','کارشناس','کارشناس ارشد','سرپرست','مدیر','مدیر ارشد' ) ),
            'insurance' => $this->canonical_options( 'insurance', $role, array( 'بیمه دارد','بیمه از روز اول','بیمه پس از دوره آزمایشی','بیمه ندارد','قابل مذاکره' ) ),
            'contract_type' => $this->canonical_options( 'contract_type', $role, array( 'قرارداد کار موقت','قرارداد کار دائم','قرارداد پروژه‌ای','پیمانکاری','کارآموزی','توافقی' ) ),
            'hiring_timeline' => $this->canonical_options( 'hiring_timeline', $role, array( 'فوری','در اولین فرصت','تا پایان هفته','تا پایان ماه','تا تکمیل ظرفیت','شروع از تاریخ مشخص' ) ),
            'trial_period' => $this->canonical_options( 'trial_period', $role, array( 'ندارد','۱ هفته','۱ ماه','۲ ماه','۳ ماه','توافقی' ) ),
            'overtime' => $this->canonical_options( 'overtime', $role, array( 'ندارد','اختیاری با پرداخت','الزامی با پرداخت','گاهی موردنیاز','توافقی' ) ),
            'disability_support' => $this->canonical_options( 'disability_support', $role, array( 'بررسی می‌شود','امکان‌پذیر است','برای این موقعیت امکان‌پذیر نیست' ) ),
            'work_environment' => $this->canonical_options( 'work_environment', $role, array( 'دفتر اداری','فروشگاه','کارگاه','کارخانه','پروژه / کارگاه ساختمانی','محیط درمانی','میدانی','منزل / دورکاری','سایر' ) ),
            'salary_structure' => $this->canonical_options( 'salary_structure', $role, array( 'توافقی','مطابق قانون کار','حقوق ثابت ماهانه','ثابت + پورسانت','پورسانتی','ساعتی','روزانه','پروژه‌ای' ) ),
        );
        if ( 'job_seeker' === $role ) {
            $selects['gender'] = $this->canonical_options( 'gender', $role, array( 'ترجیح می‌دهم اعلام نکنم','خانم','آقا' ) );
        } else {
            $selects['gender_preference'] = $this->canonical_options( 'gender_preference', $role, array( 'مهم نیست','خانم','آقا' ) );
        }
        foreach ( $selects as $key => $allowed ) {
            if ( ! array_key_exists( $key, $fields ) ) { continue; }
            $value = sanitize_text_field( is_scalar( $fields[ $key ] ) ? $fields[ $key ] : '' );
            if ( ! in_array( $value, $allowed, true ) ) { unset( $fields[ $key ] ); }
            else { $fields[ $key ] = $value; }
        }

        $multiselects = array(
            'preferred_shift' => $this->canonical_options( 'preferred_shift', '', array( 'صبح','عصر','شب','چرخشی' ) ),
            'soft_skills' => $this->canonical_options( 'soft_skills', '', array( 'ارتباط مؤثر','فن بیان','کار تیمی','حل مسئله','مسئولیت‌پذیری','نظم','پیگیری','مدیریت زمان','مذاکره','دقت','یادگیری سریع','خلاقیت' ) ),
            'interview_method' => $this->canonical_options( 'interview_method', $role, array( 'تماس اولیه','مصاحبه آنلاین','مصاحبه حضوری','آزمون تخصصی','تست عملی','استعلام معرف' ) ),
            'required_documents' => $this->canonical_options( 'required_documents', '', array( 'رزومه','نمونه‌کار','مدرک تحصیلی','گواهی دوره','گواهینامه رانندگی','معرف شغلی' ) ),
            'work_days' => $this->canonical_options( 'work_days', '', array( 'شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه' ) ),
            'benefits_list' => $this->canonical_options( 'benefits_list', $role, array( 'بیمه تکمیلی','پاداش','پورسانت','سرویس رفت‌وبرگشت','صبحانه','ناهار / غذا','جای خواب','وام','آموزش رایگان','ساعت منعطف','هدایا','پارکینگ','بن / بسته خرید','کمک‌هزینه درمان','بیمه عمر','کمک‌هزینه رفت‌وآمد' ) ),
        );
        foreach ( $multiselects as $key => $allowed ) {
            if ( ! array_key_exists( $key, $fields ) ) { continue; }
            $values = is_array( $fields[ $key ] ) ? $fields[ $key ] : array( $fields[ $key ] );
            $values = array_values( array_unique( array_filter( array_map( 'sanitize_text_field', $values ) ) ) );
            $fields[ $key ] = array_values( array_intersect( $allowed, $values ) );
        }

        foreach ( array( 'age_min','age_max' ) as $key ) {
            if ( ! array_key_exists( $key, $fields ) ) { continue; }
            $n = absint( $fields[ $key ] );
            if ( $n < 14 || $n > 99 ) { unset( $fields[ $key ] ); }
            else { $fields[ $key ] = $n; }
        }
        if ( isset( $fields['age_min'], $fields['age_max'] ) && $fields['age_min'] > $fields['age_max'] ) {
            unset( $fields['age_min'], $fields['age_max'] );
        }

        return $fields;
    }

    private function extract_experience_value( $text ) {
        $text = $this->normalize_text( $text );
        if ( ! $text ) { return ''; }
        if ( preg_match( '/بدون\s*(?:نیاز\s*به\s*)?سابقه|سابقه\s*(?:کار)?\s*مهم\s*نیست/u', $text ) ) { return 'بدون نیاز به سابقه'; }
        $words = array( 'نیم'=>'0.5', 'یک'=>'1', 'دو'=>'2', 'سه'=>'3', 'چهار'=>'4', 'پنج'=>'5', 'شش'=>'6', 'هفت'=>'7', 'هشت'=>'8', 'نه'=>'9', 'ده'=>'10' );
        $latin = $this->english_digits( $text );
        foreach ( $words as $word=>$num ) {
            $latin = preg_replace( '/(?:حداقل\s*)?' . preg_quote( $word, '/' ) . '\s*سال/u', 'حداقل ' . $num . ' سال', $latin );
        }
        $max = null;
        if ( preg_match( '/(\d+(?:\.\d+)?)\s*(?:تا|-|الی)\s*(\d+(?:\.\d+)?)\s*سال/u', $latin, $m ) ) { $max = (float) $m[2]; }
        elseif ( preg_match( '/(?:حداقل\s*)?(\d+(?:\.\d+)?)\s*سال/u', $latin, $m ) ) { $max = (float) $m[1]; }
        if ( null === $max ) { return ''; }
        if ( $max < 1 ) { return 'کمتر از ۱ سال'; }
        if ( $max <= 3 ) { return '۱ تا ۳ سال'; }
        if ( $max <= 5 ) { return '۳ تا ۵ سال'; }
        return 'بیشتر از ۵ سال';
    }

    private function extract_software_tools_value( $text ) {
        $text = $this->normalize_text( $text );
        if ( ! $text ) { return ''; }
        $tools = array();
        $known = array(
            'هلو' => '/(?:^|\s)هلو(?:\s|$|[،؛,.])/u',
            'سپیدار' => '/سپیدار/u',
            'راهکاران' => '/راهکاران/u',
            'Excel' => '/(?:excel|اکسل)/iu',
            'Word' => '/(?:word|ورد)/iu',
            'PowerPoint' => '/(?:powerpoint|پاورپوینت)/iu',
            'CRM' => '/(?:crm|سی\s*آر\s*ام)/iu',
            'اتوماسیون اداری' => '/اتوماسیون\s*اداری/u',
        );
        foreach ( $known as $label=>$pattern ) {
            if ( preg_match( $pattern, $text ) ) { $tools[] = $label; }
        }
        return implode( '، ', array_values( array_unique( $tools ) ) );
    }

    private function extract_insurance_value( $text ) {
        $text = $this->normalize_text( $text );
        if ( ! $text ) { return ''; }
        if ( preg_match( '/بیمه\s+از\s+روز\s+اول/u', $text ) ) { return 'بیمه از روز اول'; }
        if ( preg_match( '/بیمه\s+پس\s+از\s+(?:دوره\s+)?آزمایشی/u', $text ) ) { return 'بیمه پس از دوره آزمایشی'; }
        if ( preg_match( '/(?:بدون|فاقد)\s+بیمه|بیمه\s+ندارد/u', $text ) ) { return 'بیمه ندارد'; }

        // «بیمه تکمیلی» به تنهایی نباید به معنی بیمه پایه تلقی شود.
        $base_text = preg_replace( '/بیمه\s*تکمیلی/u', ' ', $text );
        if ( preg_match( '/(?:^|[\s،؛•])بیمه(?:\s+(?:تأمین|تامین)\s+اجتماعی|\s+دارد)?(?:$|[\s،؛•])/u', $base_text ) ) {
            return 'بیمه دارد';
        }
        return '';
    }

    private function extract_benefits_list_value( $text ) {
        $text = $this->normalize_text( $text );
        if ( ! $text ) { return array(); }
        $benefits = array();
        $add = static function ( $condition, $value ) use ( &$benefits ) {
            if ( $condition && ! in_array( $value, $benefits, true ) ) { $benefits[] = $value; }
        };
        $add( (bool) preg_match( '/بیمه\s*تکمیلی/u', $text ), 'بیمه تکمیلی' );
        $add( $this->contains( $text, 'پاداش' ), 'پاداش' );
        $add( (bool) preg_match( '/پورسانت|درصد(?:ی|\s+فروش)/u', $text ), 'پورسانت' );
        $add( (bool) preg_match( '/سرویس\s*(?:رفت\s*و\s*برگشت|رفت‌وبرگشت)/u', $text ), 'سرویس رفت‌وبرگشت' );
        $add( (bool) preg_match( '/ناهار|غذا|وعده\s*غذایی/u', $text ), 'ناهار / غذا' );
        $add( (bool) preg_match( '/جای\s*خواب|خوابگاه/u', $text ), 'جای خواب' );
        $add( (bool) preg_match( '/(?:^|[\s،؛•])وام(?:$|[\s،؛•])/u', $text ), 'وام' );
        $add( (bool) preg_match( '/آموزش\s*(?:رایگان|حین\s*کار)/u', $text ), 'آموزش رایگان' );
        $add( (bool) preg_match( '/ساعت(?:‌|\s)*کاری\s*منعطف|ساعات(?:‌|\s)*کاری\s*منعطف/u', $text ), 'ساعت منعطف' );
        $add( (bool) preg_match( '/هدایای\s*مناسبتی|هدیه\s*مناسبتی/u', $text ), 'هدایا' );
        $add( (bool) preg_match( '/کمک.?هزینه\s*رفت.*آمد/u', $text ), 'کمک‌هزینه رفت‌وآمد' );
        return array_values( array_unique( $benefits ) );
    }

    private function normalize_source_multiselects( $fields ) {
        $fields = is_array( $fields ) ? $fields : array();
        $maps = array(
            'preferred_shift' => $this->canonical_options( 'preferred_shift', '', array( 'صبح','عصر','شب','چرخشی' ) ),
            'soft_skills' => $this->canonical_options( 'soft_skills', '', array( 'ارتباط مؤثر','فن بیان','کار تیمی','حل مسئله','مسئولیت‌پذیری','نظم','پیگیری','مدیریت زمان','مذاکره','دقت','یادگیری سریع','خلاقیت' ) ),
            'interview_method' => $this->canonical_options( 'interview_method', $role, array( 'تماس اولیه','مصاحبه آنلاین','مصاحبه حضوری','آزمون تخصصی','تست عملی','استعلام معرف' ) ),
            'required_documents' => $this->canonical_options( 'required_documents', '', array( 'رزومه','نمونه‌کار','مدرک تحصیلی','گواهی دوره','گواهینامه رانندگی','معرف شغلی' ) ),
            'work_days' => $this->canonical_options( 'work_days', '', array( 'شنبه','یکشنبه','دوشنبه','سه‌شنبه','چهارشنبه','پنجشنبه','جمعه' ) ),
        );
        foreach ( $maps as $key => $options ) {
            if ( ! isset( $fields[ $key ] ) || '' === $fields[ $key ] || array() === $fields[ $key ] ) { continue; }
            if ( is_array( $fields[ $key ] ) ) {
                $values = array_map( 'sanitize_text_field', $fields[ $key ] );
                if ( class_exists( 'QazvinJobs_Field_Schema' ) ) { $values = QazvinJobs_Field_Schema::normalize_field_value( $key, $values ); }
            } else {
                $text = $this->normalize_text( (string) $fields[ $key ] );
                $values = array();
                foreach ( $options as $option ) {
                    if ( false !== $this->mb_pos( $text, $option ) ) { $values[] = $option; }
                }
            }
            $fields[ $key ] = array_values( array_unique( array_intersect( $options, $values ) ) );
        }
        return $fields;
    }

    private function enrich_explicit_source_fields( $fields, $source = '' ) {
        $fields = is_array( $fields ) ? $fields : array();
        $source = sanitize_key( $source );
        if ( 'e-estekhdam' !== $source ) { return $this->normalize_source_multiselects( $fields ); }

        // فقط از بخش‌های ساختاریافته همان آگهی استفاده می‌کنیم؛ نه کل متن صفحه.
        $benefit_text = sanitize_textarea_field( $fields['benefits_description'] ?? '' );
        if ( empty( $fields['insurance'] ) && $benefit_text ) {
            $insurance = $this->extract_insurance_value( $benefit_text );
            if ( $insurance ) { $fields['insurance'] = $insurance; }
        }
        if ( ! array_key_exists( 'benefits_list', $fields ) || ! is_array( $fields['benefits_list'] ) ) {
            $fields['benefits_list'] = $this->extract_benefits_list_value( $benefit_text );
        } elseif ( $benefit_text ) {
            $fields['benefits_list'] = array_values( array_unique( array_merge( $fields['benefits_list'], $this->extract_benefits_list_value( $benefit_text ) ) ) );
        }

        // مهارت‌های رفتاری و مدارک فقط وقتی عبارت صریح در شرایط احراز وجود دارد پر شوند.
        $requirements = $this->normalize_text( trim( implode( ' ', array_filter( array(
            $fields['requirements'] ?? '',
            $fields['technical_skills'] ?? '',
        ) ) ) ) );
        if ( $requirements ) {
            if ( empty( $fields['soft_skills'] ) ) {
                $soft = array();
                $soft_map = array(
                    'ارتباط مؤثر' => array( 'روابط عمومی', 'ارتباط موثر', 'ارتباط مؤثر' ),
                    'کار تیمی' => array( 'کار تیمی', 'تیمی' ),
                    'حل مسئله' => array( 'حل مسئله' ),
                    'مسئولیت‌پذیری' => array( 'مسئولیت پذیر', 'مسئولیت‌پذیر' ),
                    'مدیریت زمان' => array( 'مدیریت زمان' ),
                    'مذاکره' => array( 'مذاکره' ),
                    'دقت و توجه به جزئیات' => array( 'دقت', 'جزئیات' ),
                    'یادگیری سریع' => array( 'یادگیری سریع' ),
                    'خلاقیت' => array( 'خلاق' ),
                    'رهبری' => array( 'رهبری' ),
                );
                foreach ( $soft_map as $label => $needles ) {
                    foreach ( $needles as $needle ) { if ( $this->contains( $requirements, $needle ) ) { $soft[] = $label; break; } }
                }
                if ( $soft ) { $fields['soft_skills'] = array_values( array_unique( $soft ) ); }
            }
            if ( empty( $fields['required_documents'] ) ) {
                $docs = array();
                $doc_map = array(
                    'رزومه' => array( 'رزومه' ), 'نمونه‌کار' => array( 'نمونه کار','نمونه‌کار' ),
                    'مدرک تحصیلی' => array( 'مدرک تحصیلی' ), 'گواهی دوره' => array( 'گواهی دوره','گواهینامه دوره' ),
                    'گواهینامه رانندگی' => array( 'گواهینامه رانندگی' ), 'معرف شغلی' => array( 'معرف شغلی','ارائه معرف' ),
                );
                foreach ( $doc_map as $label => $needles ) {
                    foreach ( $needles as $needle ) { if ( $this->contains( $requirements, $needle ) ) { $docs[] = $label; break; } }
                }
                if ( $docs ) { $fields['required_documents'] = array_values( array_unique( $docs ) ); }
            }
        }
        return $this->normalize_source_multiselects( $fields );
    }

    /**
     * Source-first classification. The title and source category carry much
     * higher authority than free-form body text. We keep a legacy UI key while
     * storing the richer canonical group + specialty in the data contract.
     */
    private function classify_source_job( $title, $source_category = '', $text = '' ) {
        // Classification priority is deliberately strict:
        // 1) exact job title, 2) source category, 3) body text.
        // Never concatenate title and source category; a noisy source category
        // must not turn «کارشناس تصفیه خانه» into «کارشناس فروش».
        $title_text = $this->normalize_text( $title );
        $source_text = $this->normalize_text( $source_category );
        $body_text = $this->normalize_text( $text );

        $rules = array(
            // Highly specific titles first.
            array( 'technical-engineering', 'technical-engineering', 'water-treatment', array('تصفیه خانه','تصفیه‌خانه','تصفیه آب','تصفیه فاضلاب','آب و فاضلاب') ),
            array( 'education-cultural', 'education-cultural', 'educational-supervisor', array('مراقب پانسیون','پانسیون مطالعاتی','سرپرست پانسیون','مراقب آموزشی','ناظر آموزشی') ),
            array( 'medical-beauty', 'medical-beauty', 'laboratory', array('آزمایشگاه تشخیص پزشکی','کارشناس آزمایشگاه پزشکی','علوم آزمایشگاهی') ),
            array( 'technical-engineering', 'technical-engineering', 'chemical-process', array('مهندس شیمی','کارشناس فرایند','کارشناس فرآیند','فرایند شیمیایی','فرآیند شیمیایی') ),
            array( 'technical-engineering', 'technical-engineering', 'environment-hse', array('کارشناس محیط زیست','کارشناس hse','hse') ),
            array( 'technical-engineering', 'technical-engineering', 'technical-drawing', array('تکنسین نقشه کشی صنعتی','تکنسین نقشه‌کشی صنعتی','نقشه کشی صنعتی','نقشه‌کشی صنعتی','نقشه کش صنعتی','نقشه‌کش صنعتی','نقشه کش','نقشه‌کش') ),

            array( 'finance-accounting', 'finance-accounting', 'accountant', array('حسابدار','حسابداری') ),
            array( 'sales-marketing-commerce', 'sales-marketing-commerce', 'sales-expert', array('مدیر فروش','سرپرست فروش') ),
            array( 'transport-logistics', 'transport-logistics', 'warehouse', array('کارگر انبار','نیروی انبار','کمک انبار','مسئول انبار','مدیر انبار','سرپرست انبار','انباردار','انبار داری','انبارداری') ),
            array( 'finance-accounting', 'finance-accounting', 'audit', array('حسابرس','حسابرسی') ),
            array( 'finance-accounting', 'finance-accounting', 'treasury', array('خزانه','خزانه دار','خزانه‌دار') ),
            array( 'finance-accounting', 'finance-accounting', 'finance-manager', array('مدیر مالی','سرپرست مالی') ),
            array( 'human-resources', 'human-resources', 'hr-expert', array('منابع انسانی','کارشناس منابع انسانی','کارگزینی','امور پرسنلی') ),
            array( 'human-resources', 'human-resources', 'recruitment', array('جذب و استخدام','کارشناس جذب') ),
            array( 'admin-office', 'admin-office', 'secretary', array('منشی','مسئول دفتر') ),
            array( 'admin-office', 'admin-office', 'office-clerk', array('کارمند اداری','امور اداری') ),
            array( 'services-support', 'services-support', 'cleaning-services', array('نیروی خدماتی','خدماتی','نظافت','نظافتچی','خدمتکار') ),
            array( 'services-support', 'services-support', 'security', array('نگهبان','نگهبانی','حراست') ),
            array( 'services-support', 'services-support', 'janitor', array('سرایدار') ),
            array( 'services-support', 'services-support', 'office-service', array('آبدارچی') ),
            array( 'sales-marketing-commerce', 'sales-marketing-commerce', 'sales-expert', array('کارشناس فروش','کارشناس فروش و بازاریابی') ),
            array( 'sales-marketing-commerce', 'sales-marketing-commerce', 'salesperson', array('فروشنده','صندوقدار') ),
            array( 'sales-marketing-commerce', 'sales-marketing-commerce', 'visitor', array('ویزیتور') ),
            array( 'sales-marketing-commerce', 'sales-marketing-commerce', 'marketing', array('بازاریاب','بازاریابی') ),
            array( 'sales-marketing-commerce', 'sales-marketing-commerce', 'commercial', array('بازرگانی','کارشناس بازرگانی') ),
            array( 'it-digital', 'it-digital', 'backend', array('backend','back-end','بک اند','بک‌اند') ),
            array( 'it-digital', 'it-digital', 'frontend', array('frontend','front-end','فرانت اند','فرانت‌اند') ),
            array( 'it-digital', 'it-digital', 'software-development', array('برنامه نویس','برنامه‌نویس','توسعه دهنده','توسعه‌دهنده') ),
            array( 'it-digital', 'it-digital', 'network', array('کارشناس شبکه','شبکه') ),
            array( 'it-digital', 'it-digital', 'seo-digital-marketing', array('سئو','دیجیتال مارکتینگ') ),
            array( 'construction-architecture', 'construction-architecture', 'civil', array('مهندس عمران','عمران') ),
            array( 'construction-architecture', 'construction-architecture', 'architecture', array('معمار','معماری') ),
            array( 'technical-engineering', 'technical-engineering', 'electrical', array('مهندس برق','تکنسین برق','برقکار','برق کار') ),
            array( 'technical-engineering', 'technical-engineering', 'mechanical', array('مهندس مکانیک','تکنسین مکانیک','مکانیک') ),
            array( 'technical-engineering', 'technical-engineering', 'maintenance', array('تعمیرات','نگهداری') ),
            array( 'industrial-production', 'industrial-production', 'production-worker', array('کارگر تولید','نیروی تولید','خط تولید') ),
            array( 'industrial-production', 'industrial-production', 'machine-operator', array('اپراتور دستگاه','اپراتور تولید') ),
            array( 'industrial-production', 'industrial-production', 'packaging', array('بسته بندی','بسته‌بندی') ),
            array( 'industrial-production', 'industrial-production', 'quality-control', array('کنترل کیفیت','qc') ),
            array( 'transport-logistics', 'transport-logistics', 'driver', array('راننده') ),
            array( 'transport-logistics', 'transport-logistics', 'courier', array('پیک') ),
            array( 'transport-logistics', 'transport-logistics', 'warehouse', array('انباردار','انبار داری','انبارداری') ),
            array( 'transport-logistics', 'transport-logistics', 'logistics', array('لجستیک','پخش و توزیع') ),
            array( 'restaurant-food', 'restaurant-food', 'cook', array('آشپز') ),
            array( 'restaurant-food', 'restaurant-food', 'barista', array('باریستا') ),
            array( 'restaurant-food', 'restaurant-food', 'bakery', array('قناد','نانوایی','شیرینی پز','شیرینی‌پز') ),
            array( 'medical-beauty', 'medical-beauty', 'nursing', array('پرستار','پرستاری') ),
            array( 'medical-beauty', 'medical-beauty', 'pharmacy', array('داروخانه','داروساز') ),
            array( 'medical-beauty', 'medical-beauty', 'dental', array('دندانپزشک','دندانپزشکی') ),
            array( 'medical-beauty', 'medical-beauty', 'caregiver', array('بهیار','مراقب سالمند','مراقب بیمار') ),
            array( 'education-cultural', 'education-cultural', 'teacher', array('معلم','مدرس','مربی') ),
            array( 'education-cultural', 'education-cultural', 'student-affairs', array('امور دانش آموزان','امور دانش‌آموزان','امور دانشجو','امور دانش پژوهان','امور دانش‌پژوهان') ),
            array( 'design-media-content', 'design-media-content', 'graphic-design', array('طراح گرافیک','گرافیست') ),
            array( 'design-media-content', 'design-media-content', 'content-writing', array('تولید محتوا','کارشناس محتوا') ),
            array( 'legal-contracts', 'legal-contracts', 'legal-expert', array('کارشناس حقوقی','امور حقوقی','وکیل') ),
            array( 'agriculture-livestock', 'agriculture-livestock', 'agriculture', array('کشاورزی','کشاورز','زراعت','باغبانی') ),
            array( 'agriculture-livestock', 'agriculture-livestock', 'livestock', array('دامداری','دامپروری','دامپزشکی') ),
        );

        foreach ( array( $title_text, $source_text, $body_text ) as $haystack ) {
            if ( ! $haystack ) { continue; }
            foreach ( $rules as $rule ) {
                foreach ( $rule[3] as $needle ) {
                    if ( $this->contains( $haystack, $needle ) ) {
                        return array( 'canonical_key'=>$rule[0], 'legacy_key'=>$rule[1], 'specialty_key'=>$rule[2] );
                    }
                }
            }
        }
        return array( 'canonical_key'=>'services-support', 'legacy_key'=>'services-support', 'specialty_key'=>'general-support' );
    }

    private function detect_qazvin_city( $text ) {
        $cities = array( 'محمودآباد نمونه','بوئین زهرا','بوئین‌زهرا','معلم کلایه','دانسفهان','اسفرورین','ضیاءآباد','محمدیه','اقبالیه','خرمدشت','تاکستان','آبیک','الوند','آوج','آبگرم','رازمیان','کوهین','سیردان','نرجه','ارداق','سگزآباد','خاکعلی','بیدستان','شال','قزوین' );
        foreach ( $cities as $city ) { if ( $this->contains( $text, $this->normalize_text( $city ) ) ) { return str_replace( 'بوئین زهرا', 'بوئین‌زهرا', $city ); } }
        return '';
    }

    private function merge_contacts( $a, $b ) {
        $out = array();
        foreach ( array( 'phones','sms','emails','whatsapp','telegram' ) as $key ) {
            $values = array_merge( isset( $a[$key] ) && is_array( $a[$key] ) ? $a[$key] : array(), isset( $b[$key] ) && is_array( $b[$key] ) ? $b[$key] : array() );
            $clean = array();
            foreach ( $values as $value ) {
                $value = sanitize_text_field( (string) $value );
                if ( 'emails' === $key ) { $value = sanitize_email( $value ); if ( preg_match( '/@(?:e-estekhdam\.com|estekhdam\.com|divar\.ir)$/i', $value ) ) { $value = ''; } }
                elseif ( in_array( $key, array( 'phones','sms','whatsapp' ), true ) ) { $value = $this->normalize_phone( $value ); }
                if ( $value ) { $clean[] = $value; }
            }
            $out[$key] = array_values( array_unique( $clean ) );
        }
        return $out;
    }

    private function extract_contacts( $html ) {
        $decoded = html_entity_decode( (string) $html, ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        $flat = preg_replace( '/[\x{200c}\x{200f}\x{202a}-\x{202e}]/u', '', $this->english_digits( $decoded ) );
        $contacts = array( 'phones'=>array(), 'sms'=>array(), 'emails'=>array(), 'whatsapp'=>array(), 'telegram'=>array() );
        if ( preg_match_all( '/(?<!\d)(?:(?:\+|00)?98[\s\-]?)?0?9\d{9}(?!\d)/u', $flat, $m ) ) { foreach ( $m[0] as $v ) { $contacts['phones'][] = $this->normalize_phone( $v ); } }
        if ( preg_match_all( '/(?<!\d)(?:(?:\+|00)?98[\s\-]?)?0?28[\s\-]?\d{7,8}(?!\d)/u', $flat, $m ) ) { foreach ( $m[0] as $v ) { $contacts['phones'][] = $this->normalize_phone( $v ); } }
        if ( preg_match_all( '/[A-Z0-9._%+\-]+@[A-Z0-9.\-]+\.[A-Z]{2,}/iu', $flat, $m ) ) { foreach ( $m[0] as $v ) { $v = sanitize_email( $v ); if ( $v && ! preg_match( '/@(?:e-estekhdam\.com|estekhdam\.com|divar\.ir)$/i', $v ) ) { $contacts['emails'][] = strtolower( $v ); } } }
        if ( preg_match_all( '#(?:wa\.me/|api\.whatsapp\.com/send\?phone=)(\+?\d{10,15})#iu', $flat, $m ) ) { foreach ( $m[1] as $v ) { $contacts['whatsapp'][] = $this->normalize_phone( $v ); } }
        if ( preg_match_all( '#t\.me/([A-Za-z0-9_]{5,32})#iu', $flat, $m ) ) { foreach ( $m[1] as $v ) { $contacts['telegram'][] = '@' . $v; } }
        foreach ( $contacts as $key => $values ) { $contacts[$key] = array_values( array_unique( array_filter( $values ) ) ); }
        return $contacts;
    }

    private function ensure_import_user() {
        $stored = absint( get_option( 'qzih_import_user_id', 0 ) );
        if ( $stored && get_user_by( 'id', $stored ) ) { return $stored; }
        $login = 'qazvinjobs_importer';
        $user = get_user_by( 'login', $login );
        if ( ! $user ) {
            $created = wp_insert_user( array(
                'user_login' => $login,
                'user_pass' => wp_generate_password( 32, true, true ),
                'display_name' => 'واردکننده آگهی قزوین‌جابز',
                'nickname' => 'واردکننده آگهی قزوین‌جابز',
                'role' => 'subscriber',
            ) );
            if ( ! is_wp_error( $created ) ) { $user = get_user_by( 'id', $created ); }
        }
        if ( $user ) {
            update_user_meta( $user->ID, '_qzih_system_importer', 1 );
            update_option( 'qzih_import_user_id', absint( $user->ID ), false );
            return absint( $user->ID );
        }
        return 1;
    }

    private function repair_invalid_created_links() {
        if ( ! class_exists( 'QazvinJobs_Compat' ) ) { return; }
        $queues = get_posts( array(
            'post_type'=>self::QUEUE_POST_TYPE,
            'post_status'=>array('pending','draft'),
            'posts_per_page'=>500,
            'fields'=>'ids',
            'orderby'=>'ID',
            'order'=>'ASC',
        ) );

        // A WordPress draft belongs to exactly one Import Hub queue item.
        // Older builds could leave several queue rows pointing to the same draft.
        $used_ads = array();

        foreach ( $queues as $queue_id ) {
            $ad_id = absint( get_post_meta( $queue_id, '_qzih_created_ad_id', true ) );
            if ( ! $ad_id ) { continue; }

            $ad = get_post( $ad_id );
            $source_id = (string) get_post_meta( $queue_id, '_qzih_source_id', true );
            $owned = $ad ? (int) get_post_meta( $ad_id, '_qz_import_hub_owned', true ) : 0;
            $ad_source = $ad ? (string) get_post_meta( $ad_id, '_qz_source_id', true ) : '';
            $valid_status = $ad && in_array( $ad->post_status, array('draft','pending','private'), true );
            $same_source = $ad && $source_id && $ad_source && hash_equals( $source_id, $ad_source );
            $already_claimed = isset( $used_ads[ $ad_id ] ) && (int) $used_ads[ $ad_id ] !== (int) $queue_id;

            if ( $ad && $owned && $same_source && $valid_status && ! $already_claimed ) {
                $used_ads[ $ad_id ] = $queue_id;
                continue;
            }

            // Never let an Import Hub queue hijack a manually managed ad.
            if ( $ad && ! $owned && $same_source ) {
                delete_post_meta( $ad_id, '_qz_source_name' );
                delete_post_meta( $ad_id, '_qz_source_id' );
                delete_post_meta( $ad_id, '_qz_source_url' );
                delete_post_meta( $ad_id, '_qz_import_needs_admin_review' );
                delete_post_meta( $ad_id, '_qz_import_hub_version' );
            }

            delete_post_meta( $queue_id, '_qzih_created_ad_id' );
            wp_update_post( array( 'ID'=>$queue_id, 'post_status'=>'pending' ) );

            if ( get_option( 'qzih_auto_draft', 1 ) ) {
                $rebuilt = $this->create_ad_draft_from_queue( $queue_id );
                if ( ! is_wp_error( $rebuilt ) && $rebuilt ) { $used_ads[ absint( $rebuilt ) ] = $queue_id; }
            }
        }
    }

private function build_trusted_payload( $queue, $contacts, $role = 'employer' ) {
    $raw = (string) get_post_meta( $queue->ID, '_qzih_raw_text', true );
    if ( ! $raw ) { $raw = $this->normalize_text( $queue->post_content ); }

    $source_title = sanitize_text_field( get_post_meta( $queue->ID, '_qzih_source_title', true ) ?: $queue->post_title );
    $source       = sanitize_key( get_post_meta( $queue->ID, '_qzih_source', true ) ?: 'e-estekhdam' );
    $source_name  = sanitize_text_field( get_post_meta( $queue->ID, '_qzih_source_name', true ) ?: $this->source_label( $source ) );
    $city         = sanitize_text_field( get_post_meta( $queue->ID, '_qzih_city', true ) ?: 'قزوین' );
    $role         = in_array( $role, array( 'employer', 'job_seeker' ), true ) ? $role : 'employer';

    $stored_fields = get_post_meta( $queue->ID, '_qzih_fields', true );
    $fields = is_array( $stored_fields ) ? $stored_fields : array();
    if ( class_exists( 'QazvinJobs_Field_Schema' ) ) {
        $normalized_fields = QazvinJobs_Field_Schema::normalize_values( $fields, $role );
        if ( is_array( $normalized_fields ) ) { $fields = array_merge( $fields, $normalized_fields ); }
    }
    $fields = $this->enrich_explicit_source_fields( $fields, $source );

    // FINAL source-fidelity guard for E-Estekhdam. The crawler already sends
    // explicit source fields, but WordPress is the last trust boundary and must
    // never replace a real source fact with a generic fallback.
    if ( 'e-estekhdam' === $source ) {
        if ( empty( $fields['company_name'] ) || $this->is_generic_company_name( $fields['company_name'] ) ) {
            $company_from_source = $this->extract_eestekhdam_company_name( $raw );
            if ( $company_from_source ) { $fields['company_name'] = $company_from_source; }
        }
        if ( empty( $fields['cooperation_type'] ) ) {
            $cooperation_from_source = $this->extract_eestekhdam_cooperation( $raw );
            if ( $cooperation_from_source ) { $fields['cooperation_type'] = $cooperation_from_source; }
        }
        if ( ! empty( $fields['requirements'] ) ) {
            $fields['requirements'] = $this->cleanup_eestekhdam_requirements( $fields['requirements'] );
        }
        if ( ! empty( $fields['benefits_description'] ) ) {
            $fields['benefits_description'] = $this->cleanup_eestekhdam_benefits( $fields['benefits_description'] );
        }
    }

    // Persist direct contact in the canonical/new contact fields too.
    $first_direct_phone = ! empty( $contacts['phones'][0] ) ? $this->normalize_phone( $contacts['phones'][0] ) : '';
    if ( $first_direct_phone ) {
        if ( preg_match( '/^09\d{9}$/', $first_direct_phone ) ) { $fields['mobile_phone'] = $first_direct_phone; }
        elseif ( preg_match( '/^0(?!9)\d{9,10}$/', $first_direct_phone ) ) { $fields['landline_phone'] = $first_direct_phone; }
    }

    // The queue stores the original page text for audit, but final Divar draft
    // construction must never parse that page-wide text. Related/recommended
    // cards can live in the same <main>. Build every fallback from the crawler's
    // current-ad scoped fields instead.
    $trusted_raw = $raw;
    if ( 'divar' === $source ) {
        $trusted_raw = $this->normalize_text( implode( ' ', array_filter( array(
            $fields['job_description'] ?? '',
            $fields['requirements'] ?? '',
            $fields['technical_skills'] ?? '',
            $fields['responsibilities'] ?? '',
            $fields['benefits_description'] ?? '',
            $fields['address_detail'] ?? '',
        ) ) ) );
    }

    // 0.3.36: final contract-boundary normalization + deterministic source/final snapshots. Canonical keys win legacy aliases
    // immediately before the WordPress draft is built, so values sent by the crawler
    // cannot disappear from the current QazvinJobs editor UI.
    if ( class_exists( 'QazvinJobs_Field_Schema' ) ) {
        $canonical_storage_fields = QazvinJobs_Field_Schema::normalize_values( $fields, $role );
        if ( is_array( $canonical_storage_fields ) ) { $fields = array_merge( $fields, $canonical_storage_fields ); }
    }
    if ( empty( $fields['software_tools'] ) && ! empty( $fields['office_tools'] ) ) {
        $fields['software_tools'] = sanitize_text_field( $fields['office_tools'] );
    }
    // V3: never synthesize a second narrative schedule field from structured time facts.
    // Only infer the structural schedule mode when the source supplied enough exact facts.
    if ( empty( $fields['schedule_mode'] ) ) {
        $source_shifts = isset( $fields['preferred_shift'] ) ? array_values( array_filter( (array) $fields['preferred_shift'] ) ) : array();
        $source_days = isset( $fields['work_days'] ) ? array_values( array_filter( (array) $fields['work_days'] ) ) : array();
        $source_start = sanitize_text_field( $fields['work_start'] ?? '' );
        $source_end = sanitize_text_field( $fields['work_end'] ?? '' );
        if ( $source_shifts ) { $fields['schedule_mode'] = 'شیفتی'; }
        elseif ( $source_days && $source_start && $source_end ) { $fields['schedule_mode'] = 'ثابت'; }
        elseif ( $source_days ) { $fields['schedule_mode'] = 'شناور'; }
    }

    $legacy_category_key = sanitize_key( get_post_meta( $queue->ID, '_qzih_legacy_category_key', true ) );
    $canonical_category_key = sanitize_key( get_post_meta( $queue->ID, '_qzih_canonical_category_key', true ) );
    $specialty_key = sanitize_key( get_post_meta( $queue->ID, '_qzih_specialty_key', true ) );
    if ( ! $legacy_category_key || ! $canonical_category_key ) {
        $classification = $this->classify_source_job(
            $source_title,
            sanitize_text_field( get_post_meta( $queue->ID, '_qzih_source_category', true ) ),
            $trusted_raw
        );
        $legacy_category_key = $legacy_category_key ?: $classification['legacy_key'];
        $canonical_category_key = $canonical_category_key ?: $classification['canonical_key'];
        $specialty_key = $specialty_key ?: $classification['specialty_key'];
    }

    $fields['job_title'] = $fields['job_title'] ?? $this->canonical_job_title( $source_title, $city );
    $fields['city_name'] = $city;
    $fields['province'] = $fields['province'] ?? 'قزوین';
    if ( class_exists( 'QazvinJobs_Field_Schema' ) && method_exists( 'QazvinJobs_Field_Schema', 'normalize_values_for_category' ) && $legacy_category_key ) {
        $fields = array_merge(
            $fields,
            QazvinJobs_Field_Schema::normalize_values_for_category( $fields, $legacy_category_key, $role )
        );
    }
    $fields['category_key'] = $canonical_category_key;
    $fields['specialty_key'] = $specialty_key;

    $requirements = sanitize_textarea_field( $fields['requirements'] ?? '' );
    if ( ! $requirements ) {
        $requirements = $this->extract_section(
            $trusted_raw,
            array( 'شرایط احراز', 'شرایط استخدام', 'شرایط همکاری' ),
            array( 'شرح وظایف', 'تسهیلات و مزایا', 'مزایا و تسهیلات', 'سایر مزایا', 'محل کار', 'اطلاعات تماس', 'آگهی‌های مشابه' )
        );
    }

    $responsibilities = sanitize_textarea_field( $fields['responsibilities'] ?? '' );
    if ( ! $responsibilities ) {
        $responsibilities = $this->extract_section(
            $trusted_raw,
            array( 'شرح وظایف', 'شرح موقعیت' ),
            array( 'شرایط احراز', 'تسهیلات و مزایا', 'مزایا و تسهیلات', 'محل کار', 'اطلاعات تماس', 'آگهی‌های مشابه' )
        );
    }

    $benefits = sanitize_textarea_field( $fields['benefits_description'] ?? '' );
    if ( ! $benefits ) {
        $benefits_a = $this->extract_section(
            $trusted_raw,
            array( 'تسهیلات و مزایا', 'مزایا و تسهیلات' ),
            array( 'سایر مزایا', 'محل کار', 'اطلاعات تماس', 'آگهی‌های مشابه' )
        );
        $benefits_b = $this->extract_section(
            $trusted_raw,
            array( 'سایر مزایا' ),
            array( 'محل کار', 'اطلاعات تماس', 'آگهی‌های مشابه' )
        );
        $benefits = trim( $benefits_a . ( $benefits_a && $benefits_b ? '؛ ' : '' ) . $benefits_b, " ؛" );
    }

    $address = sanitize_text_field( $fields['address_detail'] ?? '' );
    if ( ! $address ) { $address = $this->extract_address( $trusted_raw, $city ); }

    $title = 'job_seeker' === $role
        ? $this->build_jobseeker_title( $source_title, $trusted_raw, $city )
        : $this->build_employer_title( $source_title, $trusted_raw, $city );

    $contact = $this->contact_summary( $contacts );
    $content = '';
    $source_description = sanitize_textarea_field( $fields['job_description'] ?? '' );

    // 0.3.54 — source fidelity final:
    // E-Estekhdam has a stable source description. If the crawler supplied it,
    // publish that cleaned source text exactly once. Do not append requirements,
    // benefits or location a second time because those facts already have their
    // own structured fields and may also be present in the source description.
    // If no source description exists, use only sections that actually exist;
    // never synthesize narrative copy.
    if ( 'e-estekhdam' === $source ) {
        if ( $source_description ) {
            $content .= $this->section_to_html( $source_description );
        } else {
            if ( $responsibilities ) { $content .= '<h3>شرح وظایف</h3>' . $this->section_to_html( $responsibilities ); }
            if ( $requirements ) { $content .= '<h3>شرایط احراز و شرح همکاری</h3>' . $this->section_to_html( $requirements ); }
            if ( $benefits ) { $content .= '<h3>مزایا و تسهیلات</h3>' . $this->section_to_html( $benefits ); }
            if ( $address ) { $content .= '<h3>محل کار</h3><p>' . esc_html( $address ) . '</p>'; }
        }
    } else {
        if ( $source_description ) {
            $content .= $this->section_to_html( $source_description );
        } elseif ( 'employer' === $role ) {
            $content .= '<p>برای موقعیت «' . esc_html( $fields['job_title'] ) . '» در ' . esc_html( $city ) . ' نیرو جذب می‌شود.</p>';
        } elseif ( 'job_seeker' === $role ) {
            $content .= '<p>این کارجو برای همکاری در حوزه «' . esc_html( $fields['job_title'] ) . '» در ' . esc_html( $city ) . ' آمادگی دارد.</p>';
        }
        if ( $responsibilities ) { $content .= '<h3>شرح وظایف</h3>' . $this->section_to_html( $responsibilities ); }
        if ( $requirements ) { $content .= '<h3>شرایط احراز و شرح همکاری</h3>' . $this->section_to_html( $requirements ); }
        if ( $benefits ) { $content .= '<h3>مزایا و تسهیلات</h3>' . $this->section_to_html( $benefits ); }
        if ( $address ) { $content .= '<h3>محل کار</h3><p>' . esc_html( $address ) . '</p>'; }
    }

    // Public job content must stay focused on the job itself. Contact details,
    // source attribution and internal moderation/status messages already live
    // in dedicated structured fields/post meta and must not be duplicated in
    // the public description.

    $excerpt = wp_trim_words( wp_strip_all_tags( $content ), 45, '…' );
    return array(
        'title' => $title,
        'content' => $content,
        'excerpt' => $excerpt,
        'fields' => $fields,
        'city' => $city,
        'role' => $role,
        'source' => $source,
        'source_name' => $source_name,
        'category_key' => $legacy_category_key,
        'canonical_category_key' => $canonical_category_key,
        'specialty_key' => $specialty_key,
        'category_label' => $this->category_label_from_key( $legacy_category_key ),
        'requirements' => $requirements,
        'responsibilities' => $responsibilities,
        'benefits' => $benefits,
        'address' => $address,
        'location' => $address ?: $city,
        'focus_keyword' => $title,
        'seo_title' => $title . ' | قزوین جابز',
        'seo_description' => wp_trim_words( wp_strip_all_tags( $content ), 28, '…' ),
    );
}
private function build_employer_title( $source_title, $raw, $city ) {
    // Preserve the source H1 as the public title. Do not inject gender or
    // re-detect the city here; those facts live in their own canonical fields.
    $title = sanitize_text_field( $source_title );
    $title = preg_replace( '/\s*[-–|].*(?:ای\s*استخدام|دیوار).*$/u', '', $title );
    $title = trim( preg_replace( '/\s+/u', ' ', $title ) );
    if ( ! $title ) {
        $job = $this->canonical_job_title( $source_title, $city );
        $title = $job ? 'استخدام ' . $job . ( $city ? ' در ' . $city : '' ) : 'آگهی استخدام';
    }
    return $this->compact_title( $title, 110, 18 );
}


    private function extract_section( $text, $starts, $ends ) {
        $text = $this->normalize_text( $text ); $start_pos = false; $start_len = 0;
        foreach ( $starts as $marker ) { $pos = $this->mb_pos( $text, $marker ); if ( false !== $pos && ( false === $start_pos || $pos < $start_pos ) ) { $start_pos=$pos; $start_len=$this->mb_len($marker); } }
        if ( false === $start_pos ) { return ''; }
        $from = $start_pos + $start_len; $end_pos = false;
        foreach ( $ends as $marker ) { $pos = $this->mb_pos( $text, $marker, $from ); if ( false !== $pos && ( false === $end_pos || $pos < $end_pos ) ) { $end_pos=$pos; } }
        $part = false === $end_pos ? $this->mb_sub( $text, $from, 2500 ) : $this->mb_sub( $text, $from, $end_pos-$from );
        return trim( preg_replace('/\s+/u',' ', $part), " :؛،-" );
    }

    private function extract_address( $text, $city ) {
        $location = $this->extract_section( $text, array('محل کار'), array('اطلاعات تماس','آگهی‌های استخدام مشابه','آگهی های استخدام مشابه') );
        if ( preg_match('/آدرس\s*[:：]?\s*([^؛•]{2,100})/u', $location ?: $text, $m) ) { $addr = trim($m[1]); return $city && ! $this->contains($addr,$city) ? $city . '، ' . $addr : $addr; }
        return $city;
    }

    private function is_generic_company_name( $value ) {
        $value = trim( sanitize_text_field( (string) $value ) );
        return ! $value || (bool) preg_match( '/^(?:آگهی[‌ -]*دهنده(?:\s+مستقیم)?|کارفرما|شرکت|مجموعه|(?:یک\s+)?مجموعه\s+معتبر|ای[‌ ]?استخدام|e[\s-]?estekhdam|نامشخص)$/ui', $value );
    }

    private function extract_eestekhdam_company_name( $text ) {
        $text = wp_strip_all_tags( html_entity_decode( (string) $text, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
        $text = preg_replace( '/[\x{200c}\x{200f}\x{202a}-\x{202e}]+/u', ' ', $text );
        $patterns = array(
            '/(?:^|[\n.!؟])\s*([^\n.!؟]{2,160}?)\s+در\s+استان\s+قزوین(?:،|,|\s)+شهر\s+قزوین\s+جهت\s+تکمیل\s+کادر/u',
            '/(?:^|[\n.!؟])\s*([^\n.!؟]{2,160}?)\s+در\s+استان\s+قزوین\s+جهت\s+تکمیل\s+کادر/u',
            '/(?:^|[\n.!؟])\s*([^\n.!؟]{2,160}?)\s+جهت\s+تکمیل\s+کادر/u',
        );
        foreach ( $patterns as $pattern ) {
            if ( preg_match( $pattern, $text, $m ) ) {
                $name = trim( preg_replace( '/^استخدام\s+/u', '', sanitize_text_field( $m[1] ) ) );
                if ( ! $this->is_generic_company_name( $name ) && $this->mb_len( $name ) <= 160 ) { return $name; }
            }
        }
        return '';
    }

    private function extract_eestekhdam_cooperation( $text ) {
        $text = $this->normalize_text( $text );
        if ( preg_match( '/نوع\s*همکاری\s*[:：-]?\s*(تمام[‌ ]?وقت|پاره[‌ ]?وقت|کارآموزی|پروژه[‌ ]?ای|پیمانکاری|ساعتی|روزانه)/u', $text, $m ) ) {
            $v = preg_replace( '/\s+/u', ' ', trim( $m[1] ) );
            if ( preg_match( '/تمام/u', $v ) ) { return 'تمام‌وقت'; }
            if ( preg_match( '/پاره/u', $v ) ) { return 'پاره‌وقت'; }
            if ( preg_match( '/کارآموز/u', $v ) ) { return 'کارآموزی'; }
            if ( preg_match( '/پروژه|پیمان/u', $v ) ) { return 'پروژه‌ای / پیمانکاری'; }
            if ( preg_match( '/ساعتی|روزانه/u', $v ) ) { return 'ساعتی / روزانه'; }
        }
        return '';
    }

    private function cleanup_eestekhdam_requirements( $text ) {
        $text = html_entity_decode( wp_strip_all_tags( (string) $text ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        $parts = preg_split( '/(?:\r?\n|\s*[•●▪]\s*)/u', $text );
        $items = array();
        foreach ( (array) $parts as $part ) {
            $part = trim( preg_replace( '/\s+/u', ' ', $part ), " \t\n\r\0\x0B؛،-–—:" );
            if ( ! $part || $this->mb_len( $part ) < 3 ) { continue; }
            if ( preg_match( '/جهت\s+تکمیل\s+کادر|برای\s+کسب\s+اطلاعات\s+بیشتر|مصاحبه\s+حضوری|تماس\s+(?:بگیرید|حاصل)/u', $part ) ) { continue; }
            if ( preg_match( '/^(?:عنوان\s*شغلی|نوع\s*همکاری|جنسیت|سابقه\s*کار|سن|حداکثر\s*سن|ساعات?\s*کاری|حقوق|محل\s*کار)\s*[:：]/u', $part ) ) { continue; }
            $key = $this->normalize_text( $part );
            if ( isset( $items[ $key ] ) ) { continue; }
            $items[ $key ] = $part;
        }
        return implode( "\n", array_values( $items ) );
    }

    private function cleanup_eestekhdam_benefits( $text ) {
        $text = html_entity_decode( wp_strip_all_tags( (string) $text ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        $parts = preg_split( '/(?:\r?\n|\s*[•●▪]\s*)/u', $text );
        $items = array();
        foreach ( (array) $parts as $part ) {
            $part = trim( preg_replace( '/\s+/u', ' ', $part ), " \t\n\r\0\x0B؛،-–—:" );
            if ( ! $part || $this->mb_len( $part ) < 2 || preg_match( '/^(?:تسهیلات\s+و\s+مزایا|سایر\s+مزایا)$/u', $part ) ) { continue; }
            $key = $this->normalize_text( $part );
            if ( isset( $items[ $key ] ) ) { continue; }
            $items[ $key ] = $part;
        }
        return implode( "\n", array_values( $items ) );
    }

    private function section_to_html( $text ) {
        $text = html_entity_decode( wp_strip_all_tags( (string) $text ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        $parts = preg_split( '/(?:\r?\n|\s*[•●▪]\s*|\s+-\s+)/u', $text );
        $items = array();
        foreach ( (array) $parts as $part ) {
            $part = trim( preg_replace( '/\s+/u', ' ', $part ), " \t\n\r\0\x0B؛،-–—:" );
            if ( ! $part || $this->mb_len( $part ) < 3 || preg_match( '/^[•●▪▫·.\-–—:؛،]+$/u', $part ) ) { continue; }
            $key = $this->normalize_text( $part );
            if ( isset( $items[ $key ] ) ) { continue; }
            $items[ $key ] = $part;
            if ( count( $items ) >= 20 ) { break; }
        }
        $items = array_values( $items );
        if ( count( $items ) > 1 ) {
            $html = '<ul>';
            foreach ( $items as $item ) { $html .= '<li>' . esc_html( $item ) . '</li>'; }
            return $html . '</ul>';
        }
        return $items ? '<p>' . esc_html( $items[0] ) . '</p>' : '';
    }

    private function mb_pos( $haystack, $needle, $offset=0 ) { return function_exists('mb_stripos') ? mb_stripos($haystack,$needle,$offset,'UTF-8') : stripos($haystack,$needle,$offset); }
    private function mb_len( $value ) { return function_exists('mb_strlen') ? mb_strlen($value,'UTF-8') : strlen($value); }
    private function mb_sub( $value, $start, $length=null ) { return function_exists('mb_substr') ? mb_substr($value,$start,$length,'UTF-8') : substr($value,$start,$length); }

    private function has_divar_contact_intent( $text ) {
        $text = $this->normalize_text( $text );
        $text = preg_replace( '/چت\s*و\s*تماس|اطلاعات\s*تماس/u', ' ', $text );
        return (bool) preg_match(
            '/(?:تماس\s+(?:بگیرید|حاصل\s+(?:فرمایید|کنید)|برقرار\s+کنید)|لطفا?\s+تماس|فقط\s+تماس|پیامک\s+(?:بزنید|ارسال\s+کنید|دهید)|فقط\s+پیامک|ارسال\s+رزومه|رزومه\s+(?:ارسال\s+کنید|بفرستید)|واتساپ\s+(?:کنید|پیام\s+دهید)|تلگرام\s+(?:کنید|پیام\s+دهید)|جهت\s+(?:هماهنگی|همکاری).{0,80}تماس)/u',
            $text
        );
    }

    private function has_direct_contact( $contacts ) { return ! empty( $contacts['phones'] ) || ! empty( $contacts['sms'] ) || ! empty( $contacts['emails'] ) || ! empty( $contacts['whatsapp'] ) || ! empty( $contacts['telegram'] ); }
    private function normalize_phone( $value ) { $value = preg_replace( '/\D+/', '', $this->english_digits( $value ) ); if ( 0 === strpos( $value, '0098' ) ) { $value = substr( $value, 4 ); } elseif ( 0 === strpos( $value, '98' ) ) { $value = substr( $value, 2 ); } if ( 10 === strlen( $value ) && '9' === $value[0] ) { $value = '0' . $value; } if ( 10 === strlen( $value ) && 0 === strpos( $value, '28' ) ) { $value = '0' . $value; } return $value; }

    private function sanitize_fields( $fields ) { $out = array(); foreach ( $fields as $key => $value ) { $key = sanitize_key( $key ); if ( $key && is_scalar( $value ) ) { $out[$key] = sanitize_text_field( (string) $value ); } } return $out; }

private function map_trusted_fields( $text, $city, $title, $role = 'employer' ) {
    $text = $this->normalize_text( $text );
    $fields = array();

    $cooperation = $this->first_match_label( $text, array(
        'پاره وقت'=>'پاره‌وقت', 'پاره‌وقت'=>'پاره‌وقت', 'تمام وقت'=>'تمام‌وقت', 'تمام‌وقت'=>'تمام‌وقت',
        'پروژه ای'=>'پروژه‌ای / پیمانکاری', 'پروژه‌ای'=>'پروژه‌ای / پیمانکاری', 'پیمانکاری'=>'پروژه‌ای / پیمانکاری',
        'کارآموزی'=>'کارآموزی', 'ساعتی'=>'ساعتی / روزانه', 'روزانه'=>'ساعتی / روزانه', 'فریلنس'=>'فریلنسری', 'فریلنسری'=>'فریلنسری'
    ) );
    if ( $cooperation ) { $fields['cooperation_type'] = $cooperation; }
    if ( $this->contains( $text, 'شیفتی' ) || $this->contains( $text, 'شیفت کاری' ) ) { $fields['schedule_mode'] = 'شیفتی'; }

    if ( $this->contains( $text, 'دورکاری' ) ) { $fields['workplace_mode'] = 'دورکاری'; }
    elseif ( $this->contains( $text, 'ترکیبی' ) ) { $fields['workplace_mode'] = 'ترکیبی'; }
    elseif ( $this->contains( $text, 'حضوری' ) ) { $fields['workplace_mode'] = 'حضوری'; }

    // Salary must be explicit. E-Estekhdam's «حقوق افراد دارای شغل مشابه»
    // is only a navigation hint and must never become the ad salary.
    if ( preg_match( '/(?:حقوق|دستمزد|پرداخت).{0,30}توافقی|توافقی.{0,30}(?:حقوق|دستمزد|پرداخت)/u', $text ) ) {
        $fields['salary_range'] = 'توافقی';
        $fields['salary_structure'] = 'توافقی';
    } elseif ( preg_match( '/(?:حقوق|دستمزد|پرداخت).{0,30}(?:قانون\s*کار|وزارت\s*کار)|(?:قانون\s*کار|وزارت\s*کار).{0,30}(?:حقوق|دستمزد|پرداخت)/u', $text ) ) {
        $fields['salary_range'] = 'مطابق قانون کار';
        $fields['salary_structure'] = 'حقوق ثابت ماهانه';
    }

    if ( preg_match( '/(?:سابقه\s*(?:کار)?\s*)?مهم\s*نیست/u', $text ) || $this->contains( $text, 'بدون نیاز به سابقه' ) || $this->contains( $text, 'بدون سابقه' ) ) {
        $fields['experience_years'] = 'بدون نیاز به سابقه';
    } elseif ( preg_match( '/(\d+)\s*تا\s*(\d+)\s*سال\s*(?:سابقه|تجربه)/u', $this->english_digits( $text ), $m ) ) {
        $max = absint( $m[2] );
        if ( $max <= 3 ) { $fields['experience_years'] = '۱ تا ۳ سال'; }
        elseif ( $max <= 5 ) { $fields['experience_years'] = '۳ تا ۵ سال'; }
        else { $fields['experience_years'] = 'بیشتر از ۵ سال'; }
    }

    if ( $this->contains( $text, 'حداقل سیکل' ) || $this->contains( $text, 'مدرک سیکل' ) ) { $fields['education_level'] = 'زیر دیپلم'; }
    elseif ( $this->contains( $text, 'دیپلم' ) ) { $fields['education_level'] = 'دیپلم'; }
    elseif ( $this->contains( $text, 'کاردانی' ) ) { $fields['education_level'] = 'کاردانی'; }
    elseif ( $this->contains( $text, 'کارشناسی ارشد' ) ) { $fields['education_level'] = 'کارشناسی ارشد'; }
    elseif ( $this->contains( $text, 'کارشناسی' ) ) { $fields['education_level'] = 'کارشناسی'; }
    elseif ( preg_match( '/(?:تحصیلات|مدرک)\s*(?:مهم\s*نیست|فرقی\s*ندارد)/u', $text ) ) { $fields['education_level'] = 'مهم نیست'; }

    $gender = '';
    if ( preg_match( '/جنسیت\s*[:：]?\s*خانم/u', $text ) || preg_match( '/جذب\s+نیروی\s+خانم/u', $text ) || preg_match( '/کارگر\s+(?:ساده\s+)?خانم/u', $text ) ) { $gender = 'خانم'; }
    elseif ( preg_match( '/جنسیت\s*[:：]?\s*آقا/u', $text ) || preg_match( '/جذب\s+نیروی\s+آقا/u', $text ) ) { $gender = 'آقا'; }
    elseif ( preg_match( '/جنسیت\s*[:：]?\s*مهم\s*نیست/u', $text ) ) { $gender = 'مهم نیست'; }
    if ( $gender ) { $fields[ 'job_seeker' === $role ? 'gender' : 'gender_preference' ] = $gender; }

    if ( preg_match( '/بیمه\s+از\s+روز\s+اول/u', $text ) ) { $fields['insurance'] = 'بیمه از روز اول'; }
    elseif ( preg_match( '/بیمه\s+پس\s+از\s+(?:دوره\s+)?آزمایشی/u', $text ) ) { $fields['insurance'] = 'بیمه پس از دوره آزمایشی'; }
    elseif ( preg_match( '/(?:بدون|فاقد)\s+بیمه|بیمه\s+ندارد/u', $text ) ) { $fields['insurance'] = 'بیمه ندارد'; }
    elseif ( $this->contains( $text, 'با بیمه' ) || preg_match( '/(?:مزایای\s+)?بیمه/u', $text ) ) { $fields['insurance'] = 'بیمه دارد'; }

    $benefits = array();
    if ( $this->contains( $text, 'بیمه تکمیلی' ) ) { $benefits[] = 'بیمه تکمیلی'; }
    if ( $this->contains( $text, 'پاداش' ) ) { $benefits[] = 'پاداش'; }
    if ( $this->contains( $text, 'پورسانت' ) || $this->contains( $text, 'درصدی' ) ) { $benefits[] = 'پورسانت'; }
    if ( $this->contains( $text, 'سرویس رفت و برگشت' ) || $this->contains( $text, 'سرویس رفت‌وبرگشت' ) ) { $benefits[] = 'سرویس رفت‌وبرگشت'; }
    if ( $this->contains( $text, 'ناهار' ) || $this->contains( $text, 'غذا' ) || $this->contains( $text, 'وعده' ) || $this->contains( $text, 'میان وعده' ) || $this->contains( $text, 'میان‌وعده' ) ) { $benefits[] = 'ناهار / غذا'; }
    if ( $this->contains( $text, 'جای خواب' ) ) { $benefits[] = 'جای خواب'; }
    if ( $this->contains( $text, 'وام' ) ) { $benefits[] = 'وام'; }
    if ( $this->contains( $text, 'آموزش رایگان' ) || $this->contains( $text, 'آموزش حین کار' ) ) { $benefits[] = 'آموزش رایگان'; }
    if ( $this->contains( $text, 'ساعات کاری منعطف' ) || $this->contains( $text, 'ساعت کاری منعطف' ) ) { $benefits[] = 'ساعت منعطف'; }
    if ( $this->contains( $text, 'هدایای مناسبتی' ) || $this->contains( $text, 'هدایا و مناسبت' ) || $this->contains( $text, 'هدیه مناسبتی' ) ) { $benefits[] = 'هدایا'; }
    if ( $this->contains( $text, 'کمک هزینه رفت و آمد' ) || $this->contains( $text, 'کمک‌هزینه رفت‌وآمد' ) ) { $benefits[] = 'کمک‌هزینه رفت‌وآمد'; }
    if ( $benefits ) { $fields['benefits_list'] = array_values( array_unique( $benefits ) ); }

    $category_key = $this->detect_category_key( $title, $text );
    if ( 'services-support' === $category_key ) {
        $areas = array();
        if ( $this->contains( $text, 'نظافت' ) || $this->contains( $text, 'امور منزل' ) || $this->contains( $text, 'امورات منزل' ) ) { $areas[] = 'نظافت'; }
        if ( $this->contains( $text, 'نگهبان' ) || $this->contains( $text, 'نگهبانی' ) ) { $areas[] = 'نگهبانی'; }
        if ( $this->contains( $text, 'پشتیبانی مشتری' ) ) { $areas[] = 'پشتیبانی مشتری'; }
        if ( $areas ) { $fields['service_area'] = array_values( array_unique( $areas ) ); }
        if ( $this->contains( $text, 'امور منزل' ) || $this->contains( $text, 'امورات منزل' ) || $this->contains( $text, 'نظافت منزل' ) ) {
            $fields['work_environment'] = 'سایر';
        }
    }

    return $fields;
}


    private function detect_category_key( $title, $text ) {
        $title = $this->normalize_text( $title );
        $text = $this->normalize_text( $text );
        if ( $this->contains( $text, 'امور منزل' ) || $this->contains( $text, 'امورات منزل' ) || $this->contains( $text, 'نظافت منزل' ) || $this->contains( $text, 'خدمتکار منزل' ) || $this->contains( $text, 'خانه داری' ) || $this->contains( $text, 'خانه‌داری' ) ) { return 'services-support'; }
        $groups = array(
            'services-support'=>array('خدمات','نظافت','نگهبان','سرایدار','آبدارچی','خدمتکار'),
            'industrial-production'=>array('خط تولید','کارخانه','اپراتور تولید','مونتاژ','بسته بندی','بسته‌بندی','کنترل کیفیت'),
            'technical-engineering'=>array('مهندس','تکنسین','نقشه کش','نقشه‌کش','نقشه کشی','نقشه‌کشی','برق','مکانیک','عمران','معماری','تاسیسات'),
            'it-digital'=>array('برنامه نویس','برنامه‌نویس','نرم افزار','نرم‌افزار','شبکه','کامپیوتر','سئو','دیجیتال'),
            'sales-marketing-commerce'=>array('مدیر فروش','سرپرست فروش','فروش','بازاریاب','ویزیتور','صندوقدار','فروشنده','بازرگانی'),
            'education-cultural'=>array('مدرس','معلم','مربی','آموزش'),
            'transport-logistics'=>array('مدیر انبار','سرپرست انبار','راننده','پیک','توزیع','انباردار','انبارداری','لجستیک'),
            'restaurant-food'=>array('آشپز','رستوران','کافی شاپ','کافی‌شاپ','باریستا','قناد'),
            'medical-beauty'=>array('پرستار','پزشک','دندانپزشک','داروخانه','بهیار','درمان','زیبایی'),
            'admin-office'=>array('حسابدار','حسابداری','اداری','منابع انسانی','کارگزینی','منشی','مسئول دفتر'),
        );
        $scores = array_fill_keys( array_keys( $groups ), 0 );
        foreach ( $groups as $key => $needles ) { foreach ( $needles as $needle ) { if ( $this->contains( $text, $needle ) ) { $scores[$key] += 1; } if ( $this->contains( $title, $needle ) ) { $scores[$key] += 3; } } }
        if ( $this->contains( $title, 'کارگر ساده' ) && $scores['industrial-production'] < 2 ) { $scores['services-support'] += 1; }
        arsort( $scores ); $key = key( $scores );
        return current( $scores ) > 0 ? $key : 'services-support';
    }

    private function category_label_from_key( $key ) {
        $map = array(
            'services-support'=>'خدمات و پشتیبانی','industrial-production'=>'تولید و کارگر','technical-engineering'=>'فنی و مهندسی',
            'it-digital'=>'فناوری اطلاعات','sales-marketing-commerce'=>'فروش و بازاریابی','education-cultural'=>'آموزش',
            'transport-logistics'=>'رانندگی و حمل‌ونقل','restaurant-food'=>'رستوران و صنایع غذایی','medical-beauty'=>'درمان و سلامت','admin-office'=>'اداری و منابع انسانی'
        );
        return $map[$key] ?? 'خدمات و پشتیبانی';
    }

    private function first_match_label( $text, $map ) { foreach ( $map as $needle=>$label ) { if ( $this->contains( $text, $needle ) ) { return $label; } } return ''; }
    private function contains( $haystack, $needle ) { if ( '' === (string) $needle ) { return true; } return function_exists( 'mb_stripos' ) ? false !== mb_stripos( (string) $haystack, (string) $needle, 0, 'UTF-8' ) : false !== strpos( (string) $haystack, (string) $needle ); }
private function detect_source_from_url( $url ) {
    $host = strtolower( (string) wp_parse_url( $url, PHP_URL_HOST ) );
    if ( in_array( $host, array( 'e-estekhdam.com', 'www.e-estekhdam.com' ), true ) ) { return 'e-estekhdam'; }
    if ( in_array( $host, array( 'divar.ir', 'www.divar.ir' ), true ) ) { return 'divar'; }
    return '';
}

private function is_allowed_source_host( $host, $source ) {
    $allowed = array(
        'e-estekhdam' => array( 'e-estekhdam.com', 'www.e-estekhdam.com' ),
        'divar' => array( 'divar.ir', 'www.divar.ir' ),
    );
    return isset( $allowed[ $source ] ) && in_array( $host, $allowed[ $source ], true );
}

private function source_label( $source ) {
    return 'divar' === sanitize_key( $source ) ? 'دیوار' : 'ای‌استخدام';
}

private function detect_ad_role( $title, $text, $source = '' ) {
    $haystack = $this->normalize_text( $title . "\n" . $text );
    if ( ! $haystack ) { return 'employer'; }

    // Do not use loose substring markers such as «دنبال کار»: an employer
    // sentence like «به دنبال کارشناس فروش هستیم» contains the same bytes.
    $patterns = array(
        '/(?:^|[\n.!؟؛،])\s*جویای\s+کار(?:\s|$|[،؛.!؟])/u',
        '/(?:^|[\n.!؟؛،])\s*جویای[^\n.!؟]{0,100}(?:\s|^)ام(?:\s|$|[،؛.!؟])/u',
        '/(?:به\s+)?دنبال\s+کار(?:\s|$|[،؛.!؟])[^\n.!؟]{0,80}(?:هستم|می[‌ ]?باشم|می[‌ ]?گردم|می[‌ ]?خواهم)/u',
        '/(?:هستم|می[‌ ]?باشم)[^\n.!؟]{0,80}(?:به\s+)?دنبال\s+کار(?:\s|$|[،؛.!؟])/u',
        '/درخواست\s+کار(?:\s|$|[،؛.!؟])/u',
        '/(?:^|[\n.!؟؛،])\s*دنبال\s+کارم(?:\s|$|[،؛.!؟])/u',
        '/کار\s*می[‌ ]?خواهم/u',
        '/کار\s*میخوام/u',
        '/آماده\s+به\s+کار(?:م|\s+هستم|\s|$|[،؛.!؟])/u',
        '/رزومه\s+من(?:\s|$|[،؛.!؟])/u',
    );
    foreach ( $patterns as $pattern ) {
        if ( preg_match( $pattern, $haystack ) ) { return 'job_seeker'; }
    }
    if ( preg_match( '/آماده\s+همکاری/u', $haystack ) && preg_match( '/(?:هستم|می[‌ ]?باشم|آماده\s+همکاری\s+ام)/u', $haystack ) ) {
        return 'job_seeker';
    }
    return 'employer';
}

private function short_job_phrase( $source_title, $raw ) {
    $title = $this->normalize_text( $source_title );
    $title = preg_replace( '/^(?:استخدام|جذب|دعوت\s+به\s+همکاری|نیازمندیم|نیازمند)\s+/u', '', $title );
    $title = preg_replace( '/\s+(?:در|استان)\s+قزوین.*$/u', '', $title );
    $title = preg_replace( '/\bساده\b/u', '', $title );
    $title = trim( preg_replace( '/\s+/u', ' ', $title ), " -،؛" );

    if ( ( ! $title || $this->mb_len( $title ) < 3 ) && $this->contains( $raw, 'کارگر' ) ) { $title = 'کارگر'; }
    if ( ( $this->contains( $raw, 'امور منزل' ) || $this->contains( $raw, 'امورات منزل' ) ) ) {
        if ( ! $this->contains( $title, 'کارگر' ) ) { $title = 'کارگر'; }
        if ( ! $this->contains( $title, 'امور منزل' ) ) { $title .= ' برای امور منزل'; }
    }
    return $this->compact_title( $title ?: 'نیروی موردنیاز', 48, 7 );
}

private function build_jobseeker_title( $source_title, $raw, $city ) {
    $job = $this->short_job_phrase( $source_title, $raw );
    $title = 'جویای کار ' . trim( preg_replace( '/^(?:جویای\s+کار|آماده\s+به\s+کار|آماده\s+همکاری)\s*/u', '', $job ) );
    if ( $city && ! $this->contains( $title, $city ) ) { $title .= ' در ' . $city; }
    return $this->compact_title( $title, 72, 11 );
}

private function compact_title( $title, $max_chars = 72, $max_words = 11 ) {
    $title = trim( preg_replace( '/\s+/u', ' ', $title ) );
    $words = preg_split( '/\s+/u', $title, -1, PREG_SPLIT_NO_EMPTY );
    if ( count( $words ) > $max_words ) { $title = implode( ' ', array_slice( $words, 0, $max_words ) ); }
    if ( $this->mb_len( $title ) > $max_chars ) { $title = rtrim( $this->mb_sub( $title, 0, $max_chars ), " -،؛" ); }
    return $title;
}


    private function clean_content_html( $html ) {
        $html = preg_replace( '#<(script|style|noscript|iframe|form|button)[^>]*>.*?</\1>#isu', ' ', (string) $html );
        $allowed = array( 'p'=>array(),'br'=>array(),'strong'=>array(),'b'=>array(),'em'=>array(),'i'=>array(),'ul'=>array(),'ol'=>array(),'li'=>array(),'h2'=>array(),'h3'=>array(),'h4'=>array(),'table'=>array(),'thead'=>array(),'tbody'=>array(),'tr'=>array(),'th'=>array(),'td'=>array('colspan'=>true,'rowspan'=>true),'a'=>array('href'=>true,'title'=>true,'rel'=>true),'blockquote'=>array() );
        return trim( wp_kses( $html, $allowed ) );
    }
    private function normalize_text( $text ) { $text = html_entity_decode( wp_strip_all_tags( (string) $text ), ENT_QUOTES | ENT_HTML5, 'UTF-8' ); $text = strtr( $text, array('ي'=>'ی','ى'=>'ی','ك'=>'ک','ة'=>'ه','ۀ'=>'ه','ؤ'=>'و','إ'=>'ا','أ'=>'ا') ); $text = $this->english_digits( $text ); $text = preg_replace( '/[\x{200c}\x{200f}\x{202a}-\x{202e}]/u', ' ', $text ); return trim( preg_replace( '/\s+/u', ' ', $text ) ); }
    private function english_digits( $text ) { return strtr( (string) $text, array('۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9') ); }
    private function contact_summary( $contacts ) { $parts=array(); foreach ( array('phones','sms','emails','whatsapp','telegram') as $key ) { if ( ! empty( $contacts[$key] ) && is_array( $contacts[$key] ) ) { $parts=array_merge($parts,$contacts[$key]); } } return implode( ' | ', array_values( array_unique( $parts ) ) ); }
    private function log( $status, $reason, $title, $city, $url ) { $logs=get_option('qzih_logs',array()); if(!is_array($logs)){$logs=array();} array_unshift($logs,array('time'=>current_time('mysql'),'status'=>sanitize_text_field($status),'reason'=>sanitize_text_field($reason),'title'=>sanitize_text_field($title),'city'=>sanitize_text_field($city),'url'=>esc_url_raw($url))); update_option('qzih_logs',array_slice($logs,0,300),false); }
    private function redirect( $status ) { wp_safe_redirect( add_query_arg( array('page'=>self::PAGE_SLUG,'qzih_status'=>sanitize_key($status)), admin_url('admin.php') ) ); exit; }
}
