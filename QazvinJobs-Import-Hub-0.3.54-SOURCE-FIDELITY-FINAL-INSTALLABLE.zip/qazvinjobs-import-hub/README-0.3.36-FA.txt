QazvinJobs Import Hub 0.3.36 — Deterministic Field QA

- هماهنگ با QazvinJobs 2.3.12 و Crawler 0.3.38.
- snapshot خام فیلدهای ساختاریافته منبع در _qzih_source_fields_snapshot ذخیره می‌شود.
- snapshot نهایی همچنان در _qzih_final_fields_snapshot ذخیره می‌شود.
- کلیدهایی که از منبع آمده‌اند اما تا خروجی نهایی نرسیده‌اند در _qzih_missing_source_field_keys ثبت می‌شوند؛ بنابراین بعد از این برای تشخیص محل خطا نیاز به حدس و تکرار تست نیست.
