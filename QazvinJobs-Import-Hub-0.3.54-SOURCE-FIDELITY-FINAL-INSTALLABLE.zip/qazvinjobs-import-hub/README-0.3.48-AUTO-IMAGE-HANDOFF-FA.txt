QazvinJobs Import Hub 0.3.48 — Auto Image Handoff
==================================================

- منطق پذیرش/رد، Mapping، Contact Policy، Duplicate Protection و Draft بودن خروجی تغییر نکرده است.
- پس از تکمیل کامل Draft، رویداد `qazvinjobs_import_draft_ready` صادر می‌شود.
- QazvinJobs Core 2.3.24 این رویداد را فقط برای صف‌کردن تولید تصویر AI پس‌زمینه مصرف می‌کند.
- نبود/خطای سرویس تصویر مانع ساخت Draft نمی‌شود.
- تصویر دستی یا Thumbnail موجود هرگز جایگزین نمی‌شود.
