QazvinJobs Import Hub 0.3.25 — Canonical Category + Explicit Salary Guard

این نسخه ادامه مستقیم 0.3.24 است و ظاهر سایت/اپ را تغییر نمی‌دهد.

تغییرات:
- کلید legacy دسته برای سازگاری فرم فعلی حفظ می‌شود، اما label گروه canonical و specialty به‌صورت مستقل ذخیره می‌شوند.
- برای نمونه حسابدار: finance-accounting + accountant در متای canonical ذخیره می‌شود.
- وضعیت وجود حقوق صریح منبع با _qz_import_salary_explicit ذخیره می‌شود.
- اگر منبع حقوق نداده باشد، متاهای نمایشی قدیمی حقوق و قیمت ووکامرس پاک می‌شوند تا «توافقی» به‌صورت ساختگی برنگردد.
- Crawler 0.3.24+ بدون تغییر قابل استفاده است.
- برای نمایش صحیح label canonical و خالی ماندن حقوق وارداتیِ نامشخص، QazvinJobs Core 2.3.8 توصیه می‌شود.
