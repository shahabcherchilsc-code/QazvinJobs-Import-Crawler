QazvinJobs Import Hub 0.3.26 — Unified Field Contract Adapter

- سازگار با QazvinJobs 2.3.9 و Crawler 0.3.24+.
- software_tools کلید canonical نرم‌افزارها و ابزارها است.
- office_tools فقط به عنوان twin سازگاری برای UI قدیمی حفظ می‌شود.
- منطق source-first، دسته‌بندی canonical، specialty و salary guard نسخه 0.3.25 بدون تغییر حفظ شده است.
- هیچ تغییر ظاهری در سایت یا اپ ایجاد نمی‌کند.
