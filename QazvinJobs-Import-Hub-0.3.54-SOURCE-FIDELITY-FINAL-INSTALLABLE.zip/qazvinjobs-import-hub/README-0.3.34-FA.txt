QazvinJobs Import Hub 0.3.34 — Source-First Multi-Position Mapping Fix

- اصلاح قطعی اولویت منبع: Normalize هسته دیگر category_key یا فیلدهای استخراج‌شده را با default جایگزین نمی‌کند.
- مدیر فروش => فروش، بازاریابی و بازرگانی
- مدیر/سرپرست انبار => حمل‌ونقل، انبار و لجستیک (طبق taxonomy فعلی سایت؛ بازطراحی taxonomy بعداً جدا انجام می‌شود)
- حفظ دسته مالی و حسابداری برای حسابدار
- حفظ فیلدهای ساختاری هر ردیف چندموقعیتی پس از Schema normalization
- بدون تغییر در Routing، Controlled Test، Duplicate Protection یا منطق دیوار
