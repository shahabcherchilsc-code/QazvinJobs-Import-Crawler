<?php
/**
 * Plugin Name: QazvinJobs Import Hub
 * Plugin URI: https://qazvinjobs.ir
 * Description: دریافت آگهی‌های قزوین با وفاداری به منبع، تماس سخت‌گیرانه، فیلتر Job-only دیوار، دسته‌بندی پایدار و Duplicate Protection؛ سازگار با قرارداد فیلد یکپارچه قزوین‌جابز.
 * Version: 0.3.54
 * Author: QazvinJobs
 * License: GPL-2.0-or-later
 * Text Domain: qazvinjobs-import-hub
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'QZIH_VERSION', '0.3.54' );
define( 'QZIH_FILE', __FILE__ );
define( 'QZIH_PATH', plugin_dir_path( __FILE__ ) );

require_once QZIH_PATH . 'includes/class-qzih-importer.php';
require_once QZIH_PATH . 'includes/class-qzih-divar-auth.php';

register_activation_hook( __FILE__, array( 'QZIH_Importer', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'QZIH_Importer', 'deactivate' ) );

add_action( 'plugins_loaded', static function () {
    QZIH_Importer::get_instance();
    QZIH_Divar_Auth::get_instance();
} );
