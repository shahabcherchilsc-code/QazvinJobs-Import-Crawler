<?php
if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) { exit; }
// صف و گزارش عمداً حذف نمی‌شوند تا داده‌های بررسی مدیر از بین نروند.
