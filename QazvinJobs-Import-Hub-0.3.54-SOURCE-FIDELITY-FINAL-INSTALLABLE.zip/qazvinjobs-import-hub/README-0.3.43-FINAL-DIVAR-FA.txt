QazvinJobs Import Hub 0.3.43 — Final Divar Hardening
=====================================================

این نسخه برای نهایی‌سازی مسیر Divar → Draft در qazvinjobs.ir آماده شده است.
Core و Theme در این بسته تغییر نکرده‌اند؛ سازگاری Import Hub با QazvinJobs Core 2.3.23 بررسی شده است.

اصلاحات کلیدی دیوار:
- حذف اسکن کل صفحه برای Phone/Email و جلوگیری از تماس اشتباه Footer/Support/Related Ads.
- Contact Evidence فقط از UI تماس همان آگهی، Contact Block دارای Evidence، پاسخ شبکه Contact-scoped و متن Scope‌شده با قصد صریح تماس گرفته می‌شود.
- Payloadهای عمومی شبکه فقط در Subtree کلیدهای Phone/Mobile/Contact بررسی می‌شوند.
- Phone / Email / WhatsApp / Telegram پشتیبانی می‌شوند و شماره Login حساب دیوار از Contacts حذف می‌شود.
- متن و فیلدهای آگهی قبل از Related/Recommended sections Scope می‌شوند؛ Generic DOM scan دیوار غیرفعال است.
- Divar raw HTML به WordPress ارسال نمی‌شود؛ فقط متن Scope‌شده همان آگهی منتقل می‌شود.
- WordPress در Classification، Fallback و ساخت Draft نهایی دوباره Full Page را Parse نمی‌کند.
- برچسب‌های فعلی نوع همکاری، شیوه پرداخت، سابقه مورد نیاز، بیمه، امکان دورکاری و پایان خدمت/معافیت پوشش داده شده‌اند.
- «با امکان دورکاری» به Hybrid تبدیل ساختگی نمی‌شود؛ Fact دقیق `remote_possible=بله` در Source Snapshot حفظ می‌شود.
- Salary/Experience/Cooperation با قرارداد QazvinJobs Core 2.3.23 همسان شده‌اند.
- Employer/Job Seeker Detection برای «جویای کار»، «دنبال کارم»، «کار میخوام» و جلوگیری از خطای «به دنبال کارشناس...» سخت‌سازی شده است.
- تشخیص Logged-out فعلی دیوار و مسیر OTP/Session کامل شده است.
- OTP در Success/Expiry/Failure پاک می‌شود و Session با Sodium Secretbox یا AES-256-GCM رمزگذاری می‌شود.
- نبود Contact مستقیم در دیوار همچنان Draft + Manual Contact Review می‌سازد و Publish خودکار انجام نمی‌شود.

فایل GitHub Workflow ورود دیوار الزامی است:
.github/workflows/qazvinjobs-divar-login.yml

گزارش نهایی و مراحل Deploy داخل بسته کامل:
docs/FINAL-AUDIT-FA.md
docs/INSTALL-FA.md
docs/VALIDATION-REPORT.txt
