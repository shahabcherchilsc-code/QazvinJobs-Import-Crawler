QazvinJobs Import Hub 0.3.38 — Unified Schema

- مقادیر ساختاریافته را مستقیماً از QazvinJobs_Field_Schema می‌خواند.
- «شیفتی» دیگر cooperation_type نیست و فقط schedule_mode است.
- بازه سابقه کار، بیمه، مدل پرداخت، مزایا، مدارک و سایر aliasها به مقادیر canonical هسته normalize می‌شوند.
- مقدار ناشناخته در select/multiselect ذخیره نمی‌شود تا وب/اپ هنگام ویرایش یا نمایش به گزینه نامعتبر نخورند.
- متن خام منبع همچنان در payload/شرح می‌ماند تا اطلاعات از بین نرود.
- با فعال بودن Import Hub، Importer قدیمی هسته QazvinJobs از اجرای زمان‌بندی‌شده خارج می‌شود.

نیاز پیشنهادی: QazvinJobs 2.3.16 یا جدیدتر.
