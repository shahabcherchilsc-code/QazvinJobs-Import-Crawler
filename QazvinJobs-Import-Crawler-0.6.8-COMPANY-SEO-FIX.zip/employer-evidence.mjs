const clean = value => String(value || '').replace(/[\u200c\u200f\u202a-\u202e]/g,' ').replace(/\s+/g,' ').trim();
const generic = /^(?:(?:یک\s+)?(?:شرکت|مجموعه|کارفرما|آگهی دهنده)(?:\s+(?:معتبر|مستقیم))?|نامشخص|ای\s*استخدام|e[ -]?estekhdam)$/iu;
const cityNames = ['قزوین','الوند','تاکستان','آبیک','بوئین زهرا','محمدیه','اقبالیه','آوج','تهران','کرج','البرز'];
function validName(value) {
  const name=clean(value).replace(/^(?:شرکت|مجموعه)\s+/u,'').replace(/[،؛:：]+$/u,'').trim();
  if (!name || name.length>160 || generic.test(name) || /^(?:استخدام|شرایط|اطلاعات تماس|تسهیلات|آگهی های|ورود|ثبت نام|پشتیبانی|متقاضیان|افراد|داوطلبان|واجدین|آقایان|خانم ها)(?:\s|$)/u.test(name)) return '';
  if (cityNames.some(city=>name===city || name===`شهر ${city}` || name===`استان ${city}`)) return '';
  return name;
}
export function companyFromHiringLine(value) {
  const text=clean(value);
  if (/^استخدام(?:\s|$)/u.test(text)) return '';
  const match=text.match(/^(.{2,160}?)\s+(?:به\s+منظور|جهت|برای|در\s+(?:استان|شهر)|دعوت\s+به\s+همکاری|استخدام\s+می)/u);
  return match ? validName(match[1]) : '';
}
export function companyFromSourceTitle(value) {
  const text=clean(value).replace(/\s*[-–|]\s*(?:ای\s*استخدام|دیوار).*$/iu,'');
  const match=text.match(/^استخدام\s+.{2,100}?\s+در\s+(.+)$/u);
  if (!match) return '';
  return validName(match[1].replace(/\s+در\s+(?:استان\s+|شهر\s+)?(?:قزوین|البرز|تهران|کرج)\s*$/u,''));
}
export function resolveEmployerEvidence(input={}) {
  for (const [kind, values] of [['explicit_label',[input.explicit]],['jsonld',[input.jsonld]],['company_element',input.companyElements||[]]]) {
    for (const value of values) { const name=validName(value); if (name) return {name,evidence:kind,intro:''}; }
  }
  for (const line of input.lines||[]) {
    const name=companyFromHiringLine(line);
    if (name) return {name,evidence:'hiring_sentence',intro:clean(line)};
  }
  for (const title of input.sourceTitles||[]) {
    const name=companyFromSourceTitle(title);
    if (name) return {name,evidence:'source_title',intro:''};
  }
  return {name:'',evidence:'',intro:''};
}
