import { test, before, after } from 'node:test';
import assert from 'node:assert/strict';
import vm from 'node:vm';
import { readFileSync } from 'node:fs';
import { createHash } from 'node:crypto';
import { chromium } from 'playwright';
import { resolveEmployerEvidence } from '../employer-evidence.mjs';
import { sourceAgeDays, sourceTimestamp, relativeAgeDays, discoveryMeta, collectDiscoveryRows, freshnessDecision } from '../freshness.mjs';

const source = readFileSync(new URL('../crawler.mjs', import.meta.url), 'utf8');
const context = vm.createContext({ console, URL, Date, createHash, sourceAgeDays, resolveEmployerEvidence, DIVAR_LOGIN_PHONE: '' });
vm.runInContext(source.slice(source.indexOf('const POSITION_FACT_LABELS'), source.indexOf("console.log('CRAWLER VERSION")) + '\n' + source.slice(source.indexOf('async function inspectDivarJobCategory')), context);
const plain = value => JSON.parse(JSON.stringify(value));
let browser, page;
const browserTest = process.env.QZIH_SKIP_BROWSER_TESTS === '1' ? test.skip : test;
before(async () => {
  if (process.env.QZIH_SKIP_BROWSER_TESTS === '1') return;
  browser = await chromium.launch({ executablePath: process.env.QZIH_TEST_BROWSER || undefined, headless: true, args: ['--no-sandbox'] });
  page = await browser.newPage();
});
after(async () => { await browser?.close(); });

test('minute/hour/day ages sort chronologically; work hours do not imply freshness', () => {
  assert.equal(relativeAgeDays('ساعت کاری ۸ تا ۱۷؛ ۵ روز پیش'), 5);
  assert.equal(relativeAgeDays('۳ ساعت پیش'), 3/24);
  assert.equal(relativeAgeDays('٢ دقیقه پیش'), 2/1440);
  assert.equal(relativeAgeDays('پریروز'), 2);
  assert.equal(relativeAgeDays('جدید'), null);
  const cards = ['۴ روز پیش', '۲ روز پیش', '۶ ساعت پیش', '۱۵ دقیقه پیش'];
  assert.deepEqual(cards.sort((a,b) => discoveryMeta(b).priority - discoveryMeta(a).priority), ['۱۵ دقیقه پیش','۶ ساعت پیش','۲ روز پیش','۴ روز پیش']);
});

test('Gregorian/Persian dates and invalid dates use explicit source age', () => {
  const now = Date.parse('2026-10-05T12:00:00Z');
  assert.equal(sourceAgeDays('2026-10-01T12:00:00Z','امروز',now), 4);
  assert.equal(sourceAgeDays('', '۳ ساعت پیش', now), 3/24);
  assert.equal(sourceTimestamp('۱۴۰۵/۰۷/۱۳'), Date.parse('2026-10-05T00:00:00+03:30'));
  assert.equal(sourceTimestamp('2026-02-30'), null);
  assert.equal(sourceTimestamp('1405-13-01'), null);
  assert.equal(sourceAgeDays('', 'ساعات کاری ۹ تا ۱۷', now), null);
});

browserTest('search discovery isolates timestamps per card and excludes sidebars', async () => {
  await page.setContent(`<main><section><article><a href="https://www.e-estekhdam.com/kabc123/old">قدیمی</a><span>۵ روز پیش</span></article><article><a href="https://www.e-estekhdam.com/kdef456/new">جدیدترین</a><span>۳ ساعت پیش</span></article></section><aside><a href="https://www.e-estekhdam.com/kghi789">دیگر</a>امروز</aside></main>`);
  const rows = await page.evaluate(collectDiscoveryRows, { source: 'e-estekhdam' });
  assert.equal(rows.length, 2);
  assert.equal(relativeAgeDays(rows[0].context), 5);
  assert.equal(relativeAgeDays(rows[1].context), 3/24);
});

browserTest('infinite-list discovery retains new Divar cards after scrolling, without reopening', async () => {
  await page.setContent(`<main><article><a href="https://divar.ir/v/job/kabc12345">کارگر</a>۱ ساعت پیش</article></main>`);
  const first = await page.evaluate(collectDiscoveryRows, { source: 'divar' });
  await page.evaluate(() => { document.querySelector('main').innerHTML = '<article><a href="https://divar.ir/v/job/xyz12345">حسابدار</a>۲ ساعت پیش</article>'; });
  const second = await page.evaluate(collectDiscoveryRows, { source: 'divar' });
  assert.equal(new Set([...first,...second].map(r => r.href)).size, 2);
});

browserTest('E-Estekhdam exact fields exclude similar jobs and preserve schedules', async () => {
  await page.setContent(`<h1>استخدام حسابدار</h1><main><h1>استخدام حسابدار</h1>
    <p>شرکت نمونه جهت تکمیل کادر خود استخدام می‌کند</p><p>۳ ساعت پیش</p>
    <div><span>شهر</span><span>قزوین</span></div>
    <p>نوع همکاری تمام‌وقت</p><div><span>حداقل تحصیلات</span><span>کارشناسی</span></div>
    <div><span>رشته تحصیلی</span><span>حسابداری</span></div>
    <div><span>سابقه کار</span><span>۳ سال</span></div>
    <h2>شرایط احراز</h2><p>تسلط به اکسل</p>
    <h2>ساعات کاری</h2><p>شنبه تا پنجشنبه ۸ تا ۱۶</p>
    <h2>تسهیلات و مزایا</h2><p>بیمه و ناهار</p>
    <h2>اطلاعات تماس</h2><p>تلفن ۰۹۱۲۳۴۵۶۷۸۹</p>
    <h2>آگهی‌های استخدام مشابه</h2><div><span>جنسیت</span><span>خانم</span></div><p>۱ روز پیش</p>
    </main><footer>آدرس: نشانی پشتیبانی</footer>`);
  const data = await context.extractJob(page,'e-estekhdam');
  const fields = plain(context.buildSourceFirstFields(data,'قزوین','employer','e-estekhdam','https://www.e-estekhdam.com/kabc123'));
  assert.equal(data.companyName, 'نمونه');
  assert.equal(fields.company_name, 'نمونه');
  assert.equal(data.structured.study_field, 'حسابداری');
  assert.equal(fields.study_field, 'حسابداری');
  assert.equal(fields.cooperation_type, 'تمام‌وقت');
  assert.equal(fields.experience_years, '۲ تا ۵ سال');
  assert.equal(fields.work_start,'08:00');
  assert.equal(fields.work_end,'16:00');
  assert.equal(fields.gender_preference, undefined);
  assert.equal(data.publishedRelative, '۳ ساعت پیش');
  assert.ok(!fields.requirements.includes('۸ تا ۱۶'));
  assert.ok(!data.structured.address_detail.includes('پشتیبانی'));
  assert.ok(data.contactText.includes('۰۹۱۲۳۴۵۶۷۸۹'));
  assert.equal(await page.locator('main').count(),1,'temporary parsing copy removed');
});

browserTest('named E-Estekhdam employer and source metadata reach the final payload', async () => {
  await page.setContent(`<title>استخدام کارگر انبار در آریا لجستیک پارس در قزوین - ای استخدام</title>
    <main><h1>کارگر انبار</h1><p>آریا لجستیک پارس در استان قزوین جهت تکمیل کادر خود دعوت به همکاری می‌کند.</p>
    <p>۱ ساعت پیش</p><h2>شرایط احراز</h2><p>دقت در کار</p><h2>اطلاعات تماس</h2><p>۰۹۱۲۳۴۵۶۷۸۹</p></main>`);
  const data = await context.extractJob(page,'e-estekhdam');
  const fields = plain(context.buildSourceFirstFields(data,'قزوین','employer','e-estekhdam','https://www.e-estekhdam.com/k7i18e'));
  assert.equal(data.companyName, 'آریا لجستیک پارس');
  assert.equal(fields.company_name, 'آریا لجستیک پارس');
  assert.ok(fields.source_intro.includes('دعوت به همکاری'));
  await page.setContent(`<meta property="og:title" content="استخدام کارگر انبار در نمونه لجستیک پارس در قزوین - ای استخدام">
    <main><h1>کارگر انبار</h1><h2>شرایط احراز</h2><p>دقت در کار</p><h2>اطلاعات تماس</h2><p>۰۹۱۲۳۴۵۶۷۸۹</p></main>`);
  const metadataOnly = await context.extractJob(page,'e-estekhdam');
  assert.equal(metadataOnly.companyName, 'نمونه لجستیک پارس');
});

browserTest('missing adjacent fact value never becomes next label; Divar JSON-LD description fallback', async () => {
  await page.setContent(`<main><h1>حسابدار</h1><p>ساعت کاری ۸ تا ۱۷</p><p>پریروز</p><p>نوع همکاری</p><p>حقوق ماهانه</p><p>توافقی</p><h2>آگهی‌های مشابه</h2><p>تحصیلات</p><p>کارشناسی</p></main><script type="application/ld+json">{"@type":"JobPosting","description":"<p>تسلط به اکسل و نرم افزار مالی</p>"}</script>`);
  const data = await context.extractJob(page,'divar');
  assert.equal(data.structured.cooperation_type, '');
  assert.equal(data.structured.education_level, '');
  assert.equal(data.publishedRelative,'پریروز');
  assert.ok(data.sourceDescriptionText.includes('اکسل'));
});

test('multi-position payload contains each position description and exact field only', () => {
  const base = { title:'استخدام چند شغل', sourceDescriptionText:'متن عمومی اشتباه', cityExact:'قزوین', structured:{city_name:'قزوین',company_name:'نمونه',gender_preference:'خانم'} };
  const a = context.buildMultiPositionData(base,{title:'حسابدار', requirements:'تسلط به اکسل و حداقل ۳ سال سابقه', benefits:'بیمه',facts:{'رشته تحصیلی':'حسابداری','نوع همکاری':'تمام‌وقت','ساعات کاری':'۸ تا ۱۶'}},0,2);
  const b = context.buildMultiPositionData(base,{title:'راننده', requirements:'داشتن گواهینامه پایه دو و سابقه رانندگی',benefits:'ناهار',facts:{'نوع همکاری':'پاره‌وقت'}},1,2);
  assert.ok(a.sourceDescriptionText.includes('اکسل'));
  assert.ok(!b.sourceDescriptionText.includes('اکسل'));
  assert.ok(!a.sourceDescriptionText.includes('عمومی'));
  assert.equal(a.structured.gender_preference,'');
  assert.equal(a.structured.cooperation_type,'تمام‌وقت');
  assert.equal(b.structured.cooperation_type,'پاره‌وقت');
  assert.equal(context.buildSourceFirstFields(a,'قزوین','employer','e-estekhdam','url').study_field,'حسابداری');
});


test('daily age gate rejects old and unknown ads and trusts detail dates over new badges', () => {
  const now = Date.parse('2026-10-05T12:00:00Z');
  assert.equal(freshnessDecision({publishedAt:'2026-10-01T12:00:00Z'}, {ageDays:0}, 2, true, now).allow, false);
  assert.equal(freshnessDecision({}, {}, 2, true, now).allow, false);
  assert.equal(freshnessDecision({}, {ageDays:1}, 2, true, now).allow, true);
  assert.equal(freshnessDecision({publishedRelative:'۳ ساعت پیش'}, {ageDays:5}, 2, true, now).allow, true);
  assert.equal(freshnessDecision({}, {}, 0, true, now).allow, true);
});

test('verified Iranian phone/email channels are preserved and unrelated numbers are rejected', () => {
  const contacts = plain(context.extractContacts('تلفن: ۰۹۱۲۳۴۵۶۷۸۹ ایمیل: jobs@example.com', [], 'e-estekhdam'));
  assert.ok(contacts.phones.includes('09123456789'));
  assert.ok(contacts.emails.includes('jobs@example.com'));
  assert.equal(context.hasContact(context.extractContacts('رزومه خود را ارسال کنید', [], 'divar')),0);
});

test('explicit experience overrides unrelated requirements; descriptions retain newlines', () => {
  const fields = context.buildSourceFirstFields({title:'کارشناس',structured:{experience_years:'۳ سال',requirements:'تحصیلات مهم نیست',study_field:'مهندسی برق',job_description:'خط اول\nخط دوم'}},'قزوین','employer','e-estekhdam','url');
  assert.equal(fields.experience_years,'۲ تا ۵ سال');
  assert.equal(fields.study_field,'مهندسی برق');
  assert.equal(fields.job_description,'خط اول\nخط دوم');
});

test('canonical select validation preserves allowed values with Persian half-spaces', () => {
  const expected = {
    cooperation_type:'تمام‌وقت',
    seniority_level:'تازه‌کار',
    contract_type:'قرارداد پروژه‌ای',
    disability_support:'امکان‌پذیر است',
    military_status:'امریه پذیرفته می‌شود',
    work_schedule:'شنبه تا پنج‌شنبه (تمام‌وقت)',
    salary_structure:'پروژه‌ای'
  };
  assert.deepEqual(plain(context.validateCanonicalFields(expected,'employer')),expected);
  assert.equal(context.validateCanonicalFields({cooperation_type:'تمام وقت'},'employer').cooperation_type,'تمام‌وقت');
  assert.equal(context.validateCanonicalFields({cooperation_type:'مقدار نامعتبر'},'employer').cooperation_type,undefined);
});

test('canonical lists preserve half-space choices, deduplicate variants and reject invalid values', () => {
  const expected = {
    benefits_list:['سرویس رفت‌وبرگشت','کمک‌هزینه رفت‌وآمد'],
    work_days:['سه‌شنبه'],
    soft_skills:['مسئولیت‌پذیری','گزارش‌نویسی'],
    required_documents:['نمونه‌کار']
  };
  assert.deepEqual(plain(context.validateCanonicalFields(expected,'employer')),expected);
  assert.deepEqual(plain(context.validateCanonicalFields({work_days:['سه شنبه','سه‌شنبه','نامعتبر']},'employer')).work_days,['سه‌شنبه']);
});

test('source-first mapping retains full-time and part-time cooperation in the final payload', () => {
  for (const type of ['تمام‌وقت','پاره‌وقت']) {
    const fields=context.buildSourceFirstFields({title:'حسابدار',structured:{cooperation_type:type}},'قزوین','employer','e-estekhdam','url');
    assert.equal(fields.cooperation_type,type);
  }
});
