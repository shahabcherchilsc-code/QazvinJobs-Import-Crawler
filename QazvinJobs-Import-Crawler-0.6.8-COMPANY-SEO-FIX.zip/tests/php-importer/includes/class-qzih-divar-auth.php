<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

final class QZIH_Divar_Auth {
    const STATE_OPTION   = 'qzih_divar_auth_state';
    const META_OPTION    = 'qzih_divar_auth_meta';
    const PENDING_OPTION = 'qzih_divar_auth_pending';
    const OTP_OPTION     = 'qzih_divar_auth_otp';

    private static $instance = null;

    public static function get_instance() {
        if ( null === self::$instance ) { self::$instance = new self(); }
        return self::$instance;
    }

    private function __construct() {
        add_action( 'rest_api_init', array( $this, 'register_routes' ) );
        add_action( 'admin_post_qzih_divar_submit_otp', array( $this, 'submit_otp' ) );
        add_action( 'admin_post_qzih_divar_clear_session', array( $this, 'clear_session' ) );
    }

    public function register_routes() {
        $permission = array( $this, 'rest_permission' );
        register_rest_route( QZIH_Importer::REST_NAMESPACE, '/divar-auth/begin', array(
            'methods' => 'POST', 'callback' => array( $this, 'rest_begin' ), 'permission_callback' => $permission,
        ) );
        register_rest_route( QZIH_Importer::REST_NAMESPACE, '/divar-auth/otp', array(
            'methods' => 'GET', 'callback' => array( $this, 'rest_get_otp' ), 'permission_callback' => $permission,
        ) );
        register_rest_route( QZIH_Importer::REST_NAMESPACE, '/divar-auth/session', array(
            array( 'methods' => 'GET',  'callback' => array( $this, 'rest_get_session' ),  'permission_callback' => $permission ),
            array( 'methods' => 'POST', 'callback' => array( $this, 'rest_save_session' ), 'permission_callback' => $permission ),
        ) );
        register_rest_route( QZIH_Importer::REST_NAMESPACE, '/divar-auth/fail', array(
            'methods' => 'POST', 'callback' => array( $this, 'rest_fail' ), 'permission_callback' => $permission,
        ) );
    }

    public function rest_permission( WP_REST_Request $request ) {
        $saved = (string) get_option( QZIH_Importer::TOKEN_OPTION, '' );
        $provided = trim( (string) $request->get_header( 'x-qzih-token' ) );
        if ( ! $provided ) {
            $authorization = trim( (string) $request->get_header( 'authorization' ) );
            if ( 0 === stripos( $authorization, 'Bearer ' ) ) { $provided = trim( substr( $authorization, 7 ) ); }
        }
        return $saved && $provided && hash_equals( $saved, $provided );
    }

    public function rest_begin( WP_REST_Request $request ) {
        $data = (array) $request->get_json_params();
        $session_id = sanitize_text_field( $data['session_id'] ?? '' );
        if ( ! preg_match( '/^[A-Za-z0-9_-]{12,100}$/', $session_id ) ) {
            return new WP_Error( 'invalid_session_id', 'شناسه اتصال دیوار معتبر نیست.', array( 'status' => 400 ) );
        }
        $expires_at = absint( $data['expires_at'] ?? ( time() + 8 * MINUTE_IN_SECONDS ) );
        $pending = array(
            'session_id'   => $session_id,
            'phone_masked' => sanitize_text_field( $data['phone_masked'] ?? '' ),
            'status'       => 'waiting_otp',
            'requested_at' => current_time( 'mysql' ),
            'expires_at'   => min( $expires_at, time() + 10 * MINUTE_IN_SECONDS ),
            'error'        => '',
        );
        update_option( self::PENDING_OPTION, $pending, false );
        delete_option( self::OTP_OPTION );
        return $this->no_store_response( array( 'ok' => true, 'status' => 'waiting_otp', 'expires_at' => $pending['expires_at'] ) );
    }

    public function rest_get_otp( WP_REST_Request $request ) {
        $session_id = sanitize_text_field( $request->get_param( 'session_id' ) );
        $pending = (array) get_option( self::PENDING_OPTION, array() );
        if ( ! $pending || empty( $pending['session_id'] ) || ! hash_equals( (string) $pending['session_id'], $session_id ) ) {
            return new WP_Error( 'auth_session_not_found', 'درخواست فعال ورود دیوار پیدا نشد.', array( 'status' => 404 ) );
        }
        if ( time() > absint( $pending['expires_at'] ?? 0 ) ) {
            $pending['status'] = 'expired';
            update_option( self::PENDING_OPTION, $pending, false );
            delete_option( self::OTP_OPTION );
            return new WP_Error( 'auth_session_expired', 'زمان واردکردن کد دیوار تمام شده است.', array( 'status' => 410 ) );
        }
        $otp = (array) get_option( self::OTP_OPTION, array() );
        if ( empty( $otp['otp_encrypted'] ) || empty( $otp['session_id'] ) || ! hash_equals( $session_id, (string) $otp['session_id'] ) ) {
            return $this->no_store_response( array( 'ok' => true, 'status' => 'waiting_otp', 'otp' => '' ) );
        }
        $plain_otp = $this->decrypt( (string) $otp['otp_encrypted'] );
        if ( is_wp_error( $plain_otp ) ) { return $plain_otp; }
        return $this->no_store_response( array( 'ok' => true, 'status' => 'otp_ready', 'otp' => (string) $plain_otp ) );
    }

    public function rest_save_session( WP_REST_Request $request ) {
        $data = (array) $request->get_json_params();
        $session_id = sanitize_text_field( $data['session_id'] ?? '' );
        $state = isset( $data['storage_state'] ) && is_array( $data['storage_state'] ) ? $data['storage_state'] : array();
        $pending = (array) get_option( self::PENDING_OPTION, array() );
        if ( ! $pending || empty( $pending['session_id'] ) || ! hash_equals( (string) $pending['session_id'], $session_id ) ) {
            return new WP_Error( 'auth_session_mismatch', 'شناسه درخواست ورود با درخواست فعال مطابقت ندارد.', array( 'status' => 409 ) );
        }
        if ( ! $this->valid_storage_state( $state ) ) {
            return new WP_Error( 'invalid_storage_state', 'نشست دریافت‌شده از دیوار معتبر نیست.', array( 'status' => 400 ) );
        }
        $encoded = wp_json_encode( $state, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );
        $encrypted = $this->encrypt( $encoded );
        if ( is_wp_error( $encrypted ) ) { return $encrypted; }
        update_option( self::STATE_OPTION, $encrypted, false );
        update_option( self::META_OPTION, array(
            'status'       => 'connected',
            'saved_at'     => current_time( 'mysql' ),
            'saved_ts'     => time(),
            'phone_masked' => sanitize_text_field( $pending['phone_masked'] ?? '' ),
            'cookie_count' => count( $state['cookies'] ?? array() ),
            'last_error'   => '',
        ), false );
        delete_option( self::PENDING_OPTION );
        delete_option( self::OTP_OPTION );
        return $this->no_store_response( array( 'ok' => true, 'status' => 'connected' ) );
    }

    public function rest_get_session() {
        $encrypted = get_option( self::STATE_OPTION, '' );
        $meta = (array) get_option( self::META_OPTION, array() );
        if ( ! $encrypted ) {
            return new WP_Error( 'divar_session_missing', 'حساب دیوار هنوز متصل نشده است.', array( 'status' => 404, 'qzih_status' => 'missing' ) );
        }
        $decoded = $this->decrypt( $encrypted );
        if ( is_wp_error( $decoded ) ) { return $decoded; }
        $state = json_decode( $decoded, true );
        if ( ! $this->valid_storage_state( $state ) ) {
            return new WP_Error( 'divar_session_invalid', 'نشست ذخیره‌شده دیوار قابل استفاده نیست.', array( 'status' => 409, 'qzih_status' => 'invalid' ) );
        }
        $meta['last_fetched_at'] = current_time( 'mysql' );
        update_option( self::META_OPTION, $meta, false );
        return $this->no_store_response( array( 'ok' => true, 'status' => 'connected', 'storage_state' => $state, 'meta' => $meta ) );
    }

    public function rest_fail( WP_REST_Request $request ) {
        $data = (array) $request->get_json_params();
        $session_id = sanitize_text_field( $data['session_id'] ?? '' );
        $pending = (array) get_option( self::PENDING_OPTION, array() );
        if ( $pending && ! empty( $pending['session_id'] ) && $session_id && hash_equals( (string) $pending['session_id'], $session_id ) ) {
            $pending['status'] = 'failed';
            $pending['error'] = sanitize_text_field( $data['error'] ?? 'خطای نامشخص در ورود دیوار' );
            update_option( self::PENDING_OPTION, $pending, false );
            delete_option( self::OTP_OPTION );
        }
        $meta = (array) get_option( self::META_OPTION, array() );
        $meta['last_error'] = sanitize_text_field( $data['error'] ?? '' );
        update_option( self::META_OPTION, $meta, false );
        return $this->no_store_response( array( 'ok' => true ) );
    }

    public function submit_otp() {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'دسترسی غیرمجاز' ); }
        check_admin_referer( 'qzih_divar_submit_otp' );
        $pending = (array) get_option( self::PENDING_OPTION, array() );
        $session_id = sanitize_text_field( $_POST['session_id'] ?? '' );
        $otp = preg_replace( '/\D+/', '', $this->to_english_digits( wp_unslash( $_POST['otp'] ?? '' ) ) );
        if ( ! $pending || empty( $pending['session_id'] ) || ! hash_equals( (string) $pending['session_id'], $session_id ) ) {
            $this->redirect_notice( 'divar_session_missing' );
        }
        if ( time() > absint( $pending['expires_at'] ?? 0 ) || ! preg_match( '/^\d{4,8}$/', $otp ) ) {
            $this->redirect_notice( 'divar_otp_invalid' );
        }
        $encrypted_otp = $this->encrypt( $otp );
        if ( is_wp_error( $encrypted_otp ) ) { $this->redirect_notice( 'divar_otp_invalid' ); }
        update_option( self::OTP_OPTION, array( 'session_id' => $session_id, 'otp_encrypted' => $encrypted_otp, 'created_at' => time() ), false );
        $pending['status'] = 'otp_submitted';
        update_option( self::PENDING_OPTION, $pending, false );
        $this->redirect_notice( 'divar_otp_saved' );
    }

    public function clear_session() {
        if ( ! current_user_can( 'manage_options' ) ) { wp_die( 'دسترسی غیرمجاز' ); }
        check_admin_referer( 'qzih_divar_clear_session' );
        delete_option( self::STATE_OPTION );
        delete_option( self::META_OPTION );
        delete_option( self::PENDING_OPTION );
        delete_option( self::OTP_OPTION );
        $this->redirect_notice( 'divar_session_cleared' );
    }

    public static function render_admin_card() {
        $pending = (array) get_option( self::PENDING_OPTION, array() );
        $meta = (array) get_option( self::META_OPTION, array() );
        $has_state = (bool) get_option( self::STATE_OPTION, '' );
        $pending_active = $pending && time() <= absint( $pending['expires_at'] ?? 0 ) && in_array( $pending['status'] ?? '', array( 'waiting_otp', 'otp_submitted' ), true );
        $status = $has_state ? 'متصل' : ( $pending_active ? 'در انتظار کد پیامکی' : 'متصل نشده' );
        $status_color = $has_state ? '#008a20' : ( $pending_active ? '#996800' : '#b32d2e' );
        ?>
        <div style="max-width:1280px;background:#fff;border:1px solid #dcdcde;border-radius:14px;padding:20px;margin-top:18px">
            <h2 style="margin-top:0">اتصال حساب دیوار برای نمایش اطلاعات تماس</h2>
            <p><strong>وضعیت:</strong> <span style="font-weight:800;color:<?php echo esc_attr( $status_color ); ?>"><?php echo esc_html( $status ); ?></span>
            <?php if ( ! empty( $meta['saved_at'] ) ) : ?><span style="margin-right:14px">آخرین اتصال: <?php echo esc_html( $meta['saved_at'] ); ?></span><?php endif; ?></p>
            <p>برای اتصال، در GitHub اکشن <code>QazvinJobs Divar Login 0.3.45</code> را اجرا کنید. پس از ارسال پیامک، همین صفحه را تازه‌سازی کرده و کد را در فرم زیر ثبت کنید. کد پیامک داخل GitHub یا گزارش‌ها ذخیره نمی‌شود.</p>
            <?php if ( $pending_active ) : ?>
                <div style="background:#fff8e5;border:1px solid #dba617;border-radius:10px;padding:14px;margin:12px 0">
                    <p style="margin-top:0"><strong>کد ورود برای <?php echo esc_html( $pending['phone_masked'] ?? 'شماره تعریف‌شده' ); ?> ارسال شده است.</strong></p>
                    <form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                        <input type="hidden" name="action" value="qzih_divar_submit_otp">
                        <input type="hidden" name="session_id" value="<?php echo esc_attr( $pending['session_id'] ?? '' ); ?>">
                        <?php wp_nonce_field( 'qzih_divar_submit_otp' ); ?>
                        <input name="otp" inputmode="numeric" autocomplete="one-time-code" required pattern="[0-9۰-۹]{4,8}" style="font-size:22px;letter-spacing:5px;max-width:220px" placeholder="کد پیامکی">
                        <button class="button button-primary">ثبت کد برای GitHub</button>
                    </form>
                    <?php if ( ! empty( $pending['error'] ) ) : ?><p style="color:#b32d2e"><?php echo esc_html( $pending['error'] ); ?></p><?php endif; ?>
                </div>
            <?php endif; ?>
            <p><strong>Secret لازم در GitHub:</strong> <code>QZIH_DIVAR_LOGIN_PHONE</code> با شماره موبایل حساب کاری دیوار.</p>
            <?php if ( $has_state || $pending ) : ?>
                <p><a class="button" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=qzih_divar_clear_session' ), 'qzih_divar_clear_session' ) ); ?>" onclick="return confirm('نشست ذخیره‌شده دیوار پاک شود؟');">قطع اتصال و پاک‌کردن نشست دیوار</a></p>
            <?php endif; ?>
            <?php if ( ! empty( $meta['last_error'] ) ) : ?><p style="color:#b32d2e"><strong>آخرین خطا:</strong> <?php echo esc_html( $meta['last_error'] ); ?></p><?php endif; ?>
        </div>
        <?php
    }

    private function valid_storage_state( $state ) {
        if ( ! is_array( $state ) || ! isset( $state['cookies'] ) || ! is_array( $state['cookies'] ) ) { return false; }
        foreach ( $state['cookies'] as $cookie ) {
            $domain = strtolower( (string) ( $cookie['domain'] ?? '' ) );
            if ( false !== strpos( $domain, 'divar.ir' ) ) { return true; }
        }
        foreach ( (array) ( $state['origins'] ?? array() ) as $origin ) {
            if ( false !== strpos( strtolower( (string) ( $origin['origin'] ?? '' ) ), 'divar.ir' ) ) { return true; }
        }
        return false;
    }

    private function encrypt( $plain ) {
        $key = hash( 'sha256', wp_salt( 'auth' ) . '|qzih-divar-session', true );
        if ( function_exists( 'sodium_crypto_secretbox' ) ) {
            $nonce = random_bytes( SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
            return 'sodium:' . base64_encode( $nonce . sodium_crypto_secretbox( $plain, $nonce, $key ) );
        }
        if ( function_exists( 'openssl_encrypt' ) ) {
            $iv = random_bytes( 12 ); $tag = '';
            $cipher = openssl_encrypt( $plain, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag );
            if ( false === $cipher ) { return new WP_Error( 'encrypt_failed', 'رمزگذاری نشست دیوار ناموفق بود.', array( 'status' => 500 ) ); }
            return 'openssl:' . base64_encode( $iv . $tag . $cipher );
        }
        return new WP_Error( 'crypto_unavailable', 'کتابخانه رمزگذاری امن روی هاست فعال نیست.', array( 'status' => 500 ) );
    }

    private function decrypt( $payload ) {
        $key = hash( 'sha256', wp_salt( 'auth' ) . '|qzih-divar-session', true );
        if ( 0 === strpos( $payload, 'sodium:' ) && function_exists( 'sodium_crypto_secretbox_open' ) ) {
            $raw = base64_decode( substr( $payload, 7 ), true );
            if ( false === $raw || strlen( $raw ) <= SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ) { return new WP_Error( 'decrypt_failed', 'نشست دیوار خراب است.', array( 'status' => 500 ) ); }
            $nonce = substr( $raw, 0, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES );
            $plain = sodium_crypto_secretbox_open( substr( $raw, SODIUM_CRYPTO_SECRETBOX_NONCEBYTES ), $nonce, $key );
            return false === $plain ? new WP_Error( 'decrypt_failed', 'رمزگشایی نشست دیوار ناموفق بود.', array( 'status' => 500 ) ) : $plain;
        }
        if ( 0 === strpos( $payload, 'openssl:' ) && function_exists( 'openssl_decrypt' ) ) {
            $raw = base64_decode( substr( $payload, 8 ), true );
            if ( false === $raw || strlen( $raw ) <= 28 ) { return new WP_Error( 'decrypt_failed', 'نشست دیوار خراب است.', array( 'status' => 500 ) ); }
            $iv = substr( $raw, 0, 12 ); $tag = substr( $raw, 12, 16 ); $cipher = substr( $raw, 28 );
            $plain = openssl_decrypt( $cipher, 'aes-256-gcm', $key, OPENSSL_RAW_DATA, $iv, $tag );
            return false === $plain ? new WP_Error( 'decrypt_failed', 'رمزگشایی نشست دیوار ناموفق بود.', array( 'status' => 500 ) ) : $plain;
        }
        return new WP_Error( 'decrypt_unavailable', 'روش رمزگذاری نشست با تنظیمات فعلی هاست سازگار نیست.', array( 'status' => 500 ) );
    }

    private function no_store_response( $data ) {
        $response = rest_ensure_response( $data );
        $response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0' );
        $response->header( 'Pragma', 'no-cache' );
        return $response;
    }

    private function to_english_digits( $value ) {
        return strtr( (string) $value, array( '۰'=>'0','۱'=>'1','۲'=>'2','۳'=>'3','۴'=>'4','۵'=>'5','۶'=>'6','۷'=>'7','۸'=>'8','۹'=>'9','٠'=>'0','١'=>'1','٢'=>'2','٣'=>'3','٤'=>'4','٥'=>'5','٦'=>'6','٧'=>'7','٨'=>'8','٩'=>'9' ) );
    }

    private function redirect_notice( $code ) {
        wp_safe_redirect( add_query_arg( 'qzih_notice', sanitize_key( $code ), admin_url( 'admin.php?page=' . QZIH_Importer::PAGE_SLUG ) ) );
        exit;
    }
}
