<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Source-backed editorial content. No external AI service or invented job facts. */
final class QZIH_Editorial {
    public static function comparison_text( $text ) {
        $text = strtr( sanitize_text_field( (string) $text ), array( 'ي' => 'ی', 'ك' => 'ک', 'ى' => 'ی' ) );
        return trim( preg_replace( '/[\s\x{200c}\x{200f}\x{202a}-\x{202e}]+/u', ' ', $text ) );
    }

    public static function name( $value ) {
        $value = self::comparison_text( $value );
        $value = preg_replace( '/^[\s:：؛،]+|[\s:：؛،]+$/u', '', preg_replace( '/^(?:شرکت|مجموعه)\s+/u', '', $value ) );
        if ( ! $value || count( preg_split( '//u', $value, -1, PREG_SPLIT_NO_EMPTY ) ) > 160 ) { return ''; }
        if ( preg_match( '/^(?:(?:یک\s+)?(?:شرکت|مجموعه|کارفرما|آگهی دهنده)(?:\s+(?:معتبر|مستقیم))?|نامشخص|ای\s*استخدام|e[ -]?estekhdam)$/ui', $value ) ) { return ''; }
        if ( preg_match( '/^(?:استخدام|شرایط|اطلاعات تماس|تسهیلات|آگهی های|ورود|ثبت نام|پشتیبانی|متقاضیان|افراد|داوطلبان|واجدین|آقایان|خانم ها)(?:\s|$)/u', $value ) ) { return ''; }
        if ( preg_match( '/^(?:(?:شهر|استان)\s+)?(?:قزوین|الوند|تاکستان|آبیک|بوئین زهرا|محمدیه|اقبالیه|آوج|تهران|کرج|البرز)$/u', $value ) ) { return ''; }
        return $value;
    }

    public static function company_from_title( $title ) {
        $title = self::comparison_text( $title );
        $title = preg_replace( '/\s*[-–|]\s*(?:ای\s*استخدام|دیوار).*$/ui', '', $title );
        if ( ! preg_match( '/^استخدام\s+.{2,100}?\s+در\s+(.+)$/u', $title, $m ) ) { return ''; }
        return self::name( preg_replace( '/\s+در\s+(?:استان\s+|شهر\s+)?(?:قزوین|البرز|تهران|کرج)\s*$/u', '', $m[1] ) );
    }

    public static function company_from_hiring_line( $line ) {
        $line = self::comparison_text( $line );
        if ( preg_match( '/^استخدام(?:\s|$)/u', $line ) ) { return ''; }
        if ( preg_match( '/^(.{2,160}?)\s+(?:به\s+منظور|جهت|برای|در\s+(?:استان|شهر)|دعوت\s+به\s+همکاری|استخدام\s+می)/u', $line, $m ) ) { return self::name( $m[1] ); }
        return '';
    }

    public static function resolve_company( $fields, $source_title, $raw ) {
        $name = self::name( $fields['company_name'] ?? '' );
        if ( $name ) { return $name; }
        $name = self::company_from_hiring_line( $fields['source_intro'] ?? '' );
        if ( $name ) { return $name; }
        foreach ( preg_split( '/[\r\n.!؟]+/u', wp_strip_all_tags( (string) $raw ) ) as $line ) {
            $name = self::company_from_hiring_line( $line );
            if ( $name ) { return $name; }
        }
        return self::company_from_title( $source_title );
    }

    /** A schema's empty default must not replace a value extracted from this ad. */
    public static function merge_fields( $source, $normalized ) {
        $source = is_array( $source ) ? $source : array();
        if ( ! is_array( $normalized ) ) { return $source; }
        $result = array_merge( $source, $normalized );
        foreach ( $source as $key => $value ) {
            if ( is_array( $value ) && array() === $value ) { $result[ $key ] = array(); continue; }
            if ( '' === $value || null === $value ) { continue; }
            if ( ! isset( $normalized[ $key ] ) || '' === $normalized[ $key ] || array() === $normalized[ $key ] ) { $result[ $key ] = $value; }
        }
        // Narrative/common facts are independent of the category field filter.
        foreach ( self::common_fields( $source ) as $key => $value ) { $result[ $key ] = $value; }
        return $result;
    }

    public static function common_fields( $fields ) {
        return array_intersect_key( (array) $fields, array_flip( array(
            'company_name', 'company_activity', 'source_intro', 'company_evidence',
            'job_title', 'city_name', 'province', 'requirements', 'responsibilities',
            'job_description', 'benefits_description', 'address_detail', 'source_url',
            'source_name', 'source_ad_id', 'source_raw_title',
        ) ) );
    }

    public static function limit_text( $value, $length ) {
        $value = trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( (string) $value ) ) );
        $chars = preg_split( '//u', $value, -1, PREG_SPLIT_NO_EMPTY );
        if ( count( $chars ) <= $length ) { return $value; }
        $part = implode( '', array_slice( $chars, 0, max( 1, $length - 1 ) ) );
        $without_partial_word = preg_replace( '/\s+\S*$/u', '', $part );
        return ( $without_partial_word ?: $part ) . '…';
    }

    public static function source_html( $text ) {
        $text = sanitize_textarea_field( (string) $text );
        if ( ! $text ) { return ''; }
        $headings = array( 'شرایط احراز', 'شرایط همکاری', 'شرح وظایف', 'ساعات کاری', 'تسهیلات و مزایا', 'مزایا و تسهیلات', 'سایر مزایا', 'محل کار' );
        $html = ''; $items = array(); $seen = array();
        $flush = static function () use ( &$html, &$items ) {
            if ( ! $items ) { return; }
            if ( 1 === count( $items ) ) { $html .= '<p>' . esc_html( $items[0] ) . '</p>'; }
            else { $html .= '<ul>'; foreach ( $items as $item ) { $html .= '<li>' . esc_html( $item ) . '</li>'; } $html .= '</ul>'; }
            $items = array();
        };
        foreach ( preg_split( '/\r?\n|\s*[•●▪]\s*/u', $text ) as $line ) {
            $line = preg_replace( '/^[\s•●▪–—-]+|[\s•●▪–—-]+$/u', '', $line );
            if ( ! $line || preg_match( '/^[.\-–—:؛،]+$/u', $line ) ) { continue; }
            $key = self::comparison_text( $line );
            if ( isset( $seen[ $key ] ) ) { continue; }
            $seen[ $key ] = true;
            if ( in_array( $key, $headings, true ) ) { $flush(); $html .= '<h3>' . esc_html( $line ) . '</h3>'; }
            else { $items[] = $line; }
        }
        $flush();
        return $html;
    }

    public static function build( $fields, $job, $city, $role, $source_content ) {
        $job = sanitize_text_field( $job );
        $city = sanitize_text_field( $city );
        $company = 'employer' === $role ? self::name( $fields['company_name'] ?? '' ) : '';
        $location = $city ? ' در ' . $city : '';
        $headline = ( 'job_seeker' === $role ? 'کارجوی ' : 'استخدام ' ) . $job . $location;
        $lead = 'job_seeker' === $role
            ? 'این کارجو برای همکاری در حوزه «' . $job . '»' . $location . ' آمادگی دارد.'
            : ( $company ? $company . ' برای موقعیت «' . $job . '»' . $location . ' نیرو جذب می‌کند.' : 'برای موقعیت «' . $job . '»' . $location . ' نیرو جذب می‌شود.' );
        if ( ! empty( $fields['cooperation_type'] ) ) { $lead .= ' نوع همکاری: ' . sanitize_text_field( $fields['cooperation_type'] ) . '.'; }
        $content = '<h2>' . esc_html( $headline ) . '</h2><p>' . esc_html( $lead ) . '</p>' . wp_kses_post( $source_content );
        $meta = $lead;
        $facts = array();
        if ( ! empty( $fields['experience_years'] ) ) { $facts[] = 'سابقه: ' . sanitize_text_field( $fields['experience_years'] ); }
        if ( ! empty( $fields['insurance'] ) ) { $facts[] = 'بیمه: ' . sanitize_text_field( $fields['insurance'] ); }
        if ( $facts ) { $meta .= ' ' . implode( '؛ ', $facts ) . '.'; }
        return array(
            'content' => $content,
            'seo_title' => self::limit_text( $headline, 58 ) . ' | قزوین جابز',
            'seo_description' => self::limit_text( $meta, 160 ),
            'focus_keyword' => $headline,
        );
    }
}
