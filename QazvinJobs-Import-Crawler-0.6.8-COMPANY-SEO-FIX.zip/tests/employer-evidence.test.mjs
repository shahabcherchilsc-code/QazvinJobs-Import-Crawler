import { test } from 'node:test';
import assert from 'node:assert/strict';
import { companyFromHiringLine, companyFromSourceTitle, resolveEmployerEvidence } from '../employer-evidence.mjs';
test('named employer does not need a generic company prefix',()=>{
  assert.equal(companyFromHiringLine('آریا لجستیک اینترنشنال پارس در استان قزوین جهت تکمیل کادر خود دعوت به همکاری می‌کند'),'آریا لجستیک اینترنشنال پارس');
  assert.equal(companyFromHiringLine('شرکت نمونه جهت تکمیل کادر خود استخدام می‌کند'),'نمونه');
});
test('source metadata title identifies an employer, never a city or generic employer',()=>{
  assert.equal(companyFromSourceTitle('استخدام کارگر انبار در آریا لجستیک اینترنشنال پارس در قزوین - ای استخدام'),'آریا لجستیک اینترنشنال پارس');
  assert.equal(companyFromSourceTitle('استخدام کارگر انبار در قزوین'),'');
  assert.equal(companyFromSourceTitle('استخدام کارگر انبار در یک مجموعه معتبر'),'');
  assert.equal(companyFromHiringLine('استخدام کارگر انبار در قزوین'),'');
  assert.equal(companyFromHiringLine('متقاضیان جهت ارسال رزومه اقدام کنند'),'');
});
test('explicit source name wins; metadata fallback remains supported',()=>{
  assert.equal(resolveEmployerEvidence({explicit:'شرکت نمونه',jsonld:'شرکت دیگر',lines:[]}).name,'نمونه');
  assert.equal(resolveEmployerEvidence({jsonld:'ای استخدام',sourceTitles:['استخدام کارگر انبار در آریا لجستیک']}).name,'آریا لجستیک');
  assert.equal(resolveEmployerEvidence({lines:['شرایط احراز جهت استخدام اعلام می‌شود']}).name,'');
});
