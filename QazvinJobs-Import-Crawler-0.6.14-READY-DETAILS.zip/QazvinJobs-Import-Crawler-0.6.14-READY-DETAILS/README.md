QazvinJobs Import Crawler 0.6.14 — shared source-detail readiness and strict date evidence.
Read README-READY-DETAILS-FA.md. Keep cPanel on --daily-test. First run validate_only in GitHub; then reconnect Divar and review a bounded real import.
