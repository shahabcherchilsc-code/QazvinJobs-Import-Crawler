import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readFile, mkdtemp, writeFile, rm } from 'node:fs/promises';
import { tmpdir } from 'node:os';
import { join } from 'node:path';
import { createHash } from 'node:crypto';
import { chromium } from 'playwright';
import { identity, redact, auditRecord, allowRequest } from '../audit-utils.mjs';
import { ImportLedger } from '../import-ledger.mjs';
import { extractJob } from '../source-parser.mjs';

test('audit URL validation rejects other hosts, credentials, protocols, and non-job paths', () => {
  for (const u of ['https://qazvinjobs.ir/ads/job', 'https://divar.ir.evil.test/v/a12345', 'http://divar.ir/v/a12345', 'https://u:p@divar.ir/v/a12345', 'https://divar.ir:444/v/a12345', 'https://divar.ir/s/qazvin/jobs']) assert.throws(() => identity(u));
  assert.deepEqual(identity('https://www.e-estekhdam.com/kAbc123-title?phone=SECRET#x'), {source:'e-estekhdam', id:'kabc123', url:'https://www.e-estekhdam.com/kabc123'});
  assert.equal(identity('https://divar.ir/v/عنوان/aBcd1234?contact=SECRET').id, 'divar-abcd1234');
});

test('audit network gate blocks receiver, mutations, contacts, login and unrelated requests', () => {
  assert.equal(allowRequest('https://divar.ir/v/a123456', 'GET', 'document'), true);
  for (const [url, method] of [['https://qazvinjobs.ir/wp-json/qazvinjobs-import/v1/batch','GET'], ['https://divar.ir/v/a123456','POST'], ['https://api.divar.ir/v1/contact/abc','GET'], ['https://divar.ir/auth/otp','GET'], ['https://tracker.test/foo','GET']]) assert.equal(allowRequest(url, method, 'fetch'), false);
});

test('anonymous session bootstrap and exact public search POSTs are allowed without allowing authenticated operations', () => {
  const prefix = 'https://www.e-estekhdam.com';
  for (const path of ['/search-api/auth/session', '/search-api/search', '/search-api/search/filter-options']) {
    assert.equal(allowRequest(prefix+path, 'POST', 'xhr', '{}'), true, path);
  }
  assert.equal(allowRequest(prefix+'/search-api/search', 'POST', 'xhr', '{"page":1,"keyword":"حسابدار"}'), true);
  assert.equal(allowRequest(prefix+'/search-api/search?page=1', 'POST', 'xhr', '{"where":{}}'), true);
  assert.equal(allowRequest(prefix+'/search-api/search?page=50', 'POST', 'xhr', '{"where":{}}'), true);
  for (const [path, body] of [
    ['/search-api/auth/session', '{"phone":"09123456789"}'],
    ['/search-api/auth/session', '{"client":"unknown"}'],
    ['/search-api/search', '{"password":"secret"}'],
    ['/search-api/search', '{"nested":{"token":"secret"}}'],
    ['/search-api/search/filter-options', '[]'],
    ['/search-api/search', '{broken'],
    ['/search-api/search', JSON.stringify({keyword:'x'.repeat(32768)})],
    ['/search-api/search?destination=other', '{}'],
    ['/search-api/search?page=0', '{}'], ['/search-api/search?page=51', '{}'],
    ['/search-api/search?page=1&page=2', '{}'], ['/search-api/search/filter-options?page=1', '{}'],
    ['/search-api/contact', '{}'], ['/search-api/panel/apply','{}'],
    ['/search-api/auth/otp', '{}'], ['/search-api/search/delete', '{}']
  ]) assert.equal(allowRequest(prefix+path, 'POST', 'xhr', body), false, path+' '+body.slice(0,50));
  for (const host of ['https://qazvinjobs.ir','https://api.e-estekhdam.com','http://www.e-estekhdam.com','https://www.e-estekhdam.com.evil.test']) {
    assert.equal(allowRequest(host+'/search-api/search','POST','xhr','{}'), false);
  }
});

test('ambiguous today prose is flagged and the stricter publication date policy rejects it', () => {
  const own = identity('https://www.e-estekhdam.com/kabc123');
  const row = auditRecord(own, {title:'job', publishedRelative:'مصاحبه فقط امروز انجام می‌شود'}, {}, {}, Date.parse('2026-11-08T08:00:00Z'));
  assert.equal(row.decision.allow, false);
  assert.equal(row.warning, 'ambiguous_relative_date');
  const old = auditRecord(own, {title:'job', publishedAt:'2026-10-01', publishedRelative:'امروز'}, {}, {});
  assert.equal(old.decision.allow, false);
  assert.equal(old.warning, '');
});

test('report strips contacts and keeps separate page and vacancy identity history', () => {
  const own = identity('https://www.e-estekhdam.com/kabc123');
  const row = auditRecord(own, {title:'SECRET_CONTENT', contentText:'SECRET_CONTENT', phone:'09123456789', publishedRelative:'امروز ۰۹۱۲۳۴۵۶۷۸۹ x@example.com https://x.test/contact'}, {}, {'e-estekhdam:kabc123-pos-abc':1, 'e-estekhdam:kabc123-pos-def':2});
  assert.equal(row.page_id_acknowledged, false);
  assert.equal(row.acknowledged_position_ids, 2);
  assert.ok(!JSON.stringify(row).includes('SECRET_CONTENT'));
  for (const value of ['09123456789', 'x@example.com', 'https://x.test']) assert.ok(!JSON.stringify(row).includes(value));
  assert.equal(redact('۰۹۱۲۳۴۵۶۷۸۹'), '[redacted]');
});

test('read-only ledger inspection leaves history bytes unchanged', async () => {
  const folder = await mkdtemp(join(tmpdir(),'qj-audit-'));
  try {
    const file = join(folder,'history.json');
    const endpoint = 'https://example.test/receiver';
    const raw = JSON.stringify({version:1, site_key:createHash('sha256').update(endpoint).digest('hex'), entries:{'e-estekhdam:kabc123':1}})+'\n';
    await writeFile(file, raw);
    const ledger = new ImportLedger(file,endpoint);
    await ledger.load();
    assert.equal(auditRecord(identity('https://www.e-estekhdam.com/kabc123'),{title:'job'}, {}, ledger.entries).page_id_acknowledged,true);
    assert.equal(await readFile(file,'utf8'), raw);
    const entry = await readFile(new URL('../audit-sources.mjs',import.meta.url),'utf8');
    assert.doesNotMatch(entry, /\.acknowledge\(|sendBatch\(|sendDiagnostics\(|import .*from ['"]\.\/crawler\.mjs/);
  } finally { await rm(folder,{recursive:true,force:true}); }
});

const browserTest = process.env.QZIH_SKIP_BROWSER_TESTS === '1' ? test.skip : test;
browserTest('a listing can bootstrap via public POSTs while a receiver POST remains blocked', async () => {
  const browser = await chromium.launch({executablePath:process.env.QZIH_TEST_BROWSER || undefined,headless:true,args:['--no-sandbox']});
  try {
    const context = await browser.newContext({serviceWorkers:'block'});
    const seen = [];
    await context.route('**/*', async route => {
      const request = route.request();
      const allowed = allowRequest(request.url(),request.method(),request.resourceType(),request.postData() || '');
      if (!allowed) return route.abort();
      const u = new URL(request.url());
      if (request.method() === 'POST') {
        seen.push(u.pathname);
        return route.fulfill({status:200,contentType:'application/json',body:'{}'});
      }
      return route.fulfill({status:200,contentType:'text/html',body:`<main id="listing">loading</main><script>
        (async()=>{
          for(const path of ['/search-api/auth/session','/search-api/search/filter-options','/search-api/search?page=1']) {
            const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json'},body:'{}'});
            if(!r.ok)throw new Error('bootstrap failed');
          }
          document.querySelector('main').innerHTML='<a href="/kabc123">استخدام حسابدار</a>';
          try {await fetch('https://qazvinjobs.ir/wp-json/qazvinjobs-import/v1/batch',{method:'POST',body:'{}'});} catch {window.receiverBlocked=true;}
        })();
      </script>`});
    });
    const page=await context.newPage();
    await page.goto('https://www.e-estekhdam.com/jobs/استخدام-در-قزوین');
    await page.locator('main a[href*="/k"]').waitFor();
    await page.waitForFunction(()=>window.receiverBlocked===true);
    assert.deepEqual(seen, ['/search-api/auth/session','/search-api/search/filter-options','/search-api/search']);
  } finally { await browser.close(); }
});
browserTest('audit uses the production parser and identifies ambiguous description dates', async () => {
  const browser = await chromium.launch({executablePath:process.env.QZIH_TEST_BROWSER || undefined,headless:true,args:['--no-sandbox']});
  try {
    const page = await browser.newPage();
    await page.setContent('<main><h1>استخدام کارگر</h1><h2>توضیحات</h2><p>مصاحبه فقط امروز انجام می‌شود</p></main>');
    const data = await extractJob(page,'e-estekhdam');
    const row = auditRecord(identity('https://www.e-estekhdam.com/kabc123'),data,{},{});
    assert.equal(data.publishedRelative, '');
    assert.equal(row.decision.allow, false);
    await page.setContent('<script type="application/ld+json">{"@type":"JobPosting","datePosted":"2026-10-01"}</script><main><h1>استخدام کارگر</h1><p>امروز</p></main>');
    const old = auditRecord(identity('https://www.e-estekhdam.com/kabc123'),await extractJob(page,'e-estekhdam'),{}, {}, Date.parse('2026-11-08T08:00:00Z'));
    assert.equal(old.decision.allow,false);
  } finally { await browser.close(); }
});
