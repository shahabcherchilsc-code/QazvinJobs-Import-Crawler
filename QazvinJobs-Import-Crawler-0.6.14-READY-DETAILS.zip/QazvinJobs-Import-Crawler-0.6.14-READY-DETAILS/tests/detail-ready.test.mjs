import { test } from 'node:test';
import assert from 'node:assert/strict';
import { readReadyJob, usableJobTitle } from '../detail-ready.mjs';
import { publicationRelativeAge, discoveryMeta, freshnessDecision } from '../freshness.mjs';
import { chromium } from 'playwright';
import { extractJob } from '../source-parser.mjs';

function mockPage(getData, heading = () => 'کارگر انبار') {
  let time = 0;
  const page = { locator: () => ({ first: () => ({ waitFor: async () => {}, innerText: async () => heading(time) }) }) };
  return { page, options: { now: () => time, pause: async ms => { time += ms; }, extract: async () => getData(time) } };
}
test('delayed job data is awaited beyond the old 800 ms cutoff', async () => {
  const data = { title: 'کارگر انبار', publishedRelative: '۳ ساعت پیش' };
  const { page, options } = mockPage(t => t < 1500 ? { title: 'بارگذاری' } : data, t => t < 1250 ? 'بارگذاری' : 'کارگر انبار');
  const result = await readReadyJob(page, 'e-estekhdam', options);
  assert.equal(result.data, data);
  assert.ok(result.readiness.wait_ms >= 1500);
  assert.ok(result.readiness.attempts > 1);
});
test('a ready old ad stays old; waiting never relaxes age policy', async () => {
  const { page, options } = mockPage(() => ({ title: 'کارگر انبار', publishedAt: '2026-01-01' }));
  const { data } = await readReadyJob(page, 'e-estekhdam', options);
  assert.equal(freshnessDecision(data, {}, 1, true, Date.parse('2026-11-09T09:00:00+03:30'), 'today_yesterday').allow, false);
});
test('loaded ad without a date stays unknown and is refused by production policy', async () => {
  const { page, options } = mockPage(() => ({ title: 'کارگر انبار', publishedRelative: 'مصاحبه فقط امروز انجام می‌شود' }));
  const loaded = await readReadyJob(page, 'divar', { ...options, timeoutMs: 1000 });
  assert.equal(loaded.readiness.state, 'ready_without_date');
  assert.equal(freshnessDecision(loaded.data, {}, 1, true).allow, false);
});
test('a persistent loading shell becomes an explicit load error', async () => {
  const { page, options } = mockPage(() => ({ title: 'بارگذاری' }), () => 'بارگذاری');
  await assert.rejects(readReadyJob(page, 'e-estekhdam', { ...options, timeoutMs: 500 }), error => error.code === 'SOURCE_DETAIL_NOT_READY');
  assert.equal(usableJobTitle('loading...'), false);
  assert.equal(usableJobTitle('کارگر انبار'), true);
});
test('parser errors remain errors rather than turning into unknown dates', async () => {
  const { page, options } = mockPage(() => { throw new Error('parser failed'); });
  await assert.rejects(readReadyJob(page, 'divar', options), /parser failed/);
});
test('work and interview prose cannot supply publication evidence', () => {
  for (const text of ['مصاحبه فقط امروز انجام می‌شود', 'از دیروز نیرو می‌خواهیم', 'شروع دوره ۳ روز پیش بود', 'ساعات کاری ۸ تا ۱۷', 'آگهی جدید امروز']) {
    assert.equal(publicationRelativeAge(text), null, text);
    assert.equal(discoveryMeta(text).ageDays, null, text);
  }
  assert.equal(publicationRelativeAge('۳ ساعت پیش در قزوین، خیابان اصلی'), 3/24);
  assert.equal(publicationRelativeAge('انتشار: دیروز'), 1);
  assert.equal(publicationRelativeAge('یک ساعت پیش'), 1/24);
  assert.equal(discoveryMeta('کارگر انبار؛ مصاحبه امروز', 1, 1, 0, '', ['۳ ساعت پیش']).ageDays, 3/24);
});
const browserTest = process.env.QZIH_SKIP_BROWSER_TESTS === '1' ? test.skip : test;
browserTest('real DOM hydration and a later publication phrase are handled by the shared path', async () => {
  const browser = await chromium.launch({ executablePath: process.env.QZIH_TEST_BROWSER || undefined, headless: true, args: ['--no-sandbox'] });
  try {
    const page = await browser.newPage();
    await page.setContent(`<title>بارگذاری - ای استخدام</title><main id="job"></main><script>
      setTimeout(() => document.querySelector('main').innerHTML = '<h1>کارگر انبار</h1><p>مصاحبه فقط امروز انجام می‌شود</p><p>۳ ساعت پیش</p><h2>شرایط احراز</h2><p>دقت در انجام وظایف</p>', 1400);
    </script>`);
    await page.waitForTimeout(800);
    const tooEarly = await extractJob(page, 'e-estekhdam');
    assert.equal(tooEarly.publishedRelative, '');
    const loaded = await readReadyJob(page, 'e-estekhdam');
    assert.equal(loaded.data.title, 'کارگر انبار');
    assert.equal(loaded.data.publishedRelative, '۳ ساعت پیش');
    assert.equal(loaded.readiness.state, 'ready_with_date');
  } finally { await browser.close(); }
});
