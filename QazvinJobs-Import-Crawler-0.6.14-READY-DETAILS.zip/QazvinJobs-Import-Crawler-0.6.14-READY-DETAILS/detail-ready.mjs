import { extractJob } from './source-parser.mjs';
import { sourceTimestamp, publicationRelativeAge } from './freshness.mjs';

export function usableJobTitle(value) {
  const text = String(value || '').replace(/[\u200c\u200f\u202a-\u202e]/g, ' ').replace(/\s+/g, ' ').trim();
  return text.length >= 2 && !/^(?:بارگذاری(?:\s*[.….]*)?|در حال بارگذاری(?:\s*[.….]*)?|loading(?:\s*[.….]*)?|ای\s*استخدام|دیوار)$/iu.test(text);
}

// Use the same readiness path for production and audit. An HTTP shell or
// loading title must never become an ad whose publication date is "unknown".
export async function readReadyJob(page, source, options = {}) {
  const timeoutMs = options.timeoutMs ?? 12_000;
  const extract = options.extract ?? extractJob;
  const now = options.now ?? Date.now;
  const pause = options.pause ?? (ms => page.waitForTimeout(ms));
  const start = now();
  let last = null, attempts = 0;
  try {
    await page.locator('h1').first().waitFor({ state: 'visible', timeout: Math.min(timeoutMs, 8_000) });
    while (true) {
      const data = await extract(page, source);
      attempts++;
      const heading = await page.locator('h1').first().innerText();
      if (usableJobTitle(heading) && usableJobTitle(data.title)) {
        last = data;
        if (sourceTimestamp(data.publishedAt) !== null || publicationRelativeAge(data.publishedRelative) !== null) {
          return { data, readiness: { state: 'ready_with_date', attempts, wait_ms: Math.max(0, now() - start) } };
        }
      }
      const left = timeoutMs - (now() - start);
      if (left <= 0) break;
      await pause(Math.min(250, left));
    }
  } catch (error) {
    if (error.name !== 'TimeoutError') throw error;
  }
  if (last) return { data: last, readiness: { state: 'ready_without_date', attempts, wait_ms: Math.max(0, now() - start) } };
  const error = new Error('SOURCE_DETAIL_NOT_READY: current job heading/content did not finish loading');
  error.code = 'SOURCE_DETAIL_NOT_READY';
  throw error;
}
