import { readFile, appendFile } from 'node:fs/promises';

const file = process.argv[2] || 'run-summary.json';
let report;
try { report = JSON.parse(await readFile(file, 'utf8')); }
catch (error) {
  console.log(`No crawl result to summarize (${error.code || error.message}); this is expected for validation or account connection runs.`);
  process.exit(0);
}
const e = report.sources?.['e-estekhdam'] || {};
const d = report.sources?.divar || {};
const sent = Number(report.total_sent || 0);
const reasons = [];
if (!sent && !report.discovery_only && !report.audit_only) reasons.push('No eligible ads were sent to WordPress; GitHub success means only that the crawler completed.');
if (e.discovered && !e.discovery_sort_verified) reasons.push(`E-Estekhdam: newest sort NOT verified (status: ${e.discovery_sort_status || 'unknown'}). Results may be relevance-ordered. This is a discovery warning, not a reason to loosen age filters.`);
if (e.discovered && !e.fresh_discovered) reasons.push('E-Estekhdam: zero cards had a trusted recent date in the search listing. This DOES NOT mean all listed ads were old; detail dates are checked separately.');
if (e.unknown_age || d.unknown_age) reasons.push(`Publication date unknown: E-Estekhdam=${e.unknown_age || 0}, Divar=${d.unknown_age || 0}. Unknown dates remain blocked; see freshness-samples.json and detail readiness counters.`);
if (d.login_required) reasons.push(`Divar requested login ${d.login_required} time(s), despite saved session loaded=${Boolean(d.auth_loaded)}. Reconnect with connect_divar; ${d.auth_required_skipped || 0} remaining candidates were paused without weakening the direct-contact rule.`);
if ((e.detail_load_failures || 0) + (d.detail_load_failures || 0)) reasons.push(`Detail pages that never became ready: ${(e.detail_load_failures || 0) + (d.detail_load_failures || 0)}.`);
if ((e.too_old || 0) > 0 && !(e.accepted || 0)) reasons.push(`E-Estekhdam: ${e.too_old} old candidates; fresh cards: ${e.fresh_discovered || 0}. Verify dates and current listing order.`);
if (!d.auth_loaded && (d.no_contact || d.contact_reveal_failed || 0)) reasons.push('Divar: no saved authenticated session; use the manual connect_divar action and enter the SMS code in WordPress Import Hub.');
if ((d.non_job_category || 0) > 0) reasons.push(`Divar: ${d.non_job_category} links failed the strict current-ad jobs-category check; do not disable this gate without checking sample pages.`);
if ((e.errors || 0) + (d.errors || 0)) reasons.push(`Parser/runtime errors: ${(e.errors || 0) + (d.errors || 0)}; inspect logs.`);
const table = `| Source | Found | Read | Old | No date | Seen before | No contact | Accepted |\n|---|---:|---:|---:|---:|---:|---:|---:|\n| E-Estekhdam | ${e.discovered || 0} | ${e.inspected || 0} | ${e.too_old || 0} | ${e.unknown_age || 0} | ${e.previously_imported || 0} | ${e.no_contact || 0} | ${e.accepted || 0} |\n| Divar | ${d.discovered || 0} | ${d.inspected || 0} | ${d.too_old || 0} | ${d.unknown_age || 0} | ${d.previously_imported || 0} | ${d.no_contact || 0} | ${d.accepted || 0} |`;
const probeText = Object.entries(e.discovery_probe || {}).map(([id, present]) => `${id}: ${present ? 'found in discovered list' : 'NOT found in discovered list'}`).join('; ');
const markdown = `## QazvinJobs daily crawler - actual import results\n\n**Mode:** ${report.audit_only ? 'SOURCE DETAIL AUDIT (no imports)' : report.discovery_only ? 'DISCOVERY ONLY (no imports)' : 'normal crawler'}  \n**WordPress items accepted:** ${sent}  \n**Freshness:** ${report.limits?.freshness_mode || 'rolling'}  \n**E-Estekhdam newest sort:** ${e.discovery_sort_status || 'not_attempted'}; verified=${Boolean(e.discovery_sort_verified)}  \n**E-Estekhdam discovery probe:** ${probeText || 'not requested'}  \n**Divar saved session loaded (not proof of login validity):** ${Boolean(d.auth_loaded)}\n\n${table}\n\n${reasons.map(x => '- ' + x).join('\n')}\n`;
console.log(markdown);
if (!sent && !report.discovery_only && !report.audit_only) console.log('::warning title=QazvinJobs: 0 imported ads::Crawler completed, but no new eligible job reached WordPress. See job summary for source-specific blockers.');
if (process.env.GITHUB_STEP_SUMMARY) await appendFile(process.env.GITHUB_STEP_SUMMARY, markdown, 'utf8');
