import { test } from 'node:test';
import assert from 'node:assert/strict';
import { discoveryProbe, preferNewestEEstekhdam } from '../eestekhdam-discovery.mjs';
import { discoveryMeta } from '../freshness.mjs';

test('discovery probe checks actual discovered IDs rather than inventing seeded candidates', () => {
  const urls = ['https://www.e-estekhdam.com/k6952h-%D8%A2%DA%AF%D9%87%DB%8C', 'https://www.e-estekhdam.com/kabc32-x'];
  const getId = url => (new URL(url).pathname.match(/^\/(k[a-z0-9]+)/i) || [])[1];
  assert.deepEqual(discoveryProbe('k6952h,kdoesnotexist', urls, getId), {k6952h: true, kdoesnotexist: false});
});

test('discovery recognizes a card-specific machine-readable publication time', () => {
  const threeHoursAgo = new Date(Date.now() - 3 * 3600_000).toISOString();
  const age = discoveryMeta('بازاریاب قزوین', 1, 2, 3, threeHoursAgo);
  assert.ok(age.ageDays > 0 && age.ageDays < 0.3);
  assert.equal(age.order, 1003);
  assert.ok(age.priority > 999);
});

function mockPage({hasNewest = true, startsSelected = false} = {}) {
  let selected = startsSelected;
  const clicked = [];
  const emptyLocator = () => ({count: async () => 0});
  const radio = {
    count: async () => 1,
    nth: () => ({ isVisible: async () => true,
      click: async () => { clicked.push('newest'); selected = true; } })
  };
  return {
    clicked,
    url: () => 'https://www.e-estekhdam.com/jobs/استخدام-در-قزوین',
    getByRole: role => hasNewest && role === 'radio' ? radio : emptyLocator(),
    getByText: () => emptyLocator(),
    evaluate: async callback => callback.toString().includes('selected_control') ? (selected ? 'selected_control' : '') : 'kold123,knew456',
    waitForTimeout: async () => {},
    locator: () => ({first: () => ({waitFor: async () => {}})})
  };
}

test('newest sort is marked verified only when the site reports the selected radio', async () => {
  const page = mockPage();
  const result = await preferNewestEEstekhdam(page);
  assert.equal(result.status, 'selected_control');
  assert.equal(result.selected, true);
  assert.deepEqual(page.clicked, ['newest']);
});

test('no newest UI control is a diagnostic warning, not a silently fabricated success', async () => {
  const result = await preferNewestEEstekhdam(mockPage({hasNewest:false}));
  assert.equal(result.status, 'control_not_found');
  assert.equal(result.selected, false);
});

test('already-selected newest UI is not clicked again', async () => {
  const page = mockPage({startsSelected:true});
  const result = await preferNewestEEstekhdam(page);
  assert.equal(result.status, 'already_selected');
  assert.deepEqual(page.clicked, []);
});
