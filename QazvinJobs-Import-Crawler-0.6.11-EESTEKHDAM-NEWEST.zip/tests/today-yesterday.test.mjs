import { test } from 'node:test';
import assert from 'node:assert/strict';
import { freshnessDecision, iranCalendarDayDifference } from '../freshness.mjs';

const now = Date.parse('2026-10-18T10:00:00+03:30');
const status = (date, mode = 'today_yesterday') => freshnessDecision(
  {publishedAt: date}, {}, 1, true, now, mode
);
test('Iran local yesterday is eligible even when older than 24 rolling hours', () => {
  assert.equal(status('2026-10-17T00:15:00+03:30').allow, true);
  assert.equal(status('2026-10-17T00:15:00+03:30', 'rolling').allow, false);
});
test('day before yesterday is excluded even when under 48 hours', () => {
  const result = status('2026-10-16T23:59:00+03:30');
  assert.equal(result.dayDifference, 2);
  assert.equal(result.allow, false);
});
test('midnight in Iran, not UTC midnight, changes freshness', () => {
  const t = Date.parse('2026-10-17T23:59:00+03:30');
  assert.equal(iranCalendarDayDifference(t, Date.parse('2026-10-18T00:01:00+03:30')), 1);
  assert.equal(iranCalendarDayDifference(t, Date.parse('2026-10-17T23:59:20+03:30')), 0);
});
test('relative timestamp can use scoped card fallback, but unknown date is rejected', () => {
  assert.equal(freshnessDecision({publishedRelative:'دیروز'}, {}, 1, true, now, 'today_yesterday').allow, true);
  assert.equal(freshnessDecision({}, {ageDays:30/24}, 1, true, now, 'today_yesterday').allow, true);
  assert.equal(freshnessDecision({}, {ageDays:40/24}, 1, true, now, 'today_yesterday').allow, false);
  assert.equal(freshnessDecision({}, {}, 1, true, now, 'today_yesterday').allow, false);
  assert.equal(freshnessDecision({}, {}, 0, true, now, 'today_yesterday').allow, true);
});
test('freshness trusts an actual detail publication timestamp over a misleading card badge', () => {
  assert.equal(freshnessDecision({publishedAt:'2026-10-14T11:00:00+03:30'}, {ageDays:0}, 1, true, now,'today_yesterday').allow, false);
});
