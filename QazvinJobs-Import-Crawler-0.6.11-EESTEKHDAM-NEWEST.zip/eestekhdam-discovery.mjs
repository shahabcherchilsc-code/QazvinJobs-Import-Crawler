// E-Estekhdam lists are frequently relevance-sorted. Prefer the site's
// *visible* newest sorting control; never guess undocumented query params.
// An attempted click is not a verified sort. Keep that distinction in logs.

const EXACT_NEWEST = /^\s*جدیدترین\s*$/u;
const EXACT_RELEVANCE = /^\s*مرتبط[‌\s-]*ترین\s*$/u;

async function firstVisible(locator) {
  const count = Math.min(await locator.count().catch(() => 0), 8);
  for (let i = 0; i < count; i++) {
    const item = locator.nth(i);
    if (await item.isVisible().catch(() => false)) return item;
  }
  return null;
}

async function newestOption(page) {
  for (const locator of [
    page.getByRole('radio', { name: EXACT_NEWEST }),
    page.getByRole('option', { name: EXACT_NEWEST }),
    page.getByRole('menuitemradio', { name: EXACT_NEWEST }),
    page.getByText(EXACT_NEWEST)
  ]) {
    const match = await firstVisible(locator);
    if (match) return match;
  }
  return null;
}

async function openSortMenu(page) {
  for (const locator of [
    page.getByRole('button', { name: /مرتب[‌\s-]*سازی|مرتبط[‌\s-]*ترین/u }),
    page.getByText(EXACT_RELEVANCE),
    page.getByText(/^مرتب[‌\s-]*سازی$/u)
  ]) {
    const match = await firstVisible(locator);
    if (!match) continue;
    await match.click({ timeout: 1800 }).catch(() => {});
    if (await newestOption(page)) return true;
  }
  return false;
}

// Only used after clicking. We trust a selected radio/ARIA state, or a changed
// listing identity/order, rather than pretending click() alone proves sorting.
async function selectionEvidence(page) {
  return page.evaluate(() => {
    const clean = str => String(str || '').replace(/[\u200c\u200f\u202a-\u202e]/g, ' ').replace(/\s+/g, ' ').trim();
    for (const node of document.querySelectorAll('input[type="radio"], [role="radio"], [role="menuitemradio"], [role="option"]')) {
      const text = clean([node.getAttribute('aria-label'), node.closest('label')?.innerText, node.parentElement?.innerText, node.innerText].filter(Boolean).join(' '));
      if (text.length > 140 || !text.includes('جدیدترین')) continue;
      if (node.checked || node.getAttribute('aria-checked') === 'true' || node.getAttribute('aria-selected') === 'true') return 'selected_control';
    }
    return '';
  }).catch(() => '');
}

async function leadingListingIds(page) {
  return page.evaluate(() => Array.from(document.querySelectorAll('main a[href*="/k"]'))
    .map(a => { try { return (new URL(a.href,location.href).pathname.match(/^\/(k[a-z0-9]+)(?:-|\/|$)/i) || [])[1]; } catch { return ''; } })
    .filter(Boolean).slice(0, 8).join(','))
    .catch(() => '');
}

export async function preferNewestEEstekhdam(page) {
  const startUrl = page.url();
  const initialIds = await leadingListingIds(page);
  try {
    // On a later page the saved sort query may already be selected.
    let option = await newestOption(page);
    if (!option) {
      await openSortMenu(page);
      option = await newestOption(page);
    }
    if (!option) return { status: 'control_not_found', selected: false, url: page.url() };
    const prior = await selectionEvidence(page);
    if (prior) return { status: 'already_selected', selected: true, url: page.url() };
    await option.click({ timeout: 4500 });
    await page.waitForTimeout(1500);
    await page.locator('main a[href]').first().waitFor({ timeout: 5000 }).catch(() => {});
    const evidence = await selectionEvidence(page);
    const afterIds = await leadingListingIds(page);
    const orderChanged = Boolean(initialIds && afterIds && initialIds !== afterIds);
    const urlChanged = startUrl !== page.url();
    // A changed URL alone is not proof it means 'newest'.
    return { status: evidence ? 'selected_control' : orderChanged ? 'listing_changed' : 'clicked_unverified',
      selected: Boolean(evidence || orderChanged), url: page.url(), orderChanged, urlChanged };
  } catch (error) {
    return { status: 'sort_error', selected: false, url: page.url(), error: String(error?.message || error).slice(0, 180) };
  }
}

export function discoveryProbe(idsText, discoveredKeys, sourceIdOf) {
  const targets = String(idsText || '').split(/[\s,;]+/).map(x => x.trim().toLowerCase()).filter(x => /^k[a-z0-9]+$/i.test(x)).slice(0, 20);
  const seen = new Set(Array.from(discoveredKeys, url => sourceIdOf(url, 'e-estekhdam')));
  return Object.fromEntries([...new Set(targets)].map(id => [id, seen.has(id)]));
}
