<?php
/** Test-only WordPress query and connection-lock doubles. Never loaded by plugin. */
class QZIH_Test_Wpdb {
    public $prefix = 'qj_unit_';
    public $owner = 'worker_a';
    public $unavailable = false;
    public $last_error = '';
    public $locks = array();
    public function prepare( $sql, ...$values ) { return array( $sql, $values ); }
    public function get_var( $query ) {
        list( $sql, $values ) = $query;
        $name = $values[0];
        if ( $this->unavailable ) { return null; }
        if ( false !== strpos( $sql, 'GET_LOCK' ) ) {
            if ( isset( $this->locks[$name] ) && $this->locks[$name]['owner'] !== $this->owner ) { return '0'; }
            $depth = isset( $this->locks[$name] ) ? $this->locks[$name]['depth'] : 0;
            $this->locks[$name] = array( 'owner'=>$this->owner, 'depth'=>$depth+1 );
            return '1';
        }
        if ( ! isset( $this->locks[$name] ) || $this->locks[$name]['owner'] !== $this->owner ) { return '0'; }
        $this->locks[$name]['depth']--;
        if ( ! $this->locks[$name]['depth'] ) { unset( $this->locks[$name] ); }
        return '1';
    }
}
$GLOBALS['wpdb'] = new QZIH_Test_Wpdb();
function wp_parse_url( $url, $component = -1 ) { return parse_url( $url, $component ); }
function wp_json_encode( $value, $flags = 0 ) { return json_encode( $value, $flags ); }
function wpautop( $text ) { return '<p>' . $text . '</p>'; }
function get_transient( $key ) { return $GLOBALS['transients'][$key] ?? false; }
function delete_transient( $key ) { unset( $GLOBALS['transients'][$key] ); return true; }
function delete_option( $key ) { unset( $GLOBALS['options'][$key] ); return true; }
function get_the_title( $id ) { $post = get_post( $id ); return $post ? $post->post_title : ''; }
function wp_delete_post( $id, $force = false ) { unset( $GLOBALS['posts'][$id], $GLOBALS['meta'][$id] ); return true; }
function wp_untrash_post( $id ) { $GLOBALS['posts'][$id]['post_status'] = 'draft'; return true; }
function qzih_test_meta_matches( $id, $query ) {
    if ( isset( $query['key'] ) ) {
        $value = (string) ( $GLOBALS['meta'][$id][$query['key']] ?? '' );
        if ( 'LIKE' === ( $query['compare'] ?? '=' ) ) { return false !== strpos( $value, (string) $query['value'] ); }
        return $value === (string) $query['value'];
    }
    $values = array();
    foreach ( $query as $key => $child ) { if ( is_int( $key ) && is_array( $child ) ) { $values[] = qzih_test_meta_matches( $id, $child ); } }
    return 'OR' === ( $query['relation'] ?? 'AND' ) ? in_array( true, $values, true ) : ! in_array( false, $values, true );
}
function get_posts( $args ) {
    $ids = array();
    foreach ( $GLOBALS['posts'] ?? array() as $id=>$post ) {
        if ( isset( $args['post_type'] ) && ! in_array( $post['post_type'], (array) $args['post_type'], true ) ) { continue; }
        if ( isset( $args['post_status'] ) && 'any' !== $args['post_status'] && ! in_array( $post['post_status'], (array) $args['post_status'], true ) ) { continue; }
        if ( isset( $args['meta_query'] ) && ! qzih_test_meta_matches( $id, $args['meta_query'] ) ) { continue; }
        $ids[] = $id;
    }
    sort( $ids );
    if ( 'DESC' === ( $args['order'] ?? 'DESC' ) ) { $ids = array_reverse( $ids ); }
    $ids = array_slice( $ids, 0, $args['posts_per_page'] ?? 5 );
    return 'ids' === ( $args['fields'] ?? '' ) ? $ids : array_map( 'get_post', $ids );
}
