<?php
/** Offline receiver tests. No WordPress install, network or production database. */
define( 'QZIH_TEST_BOOTSTRAP_ONLY', true );
require __DIR__ . '/importer-regressions.php';
$tests = array();
function identity_fixture() {
    fixture(); $GLOBALS['posts'] = array(); $GLOBALS['meta'] = array();
    $GLOBALS['transients'] = array(); $GLOBALS['wpdb'] = new QZIH_Test_Wpdb();
}
function identity_item( $id = 'ksample-pos-aaaaaaaaaaaa', $title = 'کارگر انبار' ) {
    return array( 'source'=>'e-estekhdam', 'source_id'=>$id, 'url'=>'https://www.e-estekhdam.com/ksample-new-slug', 'title'=>$title );
}
function identity_post( $id, $source_id, $title, $status = 'draft', $owned = true, $queue = false ) {
    $GLOBALS['posts'][$id] = array( 'ID'=>$id, 'post_type'=>$queue ? QZIH_Importer::QUEUE_POST_TYPE : 'product', 'post_status'=>$status, 'post_title'=>$title, 'post_content'=>'MANUAL CONTENT', 'post_excerpt'=>'MANUAL EXCERPT' );
    $GLOBALS['meta'][$id] = array(
        $queue ? '_qzih_source_id' : '_qz_source_id'=>$source_id,
        $queue ? '_qzih_source_url' : '_qz_source_url'=>'https://www.e-estekhdam.com/ksample-old-slug',
        '_qz_import_hub_owned'=>$owned ? 1 : 0,
        'qazvinjobs_ad_category_fields'=>array( 'source_raw_title'=>$title, 'manual_field'=>'MANUAL FIELD' ),
        '_qzih_source_title'=>$title,
    );
}
function receiver_payload( $source_id = 'ksample-pos-aaaaaaaaaaaa', $title = 'کارگر انبار' ) {
    $raw = identity_item( $source_id, $title );
    $raw['role'] = 'employer'; $raw['city'] = 'قزوین';
    $raw['content_text'] = 'نمونه لجستیک پارس در قزوین برای تکمیل کادر نیرو استخدام می‌کند.';
    $raw['content_html'] = '<p>' . $raw['content_text'] . '</p>';
    $raw['contacts'] = array( 'phones'=>array('09123456789') );
    $raw['fields'] = array( 'company_name'=>'نمونه لجستیک پارس', 'job_title'=>$title, 'city_name'=>'قزوین', 'province'=>'قزوین', 'cooperation_type'=>'تمام‌وقت', 'job_description'=>'دقت در انجام وظایف' );
    $raw['published_at'] = '2026-11-08';
    if ( $source_id !== 'ksample' ) { $raw['parent_source_id'] = 'ksample'; $raw['position_index'] = 1; $raw['position_count'] = 2; $raw['multi_position'] = true; }
    return $raw;
}
$tests['complete receive then repeat preserves the same draft and manual edits'] = static function () {
    identity_fixture();
    $first = invoke_importer( 'process_received_item', receiver_payload() );
    equal( $first['status'], 'accepted', 'first import accepted' );
    $id = $first['ad_id']; equal( get_post_status( $id ), 'draft', 'never published' );
    $GLOBALS['posts'][$id]['post_content'] = 'MANUAL REVIEWED CONTENT';
    $GLOBALS['meta'][$id]['manual_extra'] = 'MANUAL VALUE';
    $posts = $GLOBALS['posts']; $meta = $GLOBALS['meta'];
    $again = invoke_importer( 'process_received_item', receiver_payload() );
    equal( $again['status'], 'duplicates', 'repeat acknowledged as duplicate' ); equal( $again['ad_id'], $id, 'same ad' );
    equal( $GLOBALS['posts'], $posts, 'no duplicate or overwritten body' ); equal( $GLOBALS['meta'], $meta, 'manual fields intact' );
    equal( count( $GLOBALS['wpdb']->locks ), 0, 'nested import locks released' );
    $fallback = invoke_importer( 'process_received_item', receiver_payload( 'ksample' ) );
    equal( $fallback['reason'], 'multi_position_fallback_requires_review', 'fallback blocked' ); equal( $GLOBALS['posts'], $posts, 'child still intact' );
};
$tests['complete receive creates independent drafts for distinct sibling jobs'] = static function () {
    identity_fixture();
    $first = invoke_importer( 'process_received_item', receiver_payload() );
    $second = invoke_importer( 'process_received_item', receiver_payload( 'ksample-pos-bbbbbbbbbbbb', 'حسابدار' ) );
    equal( $first['status'], 'accepted', 'first job accepted' ); equal( $second['status'], 'accepted', 'second job accepted' );
    check( $first['ad_id'] !== $second['ad_id'], 'distinct draft IDs' ); equal( count( $GLOBALS['posts'] ), 4, 'two queues and two drafts' );
};
$tests['same exact vacancy remains a duplicate across every stored status'] = static function () {
    foreach ( array( 'draft','pending','publish','private','future','trash' ) as $status ) {
        identity_fixture(); identity_post( 10, 'ksample-pos-aaaaaaaaaaaa', 'عنوان ویرایش‌شده', $status );
        $posts = $GLOBALS['posts']; $meta = $GLOBALS['meta'];
        $result = QZIH_Identity::inspect( identity_item() );
        equal( $result['status'], 'duplicates', $status ); equal( $result['ad_id'], 10, 'same ad' );
        equal( $GLOBALS['posts'], $posts, 'posts preserved' ); equal( $GLOBALS['meta'], $meta, 'metadata preserved' );
    }
};
$tests['cosmetic Persian title changes are recognized under the same source page'] = static function () {
    identity_fixture(); identity_post( 10, 'ksample-pos-aaaaaaaaaaaa', 'استخدام كارگر انبار' );
    equal( QZIH_Identity::inspect( identity_item( 'ksample-pos-bbbbbbbbbbbb', 'کارگر انبار' ) )['status'], 'duplicates', 'Arabic kaf variant' );
    equal( QZIH_Identity::title_key( 'استخدام کارشناس‌فروش' ), QZIH_Identity::title_key( 'کارشناس فروش' ), 'half space' );
    equal( QZIH_Identity::title_key( 'کارگر ( شیفت ۲ )' ), QZIH_Identity::title_key( 'کارگر(شیفت 2)' ), 'digits and punctuation spacing' );
};
$tests['a genuinely different role on a shared page is allowed'] = static function () {
    identity_fixture(); identity_post( 10, 'ksample-pos-aaaaaaaaaaaa', 'کارگر انبار' );
    equal( QZIH_Identity::inspect( identity_item( 'ksample-pos-bbbbbbbbbbbb', 'حسابدار' ) ), false, 'new role remains eligible' );
};
$tests['titles from different source pages are never collapsed'] = static function () {
    identity_fixture(); identity_post( 10, 'kother-pos-aaaaaaaaaaaa', 'کارگر انبار' );
    equal( QZIH_Identity::inspect( identity_item() ), false, 'same title in another company/page' );
};
$tests['multi-position to single fallback is held without mutating any child'] = static function () {
    identity_fixture(); identity_post( 10, 'ksample-pos-aaaaaaaaaaaa', 'کارگر' ); identity_post( 11, 'ksample-pos-bbbbbbbbbbbb', 'حسابدار' );
    $posts = $GLOBALS['posts']; $meta = $GLOBALS['meta'];
    $result = QZIH_Identity::inspect( identity_item( 'ksample', 'استخدام چند ردیف شغلی' ) );
    equal( $result['status'], 'invalid', 'no duplicate acknowledgement for the whole page' );
    equal( $result['reason'], 'multi_position_fallback_requires_review', 'explicit review' );
    equal( $GLOBALS['posts'], $posts, 'children preserved' ); equal( $GLOBALS['meta'], $meta, 'child fields preserved' );
};
$tests['single-page legacy records need review when the new child cannot be identified'] = static function () {
    identity_fixture(); identity_post( 10, 'ksample', 'استخدام چند ردیف شغلی' );
    equal( QZIH_Identity::inspect( identity_item() )['reason'], 'legacy_page_identity_requires_review', 'ambiguous group held' );
    identity_fixture(); identity_post( 10, 'ksample', 'کارگر انبار' );
    equal( QZIH_Identity::inspect( identity_item() )['status'], 'duplicates', 'same known role recognized' );
};
$tests['identical titles with different source ordinals stay independent'] = static function () {
    identity_fixture(); identity_post( 10, 'ksample-pos-aaaaaaaaaaaa-1', 'کارگر انبار' );
    equal( QZIH_Identity::inspect( identity_item( 'ksample-pos-aaaaaaaaaaaa-2' ) ), false, 'second equal-title role eligible' );
    equal( QZIH_Identity::inspect( identity_item( 'ksample-pos-bbbbbbbbbbbb-1' ) )['status'], 'duplicates', 'cosmetic same ordinal' );
    equal( QZIH_Identity::inspect( identity_item() )['reason'], 'position_ordinal_requires_review', 'lost ordinal held' );
};
$tests['manual ads and controlled parser tests are excluded'] = static function () {
    identity_fixture(); identity_post( 10, 'ksample-pos-aaaaaaaaaaaa', 'کارگر انبار', 'draft', false );
    equal( QZIH_Identity::inspect( identity_item() ), false, 'unowned ad left alone' );
    identity_post( 11, 'qztest-ksample-pos-aaaaaaaaaaaa-20261108', 'کارگر انبار' );
    equal( QZIH_Identity::inspect( identity_item() ), false, 'test ID excluded' );
};
$tests['an existing queue also prevents repeated creation'] = static function () {
    identity_fixture(); identity_post( 10, 'ksample-pos-aaaaaaaaaaaa', 'کارگر انبار', 'pending', true, true );
    $result = QZIH_Identity::inspect( identity_item() ); equal( $result['queue_id'], 10, 'same queue' );
    equal( QZIH_Identity::inspect( identity_item(), 10 ), false, 'creation can exclude its own queue' );
};
$tests['a database lookup failure cannot silently allow a new draft'] = static function () {
    identity_fixture(); $GLOBALS['wpdb']->last_error = 'simulated lookup failure';
    equal( QZIH_Identity::inspect( identity_item() )['reason'], 'identity_lookup_failed', 'fail closed' );
};
$tests['page locks serialize independent workers and support nested creation'] = static function () {
    identity_fixture(); $db = $GLOBALS['wpdb'];
    $first = QZIH_Identity::acquire( 'e-estekhdam', 'ksample' ); check( is_string( $first ), 'worker A acquired' );
    $nested = QZIH_Identity::acquire( 'e-estekhdam', 'ksample' ); equal( $nested, $first, 'same page lock' );
    QZIH_Identity::release( $nested );
    $db->owner = 'worker_b'; check( is_wp_error( QZIH_Identity::acquire( 'e-estekhdam', 'ksample' ) ), 'worker B blocked while A is active' );
    $db->owner = 'worker_a'; QZIH_Identity::release( $first );
    $db->owner = 'worker_b'; $second = QZIH_Identity::acquire( 'e-estekhdam', 'ksample' ); check( is_string( $second ), 'B acquired after release' );
    QZIH_Identity::release( $second ); equal( count( $db->locks ), 0, 'no leaked lock' );
};
$tests['lock errors return a retryable receiver result without creating data'] = static function () {
    identity_fixture(); $GLOBALS['wpdb']->unavailable = true;
    $result = invoke_importer( 'process_received_item', identity_item() );
    equal( $result['status'], 'errors', 'not a duplicate or accepted' ); check( $result['retryable'], 'retryable' ); equal( count( $GLOBALS['posts'] ), 0, 'no posts' );
};
$tests['validation returns always release the page lock'] = static function () {
    identity_fixture(); $result = invoke_importer( 'process_received_item', identity_item( 'kother' ) );
    equal( $result['status'], 'invalid', 'source mismatch rejected' ); equal( count( $GLOBALS['wpdb']->locks ), 0, 'finally released' );
};
$tests['refreshing an already-linked draft does not acquire a second identity'] = static function () {
    fixture(); linked_draft(); $GLOBALS['wpdb'] = new QZIH_Test_Wpdb();
    $count = count( $GLOBALS['posts'] ); $id = invoke_importer( 'create_ad_draft_from_queue', 1 );
    equal( $id, 2, 'same linked draft' ); equal( count( $GLOBALS['posts'] ), $count, 'no extra ad' ); equal( count( $GLOBALS['wpdb']->locks ), 0, 'creation lock released' );
};
$tests['the create button cannot create another ad from a redundant queue'] = static function () {
    fixture(); $GLOBALS['wpdb'] = new QZIH_Test_Wpdb();
    identity_post( 10, 'k7i18e', 'کارگر انبار', 'publish' );
    $before = (array) get_post( 10 ); $id = invoke_importer( 'create_ad_draft_from_queue', 1 );
    equal( $id, 10, 'existing ad returned' ); equal( (array) get_post( 10 ), $before, 'published ad untouched' ); equal( count( $GLOBALS['posts'] ), 2, 'no extra post' );
};
$failed = 0;
foreach ( $tests as $name=>$test ) {
    try { $test(); echo "PASS: $name\n"; }
    catch ( Throwable $error ) { $failed++; fwrite( STDERR, "FAIL: $name: " . $error->getMessage() . "\n" ); }
}
echo count( $tests ) . ' identity tests, ' . $failed . " failures\n";
exit( $failed ? 1 : 0 );
