<?php
/** CI-only: real MySQL connection locks; no production DB or WordPress data. */
define( 'ABSPATH', __DIR__ . '/' );
class WP_Error {
    public $code;
    public function __construct( $code, $message ) { $this->code = $code; }
}
function is_wp_error( $value ) { return $value instanceof WP_Error; }
require __DIR__ . '/../includes/class-qzih-identity.php';
final class QZIH_Test_Mysql_Connection {
    public $prefix = 'qj_ci_';
    private $db;
    public function __construct() {
        $this->db = new mysqli( '127.0.0.1', 'qj_ci', 'qj_test_only', 'qj_ci', 3306 );
        if ( $this->db->connect_errno ) { throw new RuntimeException( 'CI database connection failed' ); }
    }
    public function prepare( $sql, $name ) { return str_replace( '%s', "'" . $this->db->real_escape_string( $name ) . "'", $sql ); }
    public function get_var( $sql ) { $row = $this->db->query( $sql )->fetch_row(); return $row[0]; }
}
function expect_lock( $condition, $message ) { if ( ! $condition ) { throw new RuntimeException( $message ); } }
$one = new QZIH_Test_Mysql_Connection(); $two = new QZIH_Test_Mysql_Connection();
$GLOBALS['wpdb'] = $one;
$a = QZIH_Identity::acquire( 'e-estekhdam', 'ci-page' ); expect_lock( is_string( $a ), 'first connection acquires' );
$nested = QZIH_Identity::acquire( 'e-estekhdam', 'ci-page' ); expect_lock( $nested === $a, 'nested creation uses the same page lock' );
$GLOBALS['wpdb'] = $two;
expect_lock( is_wp_error( QZIH_Identity::acquire( 'e-estekhdam', 'ci-page' ) ), 'second connection blocked' );
$other = QZIH_Identity::acquire( 'e-estekhdam', 'ci-other-page' ); expect_lock( is_string( $other ), 'independent page allowed' ); QZIH_Identity::release( $other );
$GLOBALS['wpdb'] = $one; QZIH_Identity::release( $nested );
$GLOBALS['wpdb'] = $two; expect_lock( is_wp_error( QZIH_Identity::acquire( 'e-estekhdam', 'ci-page' ) ), 'one nested release does not unlock the running import' );
$GLOBALS['wpdb'] = $one; QZIH_Identity::release( $a );
$GLOBALS['wpdb'] = $two; $b = QZIH_Identity::acquire( 'e-estekhdam', 'ci-page' ); expect_lock( is_string( $b ), 'second connection acquires after full release' ); QZIH_Identity::release( $b );
echo "PASS: real MySQL connection locks, nested release and independent pages\n";
