<?php
/** CLI-only regression harness; WordPress/core are stubbed, no network or database. */
if ( PHP_SAPI !== 'cli' ) { exit; }
define( 'ABSPATH', __DIR__ . '/' );
define( 'QZIH_VERSION', '0.3.59' );
error_reporting( E_ALL );
set_error_handler( static function ( $level, $message, $file, $line ) {
    if ( error_reporting() & $level ) { throw new ErrorException( $message, 0, $level, $file, $line ); }
    return false;
} );
class WP_Error {
    private $code; private $message;
    public function __construct( $code, $message ) { $this->code = $code; $this->message = $message; }
    public function get_error_message() { return $this->message; }
    public function get_error_code() { return $this->code; }
}
function is_wp_error( $v ) { return $v instanceof WP_Error; }
function absint( $v ) { return abs( (int) $v ); }
function sanitize_key( $v ) { return preg_replace( '/[^a-z0-9_\-]/', '', strtolower( (string) $v ) ); }
function wp_strip_all_tags( $v ) { return strip_tags( preg_replace( '#<(script|style)[^>]*>.*?</\1>#isu', '', (string) $v ) ); }
function sanitize_text_field( $v ) { return trim( preg_replace( '/\s+/u', ' ', wp_strip_all_tags( $v ) ) ); }
function sanitize_textarea_field( $v ) { return trim( wp_strip_all_tags( $v ) ); }
function esc_html( $v ) { return htmlspecialchars( (string) $v, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8' ); }
function esc_url_raw( $v ) { return (string) $v; }
function wp_kses_post( $v ) { return strip_tags( preg_replace( '#<(script|style)[^>]*>.*?</\1>#isu', '', (string) $v ), '<h2><h3><p><ul><ol><li><strong><em><br>' ); }
function wp_trim_words( $v, $limit, $more ) { $words = preg_split( '/\s+/u', trim( $v ) ); return implode( ' ', array_slice( $words, 0, $limit ) ) . ( count( $words ) > $limit ? $more : '' ); }
function wp_slash( $v ) { return is_array( $v ) ? array_map( 'wp_slash', $v ) : ( is_string( $v ) ? addslashes( $v ) : $v ); }
function wp_unslash( $v ) { return is_array( $v ) ? array_map( 'wp_unslash', $v ) : ( is_string( $v ) ? stripslashes( $v ) : $v ); }
function current_time( $format ) { return '2026-10-05 12:00:00'; }
function sanitize_email( $v ) { return filter_var( $v, FILTER_SANITIZE_EMAIL ); }
function is_email( $v ) { return filter_var( $v, FILTER_VALIDATE_EMAIL ); }
function taxonomy_exists( $v ) { return false; }
function get_option( $key, $default = false ) { return $GLOBALS['options'][ $key ] ?? $default; }
function update_option( $key, $v, $autoload = null ) { $GLOBALS['options'][ $key ] = $v; return true; }
function get_user_by( $key, $v ) { return (object) array( 'ID' => 99 ); }
function update_user_meta( $id, $key, $v ) { return true; }
function get_post_meta( $id, $key = '', $single = false ) {
    if ( '' === $key ) { return $GLOBALS['meta'][ $id ] ?? array(); }
    return $GLOBALS['meta'][ $id ][ $key ] ?? ( $single ? '' : array() );
}
function update_post_meta( $id, $key, $v ) { $GLOBALS['meta'][ $id ][ $key ] = $v; return true; }
function delete_post_meta( $id, $key ) { unset( $GLOBALS['meta'][ $id ][ $key ] ); return true; }
function get_post( $id ) { return isset( $GLOBALS['posts'][ $id ] ) ? (object) $GLOBALS['posts'][ $id ] : null; }
function get_post_type( $id ) { $p = get_post( $id ); return $p ? $p->post_type : false; }
function get_post_status( $id ) { $p = get_post( $id ); return $p ? $p->post_status : false; }
function wp_update_post( $arr, $error = false ) {
    $arr = wp_unslash( $arr ); $id = $arr['ID'];
    if ( ! isset( $GLOBALS['posts'][ $id ] ) ) { return new WP_Error( 'missing', 'Missing post' ); }
    foreach ( $arr as $key => $v ) { if ( 'meta_input' !== $key ) { $GLOBALS['posts'][ $id ][ $key ] = $v; } }
    foreach ( $arr['meta_input'] ?? array() as $key => $v ) { update_post_meta( $id, $key, $v ); }
    return $id;
}
function wp_insert_post( $arr, $error = false ) {
    $id = ++$GLOBALS['next_id'];
    $GLOBALS['posts'][ $id ] = array( 'ID' => $id, 'post_type' => 'product', 'post_status' => 'draft', 'post_title' => '', 'post_content' => '', 'post_excerpt' => '' );
    $arr['ID'] = $id;
    return wp_update_post( $arr, $error );
}
function do_action( $hook, ...$args ) {
    // Simulate an integration that erases fields after draft creation.
    if ( 'qazvinjobs_import_draft_ready' === $hook && ! empty( $GLOBALS['erase_editorial'] ) ) {
        $GLOBALS['posts'][ $args[0] ]['post_content'] = '';
        update_post_meta( $args[0], '_yoast_wpseo_metadesc', '' );
        update_post_meta( $args[0], 'qazvinjobs_ad_company_name', '' );
    }
}
class QazvinJobs_Compat { public static function primary_ad_post_type() { return 'product'; } public static function ad_post_types() { return array('product'); } }
class QazvinJobs_Field_Schema {
    public static function options( $key, $role = '' ) { return array(); }
    public static function normalize_values( $fields, $role = '' ) {
        // Reproduce an incompatible schema's empty defaults for common facts.
        return array_merge( $fields, array( 'company_name' => '', 'job_description' => '', 'job_title' => '' ) );
    }
    public static function normalize_values_for_category( $fields, $category, $role = '' ) {
        return array_intersect_key( $fields, array_flip( array( 'cooperation_type', 'insurance', 'experience_years' ) ) );
    }
    public static function normalize_field_value( $key, $value, $role = '' ) { return $value; }
}
require __DIR__ . '/wordpress-identity-stubs.php';
require __DIR__ . '/../includes/class-qzih-editorial.php';
require __DIR__ . '/../includes/class-qzih-importer.php';
$importer = ( new ReflectionClass( 'QZIH_Importer' ) )->newInstanceWithoutConstructor();
function invoke_importer( $name, ...$args ) {
    $method = new ReflectionMethod( 'QZIH_Importer', $name );
    return $method->invokeArgs( $GLOBALS['importer'], $args );
}
function check( $condition, $message ) { if ( ! $condition ) { throw new RuntimeException( $message ); } }
function equal( $actual, $expected, $message ) { check( $actual === $expected, $message . ' actual=' . json_encode( $actual, JSON_UNESCAPED_UNICODE ) ); }
function fixture( $fields = null ) {
    $GLOBALS['posts'] = array( 1 => array( 'ID' => 1, 'post_type' => QZIH_Importer::QUEUE_POST_TYPE, 'post_status' => 'draft', 'post_title' => 'کارگر انبار', 'post_content' => '', 'post_excerpt' => '' ) );
    $GLOBALS['meta'] = array( 1 => array(
        '_qzih_source_id' => 'k7i18e', '_qzih_source_url' => 'https://www.e-estekhdam.com/k7i18e-example',
        '_qzih_source' => 'e-estekhdam', '_qzih_source_title' => 'کارگر انبار', '_qzih_role' => 'employer', '_qzih_city' => 'قزوین',
        '_qzih_legacy_category_key' => 'transport-logistics', '_qzih_canonical_category_key' => 'transport-logistics', '_qzih_specialty_key' => 'warehouse',
        '_qzih_raw_text' => "شرایط احراز\nدقت در کار\nتسهیلات و مزایا\nبیمه", '_qzih_contacts' => array( 'phones' => array( '09123456789' ) ),
        '_qzih_fields' => $fields ?? array( 'company_name' => 'نمونه لجستیک پارس', 'job_title' => 'کارگر انبار', 'cooperation_type' => 'تمام‌وقت', 'job_description' => "شرایط احراز\nدقت در کار\nتسهیلات و مزایا\nبیمه" ),
    ) );
    $GLOBALS['options'] = array(); $GLOBALS['next_id'] = 100; $GLOBALS['erase_editorial'] = false;
}
function linked_draft( $body = '', $seo = '' ) {
    $GLOBALS['posts'][2] = array( 'ID' => 2, 'post_type' => 'product', 'post_status' => 'draft', 'post_title' => 'کارگر انبار', 'post_content' => $body, 'post_excerpt' => 'خلاصه مدیر' );
    $GLOBALS['meta'][2] = array( '_qz_import_hub_owned' => 1, '_qz_source_id' => 'k7i18e', '_yoast_wpseo_metadesc' => $seo, 'qazvinjobs_ad_category_fields' => array( 'manual_field' => 'ارزش دستی' ) );
    update_post_meta( 1, '_qzih_created_ad_id', 2 );
}
$tests = array(
    'employer extraction rejects cities, generic names and applicant sentences' => static function () {
        equal( QZIH_Editorial::company_from_title( 'استخدام کارگر انبار در آریا لجستیک در قزوین - ای استخدام' ), 'آریا لجستیک', 'named company' );
        foreach ( array( 'استخدام کارگر انبار در قزوین', 'استخدام کارگر انبار در یک مجموعه معتبر' ) as $title ) { equal( QZIH_Editorial::company_from_title( $title ), '', 'reject generic/city' ); }
        equal( QZIH_Editorial::company_from_hiring_line( 'نمونه لجستیک پارس در استان قزوین جهت تکمیل کادر نیرو استخدام می‌کند' ), 'نمونه لجستیک پارس', 'hiring sentence' );
        equal( QZIH_Editorial::company_from_hiring_line( 'متقاضیان جهت ارسال رزومه اقدام کنند' ), '', 'applicants are not employer' );
    },
    'schema empty defaults cannot erase source company or multiline content' => static function () {
        $source = array( 'company_name' => 'نمونه', 'job_description' => "الف\nب", 'benefits_list' => array() );
        $result = QZIH_Editorial::merge_fields( $source, array( 'company_name' => '', 'job_description' => '', 'benefits_list' => array( 'ناهار / غذا' ) ) );
        equal( $result, $source, 'source facts and explicit empty list survive' );
        equal( invoke_importer( 'sanitize_source_fields', $source )['job_description'], "الف\nب", 'sanitize preserves line breaks' );
    },
    'Persian bullets, headings and character endings remain valid UTF-8' => static function () {
        $html = QZIH_Editorial::source_html( "شرایط احراز\n• آشنایی با انبارداری\n• دقت در کار\nدقت در کار" );
        check( strpos( $html, '<h3>شرایط احراز</h3>' ) !== false, 'section heading' );
        check( strpos( $html, 'آشنایی با انبارداری' ) !== false, 'Persian word ending not cut' );
        equal( substr_count( $html, 'دقت در کار' ), 1, 'duplicate source line removed' );
        check( preg_match( '//u', $html ) === 1, 'valid Unicode' );
    },
    'half-space variants become exact canonical choices' => static function () {
        $f = invoke_importer( 'validate_import_field_values', array( 'cooperation_type' => 'تمام وقت', 'work_days' => array( 'سه شنبه' ) ) );
        equal( $f['cooperation_type'], 'تمام‌وقت', 'cooperation canonical' );
        equal( $f['work_days'], array( 'سه‌شنبه' ), 'day canonical' );
        $f = invoke_importer( 'normalize_source_multiselects', array( 'work_days' => array( 'سه شنبه' ) ) );
        equal( $f['work_days'], array( 'سه‌شنبه' ), 'earlier normalization also canonical' );
    },
    'trusted payload keeps company and creates factual nonempty body and Yoast metadata' => static function () {
        fixture(); $p = invoke_importer( 'build_trusted_payload', get_post( 1 ), array(), 'employer' );
        equal( $p['fields']['company_name'], 'نمونه لجستیک پارس', 'category filter cannot erase company' );
        check( strpos( $p['content'], 'دقت در کار' ) === false, 'source detail not repeated in summary' );
        check( strpos( $p['fields']['job_description'], 'دقت در کار' ) !== false, 'full source text still in fields' );
        check( strpos( $p['requirements'], 'دقت در کار' ) !== false, 'requirements retained' );
        check( strpos( $p['fields']['requirements'], 'دقت در کار' ) !== false, 'fallback requirements in fields' );
        check( strpos( $p['content'], 'نمونه لجستیک پارس' ) !== false, 'company intro' );
        check( strpos( $p['seo_description'], 'کارگر انبار' ) !== false, 'meta contains job' );
        check( count( preg_split( '//u', $p['seo_description'], -1, PREG_SPLIT_NO_EMPTY ) ) <= 160, 'Unicode meta length' );
        $minimal = QZIH_Editorial::build( array(), 'کارگر', 'قزوین', 'employer', '' );
        check( $minimal['content'] && $minimal['seo_description'], 'empty source still yields factual intro' );
        check( ! preg_match( '/بیمه|حقوق|ناهار|سابقه/u', $minimal['content'] . $minimal['seo_description'] ), 'no invented benefits' );
    },
    'short SEO summary ignores source lists for both roles and keeps a bounded paragraph' => static function () {
        foreach ( array( 'employer', 'job_seeker' ) as $role ) {
            $fields = array( 'company_name' => 'نمونه لجستیک پارس', 'cooperation_type' => 'تمام‌وقت' );
            $source = '<h3>شرایط احراز</h3><ul><li>متن بلند منبع</li></ul>';
            $p = QZIH_Editorial::build( $fields, 'کارگر انبار', 'قزوین', $role, $source );
            check( strpos( $p['content'], 'کارگر انبار' ) !== false && strpos( $p['content'], 'قزوین' ) !== false, 'job and city present' );
            equal( substr_count( $p['content'], '<p>' ), 1, 'one short paragraph' );
            check( ! preg_match( '/<h3|<ul|متن بلند منبع/u', $p['content'] ), 'no detailed list' );
            check( count( preg_split( '//u', wp_strip_all_tags( $p['content'] ), -1, PREG_SPLIT_NO_EMPTY ) ) <= 800, 'bounded main description' );
        }
    },
    'summarizing old generated content preserves same ID, source fields and custom meta' => static function () {
        fixture(); linked_draft( '<h2>عنوان</h2><p>متن خودکار بلند قبلی</p><ul><li>جزئیات</li></ul>', 'متای اختصاصی مدیر' );
        $old = get_post( 2 )->post_content;
        update_post_meta( 2, '_qzih_editorial_snapshot', array( 'content' => $old ) );
        $queue_fields = get_post_meta( 1, '_qzih_fields', true );
        $count = count( $GLOBALS['posts'] );
        $r = invoke_importer( 'repair_existing_editorial', 1, true );
        check( ! is_wp_error( $r ) && $r['summarized'], 'summary succeeds' );
        equal( $r['ad_id'], 2, 'same draft' ); equal( count( $GLOBALS['posts'] ), $count, 'no new draft' );
        check( strpos( get_post( 2 )->post_content, 'متن خودکار بلند قبلی' ) === false, 'old body replaced' );
        equal( get_post_meta( 2, '_qzih_editorial_previous_content', true ), $old, 'previous body backed up' );
        equal( get_post_meta( 1, '_qzih_fields', true ), $queue_fields, 'source fields preserved' );
        equal( get_post_meta( 2, 'qazvinjobs_ad_category_fields', true )['manual_field'], 'ارزش دستی', 'manual fields preserved' );
        equal( get_post_meta( 2, '_yoast_wpseo_metadesc', true ), 'متای اختصاصی مدیر', 'manual meta preserved' );
        $r = invoke_importer( 'repair_existing_editorial', 1, true );
        check( ! is_wp_error( $r ), 'repeat summary safe' );
        equal( get_post_meta( 2, '_qzih_editorial_previous_content', true ), $old, 'repeat does not erase backup' );
    },
    'summary refuses manual or unknown content without changing any stored data' => static function () {
        foreach ( array( 'manual', 'no_snapshot' ) as $case ) {
            fixture(); linked_draft( '<p>متن اختصاصی مدیر</p>', 'متای مدیر' );
            if ( 'manual' === $case ) { update_post_meta( 2, '_qzih_editorial_snapshot', array( 'content' => '<p>متن قبلی خودکار</p>' ) ); }
            $snapshot = get_post_meta( 2, '_qzih_editorial_snapshot', true );
            $repair = invoke_importer( 'repair_existing_editorial', 1 );
            check( ! is_wp_error( $repair ), 'blank-field repair still allowed' );
            equal( get_post_meta( 2, '_qzih_editorial_snapshot', true ), $snapshot, 'repair does not mark manual content as generated' );
            $posts = $GLOBALS['posts']; $meta = $GLOBALS['meta'];
            $r = invoke_importer( 'repair_existing_editorial', 1, true );
            check( is_wp_error( $r ), 'manual/unknown content refused' );
            equal( $GLOBALS['posts'], $posts, 'posts preserved' ); equal( $GLOBALS['meta'], $meta, 'all metadata preserved' );
        }
    },
    'draft creation stores company/body/meta after an integration clears them' => static function () {
        fixture(); $GLOBALS['erase_editorial'] = true;
        $id = invoke_importer( 'create_ad_draft_from_queue', 1 );
        check( ! is_wp_error( $id ), is_wp_error( $id ) ? $id->get_error_message() : 'created' );
        equal( get_post_status( $id ), 'draft', 'never published' );
        equal( get_post_meta( $id, 'qazvinjobs_ad_company_name', true ), 'نمونه لجستیک پارس', 'company survives' );
        equal( get_post_meta( $id, 'qazvinjobs_ad_category_fields', true )['company_name'], 'نمونه لجستیک پارس', 'field bag company survives' );
        check( get_post( $id )->post_content && get_post_meta( $id, '_yoast_wpseo_metadesc', true ), 'body and meta saved' );
    },
    'repair fills blank fields in same draft and preserves manual fields' => static function () {
        fixture(); linked_draft(); $before = count( $GLOBALS['posts'] );
        $r = invoke_importer( 'repair_existing_editorial', 1 );
        check( ! is_wp_error( $r ), 'repair succeeds' ); equal( $r['ad_id'], 2, 'same ID' ); equal( count( $GLOBALS['posts'] ), $before, 'no duplicate' );
        check( get_post( 2 )->post_content && get_post_meta( 2, '_yoast_wpseo_metadesc', true ), 'filled blanks' );
        equal( get_post_meta( 2, 'qazvinjobs_ad_category_fields', true )['manual_field'], 'ارزش دستی', 'manual field retained' );
        fixture(); linked_draft( '<p>متن اختصاصی مدیر</p>', 'متای اختصاصی مدیر' );
        update_post_meta( 2, 'qazvinjobs_ad_company_name', 'نام مدیر' );
        $r = invoke_importer( 'repair_existing_editorial', 1 ); check( ! is_wp_error( $r ), 'manual repair succeeds' );
        equal( get_post( 2 )->post_content, '<p>متن اختصاصی مدیر</p>', 'manual body retained' );
        equal( get_post_meta( 2, '_yoast_wpseo_metadesc', true ), 'متای اختصاصی مدیر', 'manual meta retained' );
        equal( get_post_meta( 2, 'qazvinjobs_ad_company_name', true ), 'نام مدیر', 'manual company retained' );
    },
    'repair and manual refresh refuse published or unowned drafts' => static function () {
        foreach ( array( 'published', 'unowned', 'different_source' ) as $case ) {
            fixture(); linked_draft( '<p>متن</p>', 'متا' );
            if ( 'published' === $case ) { $GLOBALS['posts'][2]['post_status'] = 'publish'; }
            elseif ( 'unowned' === $case ) { update_post_meta( 2, '_qz_import_hub_owned', 0 ); }
            else { update_post_meta( 2, '_qz_source_id', 'different' ); }
            $before = $GLOBALS['posts']; $r = invoke_importer( 'repair_existing_editorial', 1 );
            check( is_wp_error( $r ), 'refuse ' . $case ); equal( $GLOBALS['posts'], $before, 'refusal does not mutate posts' );
        }
        fixture(); linked_draft( '<p>منتشرشده</p>' ); $GLOBALS['posts'][2]['post_status'] = 'publish';
        $r = invoke_importer( 'create_ad_draft_from_queue', 1 ); check( is_wp_error( $r ), 'refresh cannot turn published ad into draft' );
        equal( get_post_status( 2 ), 'publish', 'published status retained' );
    },
);
$tests['precise experience and new benefits survive receiver validation'] = static function () {
    foreach ( array( 'حداقل ۳ سال','۳ تا ۵ سال','حداقل ۶ ماه','کمتر از یک سال' ) as $value ) {
        equal( invoke_importer( 'extract_experience_value', $value ), $value, 'precise duration' );
        equal( invoke_importer( 'validate_import_field_values', array( 'experience_years'=>$value ) )['experience_years'], $value, 'editable experience accepted' );
    }
    equal( invoke_importer( 'extract_experience_value', 'حداقل سن ۲۵ سال؛ دارای حداقل ۳ سال سابقه کار', true ), 'حداقل ۳ سال', 'age does not become experience' );
    equal( invoke_importer( 'extract_experience_value', '۳ سال تا ۵ سال' ), '۳ سال تا ۵ سال', 'explicit range units' );
    equal( invoke_importer( 'extract_experience_value', 'حداقل سابقه کار: ۳ سال' ), 'حداقل ۳ سال', 'minimum label' );
    $benefits = invoke_importer( 'extract_benefits_list_value', 'هدایای مناسبتی، پزشک سازمانی، کمک هزینه ایاب و ذهاب، میان وعده، کمک هزینه آموزش' );
    foreach ( array( 'هدایای مناسبتی','پزشک سازمانی','کمک هزینه ایاب ذهاب','میان وعده','کمک هزینه آموزش' ) as $benefit ) { check( in_array( $benefit, $benefits, true ), $benefit ); }
    equal( invoke_importer( 'validate_import_field_values', array( 'benefits_list'=>$benefits ) )['benefits_list'], $benefits, 'new benefits accepted' );
};
$tests['Telegram-only contact creates a usable draft without inventing a phone'] = static function () {
    fixture(); update_post_meta( 1, '_qzih_contacts', array( 'telegram'=>array( '@company_jobs' ) ) );
    $id = invoke_importer( 'create_ad_draft_from_queue', 1 );
    check( ! is_wp_error( $id ), 'draft created' );
    equal( get_post_status( $id ), 'draft', 'review required' );
    equal( get_post_meta( $id, 'qazvinjobs_ad_telegram', true ), '@company_jobs', 'Telegram persisted' );
    check( in_array( 'telegram', get_post_meta( $id, 'qazvinjobs_ad_contact_methods', true ), true ), 'Telegram enabled' );
    equal( get_post_meta( $id, 'qazvinjobs_ad_contact_phone_public', true ), '', 'no made-up phone' );
};
if ( defined( 'QZIH_TEST_BOOTSTRAP_ONLY' ) ) { return; }
$failed = 0;
foreach ( $tests as $name => $test ) {
    try { $test(); echo "PASS: $name\n"; }
    catch ( Throwable $e ) { $failed++; fwrite( STDERR, "FAIL: $name: " . $e->getMessage() . "\n" ); }
}
echo count( $tests ) . ' tests, ' . $failed . " failures\n";
exit( $failed ? 1 : 0 );
