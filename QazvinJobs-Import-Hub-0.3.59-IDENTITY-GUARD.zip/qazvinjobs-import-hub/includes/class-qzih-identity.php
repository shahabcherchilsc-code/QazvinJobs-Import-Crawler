<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

/** Source-scoped identity checks. No fuzzy title matching or data migration. */
final class QZIH_Identity {
    public static function parent_id( $source, $id ) {
        if ( 'e-estekhdam' === $source && preg_match( '/^(k[a-z0-9]+)(?:-pos-[a-f0-9]{12}(?:-[1-9][0-9]*)?)?$/', (string) $id, $m ) ) { return $m[1]; }
        if ( 'divar' === $source && preg_match( '/^divar-[a-z0-9_-]+$/', (string) $id ) ) { return $id; }
        return '';
    }

    public static function title_key( $title ) {
        $title = html_entity_decode( wp_strip_all_tags( (string) $title ), ENT_QUOTES | ENT_HTML5, 'UTF-8' );
        $title = strtr( $title, array( 'ي'=>'ی', 'ى'=>'ی', 'ك'=>'ک' ) );
        $title = strtr( $title, array_combine( preg_split( '//u', '۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩', -1, PREG_SPLIT_NO_EMPTY ), str_split( '01234567890123456789' ) ) );
        $title = preg_replace( '/[\x{200c}\x{200d}\x{200f}\x{202a}-\x{202e}]/u', ' ', $title );
        $title = trim( preg_replace( '/\s+/u', ' ', $title ) );
        $title = preg_replace( '/^استخدام\s+/u', '', $title );
        // Preserve role words, qualifications and ordinal numbers. Two different
        // roles on one page must remain independent even if their contact matches.
        $title = preg_replace( '/\s*([()\[\]،,:؛;\-–—])\s*/u', '$1', $title );
        return strtolower( trim( preg_replace( '/\s+/u', ' ', $title ) ) );
    }

    public static function acquire( $source, $parent ) {
        global $wpdb;
        if ( ! $parent || ! isset( $wpdb ) ) { return new WP_Error( 'qzih_lock_unavailable', 'امکان بررسی قفل دریافت فراهم نیست؛ دوباره تلاش کنید.' ); }
        $name = 'qzih_' . substr( hash( 'sha256', $wpdb->prefix . '|' . $source . '|' . $parent ), 0, 56 );
        // MySQL/MariaDB connection locks are atomic and do not expire while an
        // import is still running. The same connection may nest this lock.
        $value = $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 0)', $name ) );
        if ( '1' !== (string) $value ) {
            return new WP_Error( null === $value ? 'qzih_lock_unavailable' : 'qzih_import_busy', 'دریافت همین صفحه هم‌زمان در حال بررسی است یا قفل پایگاه داده در دسترس نیست؛ دوباره تلاش کنید.' );
        }
        return $name;
    }

    public static function release( $name ) {
        global $wpdb;
        if ( is_string( $name ) && '' !== $name ) { $wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $name ) ); }
    }

    public static function inspect( $item, $exclude_queue = 0 ) {
        global $wpdb;
        $source = $item['source'];
        $id = $item['source_id'];
        $parent = self::parent_id( $source, $id );
        if ( ! $parent ) { return array( 'status'=>'invalid', 'source_id'=>$id, 'reason'=>'invalid_source_identity' ); }
        $types = array( QZIH_Importer::QUEUE_POST_TYPE );
        if ( class_exists( 'QazvinJobs_Compat' ) ) { $types = array_merge( $types, QazvinJobs_Compat::ad_post_types() ); }
        $query = array( 'relation'=>'OR' );
        foreach ( array( '_qz_source_id', '_qzih_source_id' ) as $key ) {
            $query[] = array( 'key'=>$key, 'value'=>$parent );
            if ( 'e-estekhdam' === $source ) { $query[] = array( 'key'=>$key, 'value'=>$parent . '-pos-', 'compare'=>'LIKE' ); }
        }
        foreach ( array( '_qz_parent_source_id', '_qzih_parent_source_id' ) as $key ) { $query[] = array( 'key'=>$key, 'value'=>$parent ); }
        $candidates = get_posts( array(
            'post_type'=>array_values( array_unique( $types ) ),
            'post_status'=>array( 'publish','pending','draft','private','future','trash' ),
            'posts_per_page'=>501, 'fields'=>'ids', 'orderby'=>'ID', 'order'=>'ASC', 'meta_query'=>$query,
        ) );
        if ( ! empty( $wpdb->last_error ) ) { return array( 'status'=>'errors', 'source_id'=>$id, 'reason'=>'identity_lookup_failed', 'retryable'=>true ); }
        if ( count( $candidates ) >= 501 ) { return array( 'status'=>'invalid', 'source_id'=>$id, 'reason'=>'identity_review_limit' ); }
        $records = array();
        foreach ( $candidates as $post_id ) {
            $post = get_post( $post_id );
            if ( ! $post ) { continue; }
            $queue = QZIH_Importer::QUEUE_POST_TYPE === $post->post_type;
            if ( $queue && (int) $exclude_queue === (int) $post_id ) { continue; }
            if ( ! $queue && ! (int) get_post_meta( $post_id, '_qz_import_hub_owned', true ) ) { continue; }
            $stored = (string) get_post_meta( $post_id, $queue ? '_qzih_source_id' : '_qz_source_id', true );
            if ( $parent !== self::parent_id( $source, $stored ) || get_post_meta( $post_id, '_qzih_test_reimport', true ) ) { continue; }
            $fields = get_post_meta( $post_id, $queue ? '_qzih_fields' : 'qazvinjobs_ad_category_fields', true );
            $fields = is_array( $fields ) ? $fields : array();
            $title = $queue ? get_post_meta( $post_id, '_qzih_source_title', true ) : '';
            if ( ! $title ) { $title = ! empty( $fields['source_raw_title'] ) ? $fields['source_raw_title'] : ( ! empty( $fields['job_title'] ) ? $fields['job_title'] : $post->post_title ); }
            $records[] = array( 'id'=>(int) $post_id, 'queue'=>$queue, 'source_id'=>$stored, 'title'=>self::title_key( $title ) );
        }
        // Prefer a real ad in the response if its queue also exists.
        usort( $records, static function ( $a, $b ) { return (int) $a['queue'] - (int) $b['queue']; } );
        foreach ( $records as $record ) {
            if ( $record['source_id'] === $id ) { return self::duplicate( $id, $record, 'already_received' ); }
        }
        $child = $id !== $parent;
        if ( ! $child ) {
            foreach ( $records as $record ) {
                if ( $record['source_id'] !== $parent ) {
                    return array( 'status'=>'invalid', 'source_id'=>$id, 'reason'=>'multi_position_fallback_requires_review' );
                }
            }
        }
        $title = self::title_key( $item['title'] );
        foreach ( $records as $record ) {
            if ( $child && '' !== $title && $title === $record['title'] ) {
                // Repeated equal titles can describe independent vacancies.
                // Their original child IDs/ordinals must remain authoritative.
                preg_match( '/-pos-[a-f0-9]{12}-([1-9][0-9]*)$/', $id, $incoming_ordinal );
                preg_match( '/-pos-[a-f0-9]{12}-([1-9][0-9]*)$/', $record['source_id'], $stored_ordinal );
                $incoming_number = isset( $incoming_ordinal[1] ) ? (int) $incoming_ordinal[1] : 0;
                $stored_number = isset( $stored_ordinal[1] ) ? (int) $stored_ordinal[1] : 0;
                if ( $incoming_number && $stored_number && $incoming_number !== $stored_number ) { continue; }
                if ( (bool) $incoming_number !== (bool) $stored_number ) {
                    return array( 'status'=>'invalid', 'source_id'=>$id, 'reason'=>'position_ordinal_requires_review' );
                }
                return self::duplicate( $id, $record, 'same_page_same_position_title' );
            }
        }
        if ( $child ) {
            foreach ( $records as $record ) {
                if ( $record['source_id'] === $parent ) {
                    return array( 'status'=>'invalid', 'source_id'=>$id, 'reason'=>'legacy_page_identity_requires_review' );
                }
            }
        }
        return false;
    }

    private static function duplicate( $id, $record, $reason ) {
        $result = array( 'status'=>'duplicates', 'source_id'=>$id, 'reason'=>$reason, 'mode'=>'existing_import_preserved' );
        $result[ $record['queue'] ? 'queue_id' : 'ad_id' ] = $record['id'];
        return $result;
    }
}
