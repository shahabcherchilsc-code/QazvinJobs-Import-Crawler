# QazvinJobs Import Crawler 0.5.1

- Hotfix نهایی برای خطای `Cannot access finalRequirements before initialization`.
- ترتیب محاسبه `finalRequirements` و `finalBenefitsDescription` اصلاح شد تا قبل از استفاده مقداردهی شوند.
- هیچ منطق استخراج، دسته‌بندی، تماس، deduplication یا mapping نسبت به 0.5.0 تغییر نکرده است؛ این نسخه فقط رفع خطای اجرایی است.
