export function applicationDecision(policy, pageId) {
  if (!policy || policy.version !== 1 || policy.scope !== 'listing_card' || policy.source_page_id !== pageId) return 'unknown';
  if (policy.easy_apply === true) return 'easy_apply';
  if (policy.card_complete === true && policy.easy_apply === false) return 'eligible';
  return 'unknown';
}
