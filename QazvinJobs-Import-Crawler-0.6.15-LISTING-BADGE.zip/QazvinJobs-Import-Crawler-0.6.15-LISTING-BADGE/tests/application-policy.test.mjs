import { test } from 'node:test';
import assert from 'node:assert/strict';
import { chromium } from 'playwright';
import { applicationDecision } from '../application-policy.mjs';
import { collectDiscoveryRows } from '../freshness.mjs';
const card = (overrides = {}) => ({ version:1, scope:'listing_card', source_page_id:'ksample', card_complete:true, easy_apply:false, ...overrides });
test('a complete own card without Easy Apply is eligible', () => assert.equal(applicationDecision(card(),'ksample'),'eligible'));
test('an explicit Easy Apply badge excludes that ad even if contacts might exist', () => assert.equal(applicationDecision(card({easy_apply:true}),'ksample'),'easy_apply'));
test('missing, incomplete, different-card and string flags are never treated as an absent badge', () => {
  for (const value of [null, {}, card({card_complete:false}), card({source_page_id:'kother'}), card({easy_apply:'false'}),card({scope:'whole_page'})]) assert.equal(applicationDecision(value,'ksample'),'unknown');
});
const browserTest=process.env.QZIH_SKIP_BROWSER_TESTS==='1'?test.skip:test;
browserTest('badge is scoped to each listing card and cannot leak from an adjacent ad', async () => {
  const b=await chromium.launch({executablePath:process.env.QZIH_TEST_BROWSER || undefined,headless:true,args:['--no-sandbox']});
  try {
    const p=await b.newPage();
    await p.setContent(`<main><article><a href="https://www.e-estekhdam.com/ksample"><h3>استخدام حسابدار</h3></a><span>قزوین، تمام وقت، دیروز</span><span>ارسال آسان</span></article><article><a href="https://www.e-estekhdam.com/kother"><h3>کارگر انبار</h3></a><span>قزوین، تمام وقت، امروز</span></article></main>`);
    const rows=await p.evaluate(collectDiscoveryRows,{source:'e-estekhdam'});
    assert.equal(applicationDecision(rows[0].applicationPolicy,'ksample'),'easy_apply');
    assert.equal(applicationDecision(rows[1].applicationPolicy,'kother'),'eligible');
  } finally {await b.close();}
});
browserTest('an anchor that wraps the whole card is supported and a title-only shell remains unknown', async () => {
  const b=await chromium.launch({executablePath:process.env.QZIH_TEST_BROWSER || undefined,headless:true,args:['--no-sandbox']});
  try {
    const p=await b.newPage();
    await p.setContent(`<main><a href="https://www.e-estekhdam.com/ksample"><h3>کارگر انبار</h3><span>قزوین، تمام وقت، دیروز</span></a><a href="https://www.e-estekhdam.com/kother"><h3>حسابدار</h3></a></main>`);
    const rows=await p.evaluate(collectDiscoveryRows,{source:'e-estekhdam'});
    assert.equal(applicationDecision(rows[0].applicationPolicy,'ksample'),'eligible');
    assert.equal(applicationDecision(rows[1].applicationPolicy,'kother'),'unknown');
  } finally {await b.close();}
});
