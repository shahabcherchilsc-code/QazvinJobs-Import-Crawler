<?php
define( 'QZIH_IDENTITY_BOOTSTRAP_ONLY', true );
require __DIR__ . '/identity-regressions.php';
$tests = array();
$tests['non-Easy-Apply without extracted contacts becomes a private review draft'] = static function () {
    identity_fixture(); $raw = receiver_payload(); $raw['contacts'] = array();
    $result = invoke_importer( 'process_received_item', $raw );
    equal( $result['status'], 'accepted', 'eligible without invented phone' );
    equal( $result['mode'], 'contact_review_draft', 'review state' );
    equal( get_post_status( $result['ad_id'] ), 'draft', 'not published' );
    equal( get_post_meta( $result['queue_id'], '_qzih_contact_review_required', true ), 1, 'contact review persisted' );
    equal( get_post_meta( $result['ad_id'], 'qazvinjobs_ad_contact_phone_public', true ), '', 'no invented phone' );
};
$tests['an Easy Apply ad is excluded even with a phone'] = static function () {
    identity_fixture(); $raw = receiver_payload(); $raw['application_policy']['easy_apply'] = true;
    $r = invoke_importer( 'process_received_item', $raw );
    equal( $r['reason'], 'eestekhdam_easy_apply_excluded', 'explicit badge honored' ); equal( count( $GLOBALS['posts'] ), 0, 'no queue or ad' );
};
$tests['missing and untrusted absence evidence is held without creating drafts'] = static function () {
    foreach ( array( 'missing','incomplete','foreign','string','scope' ) as $case ) {
        identity_fixture(); $raw = receiver_payload();
        if ( 'missing' === $case ) { unset( $raw['application_policy'] ); }
        if ( 'incomplete' === $case ) { $raw['application_policy']['card_complete'] = false; }
        if ( 'foreign' === $case ) { $raw['application_policy']['source_page_id'] = 'kother'; }
        if ( 'string' === $case ) { $raw['application_policy']['easy_apply'] = 'false'; }
        if ( 'scope' === $case ) { $raw['application_policy']['scope'] = 'whole_page'; }
        equal( invoke_importer( 'process_received_item', $raw )['reason'], 'eestekhdam_card_evidence_required', $case );
        equal( count( $GLOBALS['posts'] ), 0, 'nothing created' );
    }
};
$tests['verified contact remains usable on an eligible card'] = static function () {
    identity_fixture(); $r = invoke_importer( 'process_received_item', receiver_payload() );
    equal( $r['status'], 'accepted', 'accepted' ); equal( $r['mode'], 'source_first_draft', 'no contact fallback needed' );
    equal( get_post_meta( $r['ad_id'], 'qazvinjobs_ad_contact_phone_public', true ), '09123456789', 'real fixture phone retained' );
};
$tests['a second missing-contact import still cannot duplicate or overwrite the first'] = static function () {
    identity_fixture(); $raw = receiver_payload(); $raw['contacts'] = array();
    $first = invoke_importer( 'process_received_item', $raw );
    $GLOBALS['posts'][$first['ad_id']]['post_content'] = 'MANUAL TEXT'; $posts = $GLOBALS['posts'];
    $again = invoke_importer( 'process_received_item', $raw );
    equal( $again['status'], 'duplicates', 'duplicate acknowledged' ); equal( $GLOBALS['posts'], $posts, 'manual draft preserved' );
};
$failed = 0;
foreach ( $tests as $name=>$test ) {
    try { $test(); echo "PASS: $name\n"; }
    catch ( Throwable $error ) { $failed++; fwrite( STDERR, "FAIL: $name: " . $error->getMessage() . "\n" ); }
}
echo count( $tests ) . ' Easy Apply policy tests, ' . $failed . " failures\n";
exit( $failed ? 1 : 0 );
