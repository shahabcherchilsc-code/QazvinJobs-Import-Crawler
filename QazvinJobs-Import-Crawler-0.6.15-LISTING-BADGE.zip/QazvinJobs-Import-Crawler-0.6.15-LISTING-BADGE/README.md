QazvinJobs Import Crawler 0.6.15 — scoped E-Estekhdam listing badge policy.
Read README-LISTING-BADGE-FA.md. Requires Import Hub 0.3.60 for real imports. First run validate_only. Keep cPanel on --daily-test.
